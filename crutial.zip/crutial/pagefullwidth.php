<?php
/**
 * Genesis Sample.
 *
 * This file adds the landing page template to the Genesis Sample Theme.
 *
 * Template Name: Full width page
 *
 * @package Genesis Sample
 * @author  StudioPress
 * @license GPL-2.0+
 * @link    http://www.studiopress.com/
 */

// This file handles pages, but only exists for the sake of child theme forward compatibility.
get_header();
?>
<script type="application/ld+json">
 { "@context": "http://schema.org",
 "@type": "Organization",
 "name": "<?php echo get_bloginfo('name'); ?>",
 "legalName" : "<?php echo get_bloginfo('name'); ?>",
 "url": "<?php echo get_site_url(); ?>",
 "logo": "<?php echo get_header_image(); ?>",
 "foundingDate": "<?php echo get_option('founddate'); ?>",
 "founders":  {
 "@type": "Person",
 "name": "<?php echo get_option('foundname'); ?>"
 },
 "address": {
 "@type": "PostalAddress",
 "streetAddress": "<?php echo get_option('streetaddress'); ?>",
 "addressLocality": "<?php echo get_option('addresslocality'); ?>",
 "addressRegion": "<?php echo get_option('addressregion'); ?>",
 "postalCode": "<?php echo get_option('postalcode'); ?>",
 "addressCountry": "<?php echo get_option('addresscountry'); ?>"
 },
 "contactPoint": {
 "@type": "ContactPoint",
 "contactType": "<?php echo get_option('contacttype'); ?>",
 "telephone": "<?php echo get_option('support_phone'); ?>",
 "email": "<?php echo get_option('support_email'); ?>"
 },
 "sameAs": [ 
 "<?php echo get_option('link1'); ?>",
 "<?php echo get_option('link2'); ?>",
 "<?php echo get_option('link3'); ?>",
 "<?php echo get_option('link4'); ?>",
 "<?php echo get_option('link5'); ?>"
 ]}
</script>
	<?php
	  if ( is_active_sidebar( 'topadd-sidebar-widget' ))
	  {
	  genesis_widget_area( 'topadd-sidebar-widget', array(
		'before' => '<div class="topaddpositon">',
		'after'  => '</div>',
	) );
	  }
	  ?>
<?php
$content_post = get_post($postid);
$content = $content_post->post_content;
$content = apply_filters('the_content', $content);
$content = str_replace(']]>', ']]&gt;', $content);
?>
<div class="inner-content">
		<div class="container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
					<div class="blog-single">	
<?php
echo $content;
?>
</div>
</div>
	

</div>
</div>
<?php
get_footer();
?>