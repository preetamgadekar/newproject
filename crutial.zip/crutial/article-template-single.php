<?php

/*
Template Name:Article Post
Template Post Type: post
*/

get_header();
?>
<?php
$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'singlepage' ); 	
?>
<script type="application/ld+json">
 { "@context": "http://schema.org",
 "@type": "Organization",
 "name": "<?php echo get_bloginfo('name'); ?>",
 "legalName" : "<?php echo get_bloginfo('name'); ?>",
 "url": "<?php echo get_site_url(); ?>",
 "logo": "<?php echo get_header_image(); ?>",
 "foundingDate": "<?php echo get_option('founddate'); ?>",
 "founders":  {
 "@type": "Person",
 "name": "<?php echo get_option('foundname'); ?>"
 },
 "address": {
 "@type": "PostalAddress",
 "streetAddress": "<?php echo get_option('streetaddress'); ?>",
 "addressLocality": "<?php echo get_option('addresslocality'); ?>",
 "addressRegion": "<?php echo get_option('addressregion'); ?>",
 "postalCode": "<?php echo get_option('postalcode'); ?>",
 "addressCountry": "<?php echo get_option('addresscountry'); ?>"
 },
 "contactPoint": {
 "@type": "ContactPoint",
 "contactType": "<?php echo get_option('contacttype'); ?>",
 "telephone": "<?php echo get_option('support_phone'); ?>",
 "email": "<?php echo get_option('support_email'); ?>"
 },
 "sameAs": [ 
 "<?php echo get_option('link1'); ?>",
 "<?php echo get_option('link2'); ?>",
 "<?php echo get_option('link3'); ?>",
 "<?php echo get_option('link4'); ?>",
 "<?php echo get_option('link5'); ?>"
 ]}
</script>
<script type="application/ld+json">
{
  "@context": "http://schema.org/",
  "@type": "Article",
  "headline": "<?php the_title(); ?>",
  "name": "<?php the_title(); ?>",
    "datePublished": "<?php echo get_the_date('M j, Y'); ?>",
	"url": "<?php echo get_the_permalink(); ?>",
   "image": "<?php echo $image[0]; ?>",
  "description": "<?php echo strip_tags(get_the_excerpt()); ?>",
  "publisher": {
	  "@type": "organization",
	  "name": "<?php echo get_bloginfo('name'); ?>",
	   "logo": {
            "@type": "ImageObject",
            "name": "<?php echo get_bloginfo('name'); ?>",
            "width": "140",
            "height": "40",
            "url": "<?php echo get_header_image(); ?>"
        }
  },

  "author": {
    "@type": "Person",
    "name": "<?php echo get_author_name(); ?> "
  },
  "dateModified": "<?php echo the_modified_date('M j, Y'); ?>",
  "mainEntityOfPage":"<?php echo get_the_permalink(); ?>",
  "articleBody": "<?php echo strip_tags(get_the_content());?>"


}
</script>
<?php
	  if ( is_active_sidebar( 'topadd-sidebar-widget' ))
	  {
	  genesis_widget_area( 'topadd-sidebar-widget', array(
		'before' => '<div class="topaddpositon">',
		'after'  => '</div>',
	) );
	  }
?>
<div class="inner-content">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
				<?php while ( have_posts() ) : the_post(); ?>
				<article>
					<div class="blog-single">

		<?php 
		genesis_do_breadcrumbs();
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
				
	genesis_markup(array(
	'close' => ''
));	
?>
<?php 
	genesis_markup( array(
		'html5'   => '<h1 class="h1" %s>',
		'context' => 'entry-title'
	) );

 the_title();
 
	genesis_markup( array(
		'close'   => '</h1>',
		
	) );

?>					
<div class="single-meta">
	<div class="meta pull-left">
						<?php
								genesis_markup( array(
		'html5'   => '<span class="author" %s>',
		'context' => 'author-box'
	) );
								echo '<img src="'. get_stylesheet_directory_uri().'/img/avatar/1.jpg" class="img-circle" alt="">';
								echo '<span itemprop="name">'.get_the_author().'</span>';

								genesis_markup( array(
                        'close' =>'</span>',	
                         ) );		   

								genesis_markup( array(
		'html5'   => '<span class="date" %s>',
		'context' => 'entry-time'
	) );
								
								
							echo ' on '.get_the_date('M j, Y');
								
								genesis_markup( array(
		                        'close'   => '</span>',
		                         ) );
								 
								?>
								<span class="comment"><i class="fa fa-comment-o"></i> 
								
								<?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?>
								</span>
								
								<span class="views"><i class="fa fa-eye"></i> 
								<?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
							</div>

							<div class="pull-right">
								<div class="social">
									<?php echo do_shortcode('[social_share_icons]') ?>
								</div>
							</div>	

							<div class="clearfix"></div>
						</div>
				<?php 
						
					genesis_markup( array(
	'html5'   => '<div class="div" %s>',
		'context' => 'entry'
	) );		
						
						
	genesis_markup( array(
		'html5'   => '<div %s>',
		'context' => 'entry-content'
	) );		
			
					
	genesis_markup( array(
		'html5'   => '<h1 class="h1" style="display:none !important"; %s>',
		'context' => 'entry-title'
	) );

 echo '<span>'.get_the_title().'</span>';
 
	genesis_markup( array(
		'close'   => '</h1>',
		
	) );			

the_content();
genesis_markup( array(
		'close'   => '</div>',
		
	) );
genesis_markup( array(
		'close'   => '</div>',
		
	) );
?>					
					<div class="clearfix"></div>
						<div class="tags">
					<?php the_tags( '<span>Tags:</span> &nbsp;',' ' ); ?>
						</div>
	
						
						
						
					<div class="clearfix"></div>
					</div>
					</article>
				<?php
					endwhile;
					
$previous = get_previous_post();
$next = get_next_post();

if ( get_next_post() ) { ?>
  
<?php } if ( get_previous_post() ) { ?>
 
<?php } ?>
					<div class="post-nav">
						<div class="row">
						<?php
						
							$prev_title = get_the_title();
							
						
							
							$prev_post_title = get_the_title($next);
							
							
							
							if(get_the_title($previous) !=  $prev_title)
							{
								?>
							<div class="col-md-6 text-right">
								<a href="<?php echo get_the_permalink($previous); ?>"><i class="fa fa-angle-left"></i></a>
								<span class="small-title">Read Previous</span>
								<h3><a href="<?php echo get_the_permalink($previous); ?>"><?php echo get_the_title($previous); ?></a></h3>
							</div>
	                     <?php
							}
							else
							{
							?>	
								<div class="col-md-6 text-right">
								
							</div>
							<?php	
							}
							?>
							<?php
						
							$next_title = get_the_title();
							
							$next_post_title = get_the_title($next);
							
							if(get_the_title($next) !=  $next_title)
							{
								?>
							<div class="col-md-6 text-left">
								<a href="<?php echo get_the_permalink($next); ?>"><i class="fa fa-angle-right"></i></a>
								<span class="small-title">Read Next</span>
								<h3><a href="<?php echo get_the_permalink($next); ?>"><?php echo get_the_title($next); ?></a></h3>
							</div>
							
							<?php
							}
							else
							{
							?>	
								<div class="col-md-6 text-left">
								
							</div>
							<?php	
							}
							?>
							
							
						</div>
					</div>

					<div class="related-posts">
						<h5>Related Articles</h5>
						
					   <div class="row">
						 <?php
		   
		   $postid=get_the_id();
			$relatedcategory =   get_the_category( $postid )[0]->name ;
			
		
	$exclude = get_the_ID();
		   

$args = array(
        'post_type' => 'post',
        'posts_per_page' => 6,
		 'post_status' => 'publish',
		'offset' => $posts_offset,
		'category_name' => $relatedcategory,
        'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => 'NOT IN'
           ) )
		   );



$newsQuery = new WP_Query($args);
if ( $newsQuery->have_posts() ) {
	
	$i = 1;
	
   while ($newsQuery->have_posts() ) {
        $newsQuery->the_post(); 
        
      
	if($exclude != get_the_id() && $i<4)
	{

			$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
				$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style3' ); 
						
	echo '<div class="col-md-4">';
							echo '<a href="'.get_the_permalink().'">';
							echo '<div class="article-thumb">';
							
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
								
								echo '</div>';
								echo '</a>';								echo '<div class="space10"></div>';
								echo '<div class="meta"><span>'.get_the_date('M j,Y').'</span></div>';
								echo '<h3 class="h5"><a href="'.get_the_permalink().'">'.get_the_title().'</a></h3>';
							echo '</div>';
			
$i++;
 }
}
}
			

wp_reset_query();			
				?>			
				</div>
				</div>
					
					<div class="comments">
						<h5><?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No';
                                     }
                                      ?> Comments</h5>
						
			<ul>					
  <?php  
$postid = get_the_ID();
	
        //Gather comments for a specific page/post 
        $comments = get_comments(array(
            'post_id' => $postid,
            'status' => 'approve' //Change this to the type of comments to be displayed
        ));

        //Display the list of comments
        wp_list_comments(array(
            'per_page' => 10, //Allow comment pagination
            'reverse_top_level' => false,
            'callback' => 'mytheme_comment'
			//Show the latest comments at the top of the list
        ), $comments);

    ?>
		</ul>					
		</div>
	<div class="comment-form">	
 <?php 
 comments_template();
 ?>
</div>
</div>
<?php 

    genesis_markup(array(
         'html5' => '<aside class="col-md-4" %s>',
		 'context' => 'sidebar-secondary'
		 ));
		 ?>
	<?php
	  if ( is_active_sidebar( 'post-sidebar-widget' ))
	  {
	  genesis_widget_area( 'post-sidebar-widget', array(
		'before' => '',
		'after'  => '',
	) );
	  }
	  ?>
<?php 
genesis_markup(array(
'close' => '</aside>'
));						
?>			
</div>
</div>
<?php
get_footer();
?>