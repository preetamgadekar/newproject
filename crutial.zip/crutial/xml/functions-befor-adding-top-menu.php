<?php
/**
 * Genesis Sample.
 *
 * This file adds functions to the Genesis Sample Theme.
 *
 * @package Genesis Sample
 * @author  StudioPress
 * @license GPL-2.0+
 * @link    http://www.studiopress.com/
 */
// Start the engine.
include_once( get_template_directory() . '/lib/init.php' );
// Setup Theme.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );
// Set Localization (do not remove).
add_action( 'after_setup_theme', 'genesis_sample_localization_setup' );
function genesis_sample_localization_setup(){
	load_child_theme_textdomain( 'genesis-sample', get_stylesheet_directory() . '/languages' );
}
// Add the helper functions.
include_once( get_stylesheet_directory() . '/lib/helper-functions.php' );
// Add Image upload and Color select to WordPress Theme Customizer.
require_once( get_stylesheet_directory() . '/lib/customize.php' );
// Include Customizer CSS.
include_once( get_stylesheet_directory() . '/lib/output.php' );
// Add WooCommerce support.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-setup.php' );
// Add the required WooCommerce styles and Customizer CSS.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-output.php' );
// Add the Genesis Connect WooCommerce notice.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-notice.php' );
// Child theme (do not remove).
define( 'CHILD_THEME_NAME', 'Genesis Sample' );
define( 'CHILD_THEME_URL', 'http://www.studiopress.com/' );
define( 'CHILD_THEME_VERSION', '2.3.1' );
// Enqueue Scripts and Styles.
add_action( 'wp_enqueue_scripts', 'genesis_sample_enqueue_scripts_styles' );
function genesis_sample_enqueue_scripts_styles() {
	wp_enqueue_style( 'genesis-sample-fonts', '//fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'dashicons' );
	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'genesis-sample-responsive-menu', get_stylesheet_directory_uri() . "/js/responsive-menus{$suffix}.js", array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_localize_script(
		'genesis-sample-responsive-menu',
		'genesis_responsive_menu',
		genesis_sample_responsive_menu_settings()
	);
}
// Define our responsive menu settings.
function genesis_sample_responsive_menu_settings() {
	$settings = array(
		'mainMenu'         => __( 'Menu', 'genesis-sample' ),
		'menuIconClass'    => 'dashicons-before dashicons-menu',
		'subMenu'          => __( 'Submenu', 'genesis-sample' ),
		'subMenuIconClass' => 'dashicons-before dashicons-arrow-down-alt2',
		'menuClasses'      => array(
			'combine' => array(
				'.nav-primary',
				'.nav-header',
			),
			'others'  => array(),
		),
	);
	return $settings;
}
// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );
// Add Accessibility support.
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );
// Add viewport meta tag for mobile browsers.
add_theme_support( 'genesis-responsive-viewport' );
// Add support for custom header.
add_theme_support( 'custom-header', array(
	'width'           => 600,
	'height'          => 160,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );
// Add support for custom background.
add_theme_support( 'custom-background' );
// Add support for after entry widget.
add_theme_support( 'genesis-after-entry-widget-area' );
// Add support for 3-column footer widgets.
add_theme_support( 'genesis-footer-widgets', 3 );
// Add Image Sizes.
add_image_size( 'featured-image', 720, 400, TRUE );
// Rename primary and secondary navigation menus.
add_theme_support( 'genesis-menus', array( 'primary' => __( 'After Header Menu', 'genesis-sample' ), 'secondary' => __( 'Footer Menu', 'genesis-sample' ) ) );
// Reposition the secondary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_footer', 'genesis_do_subnav', 5 );
// Reduce the secondary navigation menu to one level depth.
add_filter( 'wp_nav_menu_args', 'genesis_sample_secondary_menu_args' );
function genesis_sample_secondary_menu_args( $args ) {
	if ( 'secondary' != $args['theme_location'] ) {
		return $args;
	}
	$args['depth'] = 1;
	return $args;
}
// Modify size of the Gravatar in the author box.
add_filter( 'genesis_author_box_gravatar_size', 'genesis_sample_author_box_gravatar' );
function genesis_sample_author_box_gravatar( $size ) {
	return 90;
}
// Modify size of the Gravatar in the entry comments.
add_filter( 'genesis_comment_list_args', 'genesis_sample_comments_gravatar' );
function genesis_sample_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;

	return $args;
}
/*genesis custom footers code */
//* Remove site footer widgets
remove_theme_support( 'genesis-footer-widgets' );
//* Remove site footer elements
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
//Remove Existing Footer
 add_action( 'widgets_init', 'magazine_extra_widgets' );
 function magazine_extra_widgets()
 {
genesis_register_sidebar(array(
    'id' => 'home-slider',
	'name' => __( 'Home slider','magazine'),
	'description' =>__( 'This is for Home slider'),
	));
		genesis_register_sidebar(array(
    'id' => 'home-middle',
	'name' => __( 'Home Middle','magazine'),
	'description' =>__( 'This is for Home Middle'),
	));
 genesis_register_sidebar( array(
	'id'          => 'theme-footer-head1',
	'name'        => __( 'Footer Head 1','magazine'),
	'description' => __( 'This is the footer head 1.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-head2',
	'name'        => __( 'Footer Head 2','magazine'),
	'description' => __( 'This is the footer head 2.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-head3',
	'name'        => __( 'Footer Head 3','magazine'),
	'description' => __( 'This is the footer head 3.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-1',
	'name'        => __( 'Footer 1','magazine'),
	'description' => __( 'This is the footer 1.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-2',
	'name'        => __( 'Footer 2','magazine'),
	'description' => __( 'This is the footer 2.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-3',
	'name'        => __( 'Footer 3','magazine'),
	'description' => __( 'This is the footer 3.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-4',
	'name'        => __( 'Footer 4','magazine'),
	'description' => __( 'This is the footer 4.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-5',
	'name'        => __( 'Footer 5','magazine'),
	'description' => __( 'This is the footer 5.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-6',
	'name'        => __( 'Footer 6','magazine'),
	'description' => __( 'This is the footer 6.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-bottom1',
	'name'        => __( 'Footer bottom 1','magazine'),
	'description' => __( 'This is the footer bottom 1.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-bottom2',
	'name'        => __( 'Footer bottom 2','magazine'),
	'description' => __( 'This is the footer bottom 2.','magazine'),
) );
genesis_register_sidebar(array(
    'id' => 'home-sidebar-widget',
	'name' => __( 'Home Page Sidebar widgets','magazine'),
	'description' =>__( 'This is for Home page sidebar widgets'),
	));
genesis_register_sidebar(array(
    'id' => 'post-sidebar-widget',
	'name' => __( 'Post Page Sidebar widgets','magazine'),
	'description' =>__( 'This is for post page sidebar widgets'),
	));
genesis_register_sidebar(array(
    'id' => 'single-sidebar-widget',
	'name' => __( 'Single Page Sidebar widgets','magazine'),
	'description' =>__( 'This is for single page sidebar widgets'),
	));
 }
add_action('genesis_footer','magazine_footer_widget');	
// Position the Footer Area
function magazine_footer_widget() {
	genesis_markup( array(
		'html5'   => '<footer class="margin-top-30"><div class="container">',
	) );
genesis_markup( array(
		'html5'   => '<div class="footer-head"><div class="row center-content">',
	) );
	genesis_widget_area ('theme-footer-head1', array(
		'before' => '<div class ="col-md-2 col-sm-3">',
		'after'  => '</div>',
	));
		genesis_widget_area ('theme-footer-head2', array(
		'before' => '<div class ="col-md-6 col-sm-5">',
		'after'  => '</div>',
	));
		genesis_widget_area ('theme-footer-head3', array(
		'before' => '<div class ="col-md-4 col-sm-4">',
		'after'  => '</div>',
	));
genesis_markup( array(
		'close'   => '</div></div>',
    ) );
	genesis_markup( array(
		'html5'   => '<div class="footer-content"><div class="row">',
	) );
	genesis_widget_area ('theme-footer-1', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-2', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-3', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-4', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-5', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-6', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_markup( array(
		'close'   => '</div></div>',
	) );
	genesis_markup( array(
		'html5'   => '<div class="footer-bottom" %s><div class="row">',
		'context' => 'site-footer',
	) );
	genesis_widget_area ('theme-footer-bottom1', array(
		'before' => '<div class="col-md-6 col-sm-6">',
		'after'  => '</div>',
	));
		genesis_widget_area ('theme-footer-bottom2', array(
		'before' => '<div class="col-md-6 col-sm-6 text-right">',
		'after'  => '</div>',
	));
		genesis_markup( array(
		'close'   => '</div></div>',
	) );
	genesis_markup( array(
		'close'   => '</div></footer>',
	) );
	}
add_action( 'wp_enqueue_scripts', 'enqueue_front_scripts_header');
add_action( 'genesis_footer', 'enqueue_front_scripts_footer');
function enqueue_front_scripts_header()
{
/// custom theme code starts here
	wp_enqueue_style( 'fontawesom', get_stylesheet_directory_uri() . '/js/font-awesome/css/font-awesome.css' );
		wp_enqueue_style( 'slickcss', get_stylesheet_directory_uri() . '/js/slick/slick.css');
		wp_enqueue_style( 'bootstrap', get_stylesheet_directory_uri() . '/js/bootstrap/bootstrap.min.css' );
	wp_enqueue_style( 'animate', get_stylesheet_directory_uri() . '/css/animate.css' );
		wp_enqueue_style( 'style', get_stylesheet_directory_uri() . '/css/style.css' );
	//wp_enqueue_style( 'ts', get_stylesheet_directory_uri() . '/css/ts.css' );
	//wp_enqueue_style( 'bootstrapmin', get_stylesheet_directory_uri() . '/js/font-awesome/css/font-awesome.min.css' );
}
function enqueue_front_scripts_footer()
	{	
    wp_enqueue_script( 'modernizr-2.8.3-respond-1.4.2.mi', get_stylesheet_directory_uri() . '/js/modernizr-2.8.3-respond-1.4.2.min.js');
		wp_enqueue_script( 'bootstrapmin', get_stylesheet_directory_uri() . '/js/bootstrap/bootstrap.min.js',array('jquerymin'));
		wp_enqueue_script( 'jquerymin', get_stylesheet_directory_uri() . '/js/jquery.min.js');
		wp_enqueue_script( 'slickmin', get_stylesheet_directory_uri() . '/js/slick/slick.min.js');
		wp_enqueue_script( 'theme', get_stylesheet_directory_uri() . '/js/theme.js');
		//wp_enqueue_script( 'slick', get_stylesheet_directory_uri() . '/js/slick/slick.js');
//	wp_enqueue_script( 'instagramLitemin', get_stylesheet_directory_uri() . '/js/instagramLite.min.js');
	//	wp_enqueue_script( 'tweecool.min', get_stylesheet_directory_uri() . '/js/tweecool.min.js');
}
		//* Do NOT include the opening php tag shown above. Copy the code shown below.
//* Remove Skip Links from a template
remove_action ( 'genesis_before_header', 'genesis_skip_links', 5 );
//* Dequeue Skip Links Script
add_action( 'wp_enqueue_scripts','child_dequeue_skip_links' );
function child_dequeue_skip_links() {
	wp_dequeue_script( 'skip-links' );
}
		//remove initial header functions
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );
remove_action( 'genesis_header', 'genesis_do_header' );
//add in the new header markup - prefix the function name - here sm_ is used
add_action( 'genesis_header', 'sm_genesis_header_markup_open', 5 );
//New Header functions
function sm_genesis_header_markup_open() {
	genesis_markup( array(
		'html5'   => '<header class="header" %s>',
		'context' => 'site-header',
	) );
	// Added in content
?>
<nav class="navbar navbar-default" role="navigation">
<div class="container">
<div class="search-bar">
<?php		
		get_search_form();
?>			
		</div>
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
<?php			
if ( get_header_image() ) : 
	genesis_markup(array (
	 'html5' => '<a class="navbar-brand" href="'. esc_url( home_url( '/' ) ).'"><div %s>'.get_bloginfo( 'name' ).'</div>',
	 'context' => 'site-title'
	));
	genesis_markup(array (
'html5' => '<p class="site-description" %s>',
'context' => 'site-description'
));
echo get_option('blogdescription');
genesis_markup(array (
'close' =>'</p>'
));
$header_image = get_header_image();
	echo '<img src="'.esc_url($header_image).'" class="img-responsive" alt=""/>';
genesis_markup(array (
	'close' => '</a>'
	));
 endif; // End header image check. 
?>
</div>
	<div class="search-trigger pull-right"></div>
			<div class="login pull-right"></div>
			<!-- Collect the nav links, forms, and other content for toggling -->
<?php			
				genesis_markup(array(
				'html5' => '<div class = "collapse navbar-collapse navbar-ex1-collapse" %s>',
				'context' => 'nav-primary'
				));
	wp_nav_menu( array( 
'theme_location' => 'main-menu', 
'container' => false,
 'items_wrap'  => '<ul id="%1$s" class="nav navbar-nav">%3$s</ul>',
'walker' => new WP_Bootstrap_Navwalker()
 ) );
?>		
	</div>	
			</div>
		<?php
genesis_markup( array(
		'close'   => '</nav>',
		) );
genesis_markup( array(
		'close'   => '</header>'
       ) );
}
/**
 * WP Bootstrap Navwalker */
if ( ! class_exists( 'WP_Bootstrap_Navwalker' ) ) {
	/**
	 * WP_Bootstrap_Navwalker class.
	 *
	 * @extends Walker_Nav_Menu
	 */
	class WP_Bootstrap_Navwalker extends Walker_Nav_Menu {
		
		public function start_lvl( &$output, $depth = 0, $args = array() ) {
			$indent  = str_repeat( "\t", $depth );
			$output .= "\n$indent<ul role=\"menu\" class=\" dropdown-menu\" >\n";
		}
		public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
			$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
		
			if ( 0 === strcasecmp( $item->attr_title, 'divider' ) && 1 === $depth ) {
				$output .= $indent . '<li role="presentation" class="divider">';
			} elseif ( 0 === strcasecmp( $item->title, 'divider' ) && 1 === $depth ) {
				$output .= $indent . '<li role="presentation" class="divider">';
			} elseif ( 0 === strcasecmp( $item->attr_title, 'dropdown-header' ) && 1 === $depth ) {
				$output .= $indent . '<li role="presentation" class="dropdown-header">' . esc_attr( $item->title );
			} elseif ( 0 === strcasecmp( $item->attr_title, 'disabled' ) ) {
				$output .= $indent . '<li role="presentation" class="disabled"><a href="#">' . esc_attr( $item->title ) . '</a>';
			} else {
				$value       = '';
				$class_names = $value;
				$classes     = empty( $item->classes ) ? array() : (array) $item->classes;
				$classes[]   = 'menu-item-' . $item->ID;
				$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
				if ( $args->has_children ) {
					$class_names .= ' dropdown dropdown-v1';
				}
				if ( in_array( 'current-menu-item', $classes, true ) ) {
					$class_names .= ' dropdown dropdown-v1';
				}
				$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';
				$id          = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args );
				$id          = $id ? ' id="' . esc_attr( $id ) . '"' : '';
				$output     .= $indent . '<li' . $id . $value . $class_names . '>';
				$atts        = array();
				if ( empty( $item->attr_title ) ) {
					$atts['title'] = ! empty( $item->title ) ? strip_tags( $item->title ) : '';
				} else {
					$atts['title'] = $item->attr_title;
				}
				$atts['target'] = ! empty( $item->target ) ? $item->target : '';
				$atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
				// If item has_children add atts to a.
				if ( $args->has_children && 0 === $depth ) {
					$atts['href']          = '#';
					$atts['data-toggle']   = 'dropdown';
					$atts['class']         = 'dropdown-toggle';
					//$atts['aria-haspopup'] = 'true';
				} else {
					$atts['href'] = ! empty( $item->url ) ? $item->url : '';
				}
				$atts       = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args );
				$attributes = '';
				foreach ( $atts as $attr => $value ) {
					if ( ! empty( $value ) ) {
						$value       = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
						$attributes .= ' ' . $attr . '="' . $value . '"';
					}
				}
				$item_output = $args->before;
				
				if ( ! empty( $item->attr_title ) ) {
					$pos = strpos( esc_attr( $item->attr_title ), 'glyphicon' );
					if ( false !== $pos ) {
						$item_output .= '<a' . $attributes . '><span class="glyphicon ' . esc_attr( $item->attr_title ) . '" aria-hidden="true"></span>&nbsp;';
					} else {
						$item_output .= '<a' . $attributes . '><i class="fa ' . esc_attr( $item->attr_title ) . '" aria-hidden="true"></i>&nbsp;';
					}
				} else {
					$item_output .= '<a' . $attributes . '><span itemprop="name">';
				}
				$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
				$item_output .= ( $args->has_children && 0 === $depth ) ? ' <span class="caret"></span></a>' : '</span></a>';
				$item_output .= $args->after;
				$output      .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
			} // End if().
		}
		
		public function display_element( $element, &$children_elements, $max_depth, $depth, $args, &$output ) {
			if ( ! $element ) {
				return; }
			$id_field = $this->db_fields['id'];
			// Display this element.
			if ( is_object( $args[0] ) ) {
				$args[0]->has_children = ! empty( $children_elements[ $element->$id_field ] ); }
			parent::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
		}
		
		public static function fallback( $args ) {
			if ( current_user_can( 'edit_theme_options' ) ) {
				/* Get Arguments. */
				$container       = $args['container'];
				$container_id    = $args['container_id'];
				$container_class = $args['container_class'];
				$menu_class      = $args['menu_class'];
				$menu_id         = $args['menu_id'];
				if ( $container ) {
					echo '<' . esc_attr( $container );
					if ( $container_id ) {
						echo ' id="' . esc_attr( $container_id ) . '"';
					}
					if ( $container_class ) {
						echo ' class="' . esc_attr( $container_class ) . '"'; }
					echo '>';
				}
				echo '<ul';
				if ( $menu_id ) {
					echo ' id="' . esc_attr( $menu_id ) . '"'; }
				if ( $menu_class ) {
					echo ' class="' . esc_attr( $menu_class ) . '"'; }
				echo '>';
				echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '" title="">' . esc_attr( 'Add a menu', '' ) . '</a></li>';
				echo '</ul>';
				if ( $container ) {
					echo '</' . esc_attr( $container ) . '>'; }
			}
		}
	}
} // End if().
//* Remove primary/secondary navigation menus
remove_theme_support( 'genesis-menus' );
function register_additional_menu_main() {
register_nav_menu( 'main-menu' ,__( 'Main Menu' ));
}

add_action( 'init', 'register_additional_menu_main' );
//add_action( 'genesis_before', 'add_main_nav_genesis' ); 

//enables the shortcode in widget area
add_filter('widget_text', 'do_shortcode');

//customization to the genesis serch form 
 function magazine_search_form( $form, $search_text, $button_text) 
 {
	$onfocus = " onfocus=\"if (this.value == '$search_text') {this.value = '';}\"";
	$onblur = " onblur=\"if (this.value == '') {this.value = '$search_text';}\"";
	$form = '<form itemprop="potentialAction" itemscope="" itemtype="https://schema.org/SearchAction" method="get" class="footer-search" action="' . home_url() . '/">
	<input id="s" type="search"  value="' . esc_attr( $search_text ) . '" name="s" class="s search-input"' . $onfocus . $onblur . ' />
	<button type="submit" class="searchsubmit search-submit" value="" /><i class="fa fa-search"></i></button>
	<div class="search-close"><i class="fa fa-times"></i></div>
	</form>';
	return $form;
}
add_filter( 'genesis_search_form', 'magazine_search_form', 10, 4);

//code for the post count views
//Set the Post Custom Field in the WP dashboard as Name/Value pair 
function bac_PostViews($post_ID) {
    //Set the name of the Posts Custom Field.
    $count_key = 'post_views_count'; 
    //Returns values of the custom field with the specified key from the specified post.
    $count = get_post_meta($post_ID, $count_key, true);
    //If the the Post Custom Field value is empty. 
    if($count == ''){
        $count = 0; // set the counter to zero.
        //Delete all custom fields with the specified key from the specified post. 
        delete_post_meta($post_ID, $count_key);
        //Add a custom (meta) field (Name/value)to the specified post.
        add_post_meta($post_ID, $count_key, '0');
        return $count . ' View';
    //If the the Post Custom Field value is NOT empty.
    }else{
        $count++; //increment the counter by 1.
        //Update the value of an existing meta key (custom field) for the specified post.
        update_post_meta($post_ID, $count_key, $count);
         
        //If statement, is just to have the singular form 'View' for the value '1'
        if($count == '1'){
        return $count . ' View';
        }
        //In all other cases return (count) Views
        else {
        return $count . ' Views';
        }
    }
}

//below to enable the shortcode in genesis
add_filter( 'post_content', 'shortcode_unautop');
add_filter( 'post_content', 'do_shortcode');

// Modify comments header text in comments
add_filter( 'genesis_title_comments', 'child_title_comments');
function child_title_comments() {
    return __(comments_number( '<h3>No Responses</h3>', '<h3>1 Response</h3>', '<h3>% Responses...</h3>' ), 'genesis');
}
 
// Unset URL from comment form
function crunchify_move_comment_form_below( $fields ) { 
    $comment_field = $fields['comment']; 
    unset( $fields['comment'] ); 
    $fields['comment'] = $comment_field; 
    return $fields; 
} 
add_filter( 'comment_form_fields', 'crunchify_move_comment_form_below' ); 
 add_filter('comment_form_field_url', '__return_false');
 
// Add placeholder for Name and Email
function modify_comment_form_fields($fields){
   $fields['author'] = '<h5>Leave a reply</h5><div class="row"><div class="col-md-6">' . '<input class="form-control" id="author" placeholder="Your Name" name="author" type="text" value="' .
				esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' />'.
				( $req ? '<span class="required">*</span>' : '' )  .
				'</div>';
    $fields['email'] = '<div class="col-md-6">' . '<input class="form-control" id="email" placeholder="Your email address" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
				'" size="30"' . $aria_req . ' />'  .
				( $req ? '<span class="required">*</span>' : '' ) 
				 .
				'</div></div>';
	//$fields['comment'] = '<textarea id="comment" name="comment" placeholder="Your Comment here" cols="45" rows="1" aria-required="true"></textarea></form></div>';
    return $fields;
}
add_filter('comment_form_default_fields','modify_comment_form_fields');

//customizing the comment textarea
function wpsites_customize_comment_form_text_area($arg) {
 $arg['comment_field'] = '<textarea id="comment" name="comment" placeholder="Your Comment here" cols="45" rows="1" aria-required="true"></textarea>';
 return $arg;
}

add_filter('comment_form_defaults', 'wpsites_customize_comment_form_text_area');
//* Customize the comment respond title
add_filter( 'comment_form_defaults', 'bg_comment_respond_title' );
function bg_comment_respond_title( $defaults ) {
	$defaults['title_reply'] = __( '', 'bg' );
	return $defaults;
}

//* Customize the submit button text in comments
add_filter( 'comment_form_defaults', 'sp_comment_submit_button' );
function sp_comment_submit_button( $defaults ) {
$defaults['label_submit'] = __( 'SUBMIT', 'bg' );	
return $defaults;
}

function mytheme_comment($comment, $args, $depth) {
    if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li ';
        $add_below = 'div-comment';
    }?>
    <<?php echo $tag; comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID() ?>"><?php 
    if ( 'div' != $args['style'] ) { ?>
 
  <div id="user_comments">
  <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
<?php

	 genesis_markup( array(
	   
		'html5'   => '<div %s>',
		'context' => 'comment'
	) );
	   
	  ?> 
<?php
    } ?>
		<div class="comment-author">
	<?php 
		genesis_markup(array(
		'html5' => '<span %s>',
		'context' => 'comment-author'
		));
		?>
		<?php 
            if ( $args['avatar_size'] != 0 ) {
              //  echo get_avatar( $comment, $args['avatar_size'] );
echo '<img src="'. get_stylesheet_directory_uri().'/img/avatar/1-med.png"  alt=""> ';				
            } 
           printf( __( '<cite class="fn" itemprop="name">%s</cite> <span class="says">&nbsp;</span>' ), get_comment_author_link() );
		 ?>
		 <?php 
        genesis_markup(array(
		'close' => '</span>'

            ));		
      
		?>
	  <?php 
		genesis_markup(array(
		'html5' => '<div class="comment-meta commentmetadata" %s>',
		'context' => 'entry-time'
		));
		
		?> 
            <span href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>"><?php
                /* translators: 1: date, 2: time */
                printf( 
                    __('%1$s at %2$s'), 
                    get_comment_date('M j, Y'),  
                    get_comment_time() 
                ); ?>
            </span><?php 
            edit_comment_link( __( '(Edit)' ), '  ', '' ); ?>
					  <?php 
		genesis_markup(array(
		'close' => '</div>',
		
		));
		
		?> 
			</div>
		<?php 
        if ( $comment->comment_approved == '0' ) { ?>
            <em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.' ); ?></em><br/><?php 
        } ?>
      <span itemprop="text"> <?php comment_text(); ?> </span>
        <div class="comment-meta""><span> <i class="fa fa-reply"></i> <?php 
                comment_reply_link( 
                    array_merge( 
                        $args, 
                        array( 
						
                            'add_below' => $add_below, 
                            'depth'     => $depth, 
                            'max_depth' => $args['max_depth'] 
                        ) 
                    ) 
                ); ?>
        </span></div><?php 
    if ( 'div' != $args['style'] ) : ?>
	
       <?php 
	   genesis_markup(array (
	   'close' => '</div>'
	   ));
	   ?>
	   <?php

	 genesis_markup( array(
	   
		'close'   => '</div>',
	) );
	   
	  ?> 
	   
	   </div>
	   <?php
	   
    endif;
}
?>
<?php
// Replace h3 with h4 for all widget titles for footer
add_filter( 'genesis_register_sidebar_defaults', 'custom_register_sidebar_defaults' );
function custom_register_sidebar_defaults( $defaults ) {
	$defaults['before_title'] = '<h5 class="text-white">';
	$defaults['after_title'] = '</h5>';
	return $defaults;
}
//Insert SPAN tag into widgettitle  
add_filter( 'dynamic_sidebar_params', 'b3m_wrap_widget_titles', 20 );
function b3m_wrap_widget_titles( array $params ) {
        // $params will ordinarily be an array of 2 elements, we're only interested in the first element
		$widget =& $params[0];
       // $widget['before_title'] = '<div class="side-widget"><h4>';
        //$widget['after_title'] = '</h4>';
   
        return $params;
		
}
?>
<?php
add_theme_support( 'post-thumbnails' );   

		add_image_size( 'style4', 370, 230, true );
		add_image_size( 'style5', 509, 342, true );
		add_image_size( 'style51', 243, 243, true );
		//add_image_size( 'style2', 113, 70, true );
		add_image_size( 'style3', 236, 147, true );
		add_image_size( 'singlepage', 770, 379, true );
		add_image_size( 'homeslider', 1349, 390, true );
		add_image_size( 'hometop2', 776, 488, true );
		?>
<?php
// start of custom category widget code
class categorywidget extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'categorywidget', // Base ID
			'Theme Category Widget', // Name
			array('description' => __( 'To display category widget'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		
		$article = $instance['article'];
		$newsarticle = $instance['newsarticle'];
		$postcat = $instance['postcat'];
	
		
		//echo $before_widget;
		// Check if title is set
		
	
		
		$this->getRealtyListings($article,$newsarticle,$postcat,$title);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['article'] = strip_tags($new_instance['article']);
		$instance['newsarticle'] = strip_tags($new_instance['newsarticle']);
		$instance['postcat'] = strip_tags($new_instance['postcat']);
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$article = esc_attr($instance['article']);
		$newsarticle = esc_attr($instance['newsarticle']);
		$postcat = esc_attr($instance['postcat']);
		
		
	} else {
		$title = '';
		$article = '';
		$newsarticle = '';
		$postcat = '';
		
		
		
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'article' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'article' ) ); ?>" value="1" <?php checked( $instance['article'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'article' ) ); ?>"><?php _e( 'Show Article category', 'genesis' ); ?></label>
				</p>
			<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'newsarticle' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'newsarticle' ) ); ?>" value="1" <?php checked( $instance['newsarticle'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'newsarticle' ) ); ?>"><?php _e( 'Show News Article category', 'genesis' ); ?></label>
				</p>
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'postcat' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'postcat' ) ); ?>" value="1" <?php checked( $instance['postcat'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'postcat' ) ); ?>"><?php _e( 'Show Post category', 'genesis' ); ?></label>
				</p>
	<?php
	}

	function getRealtyListings($article,$newsarticle,$postcat,$title) { //html
		global $post;
	?>
		 <div class="side-widget">
		<h4><?php echo $title ?></h4>
		<ul id="toggle-view">
	<?php
	if($newsarticle)
	{?>
			<li>
	<?php
$taxonomy = 'newsarticlecategory';
$terms = get_terms($taxonomy); // Get all terms of a taxonomy

if ( $terms && !is_wp_error( $terms ) ) :
?>
  <h3>News Article</h3>
						<span class="fa fa-angle-up"></span>
						<div class="toggle-panel">
        <?php foreach ( $terms as $term ) { ?>
          <div>
		   <a class="category-menu" href="<?php echo get_term_link($term->slug, $taxonomy); ?>"><?php echo $term->name; ?></a>
		  </div>
		  
		  <?php } ?>
    
<?php endif;?>
						</div>
						
						
					</li>
					<?php
	}
	if($article)
	{
		?>
							<li>
				<?php
$taxonomy = 'articlecategory';
$terms = get_terms($taxonomy); // Get all terms of a taxonomy

if ( $terms && !is_wp_error( $terms ) ) :
?>
  <h3>Article</h3>
						<span class="fa fa-angle-up"></span>
						<div class="toggle-panel">
        <?php foreach ( $terms as $term ) { ?>
          <div>
		   <a class="category-menu" href="<?php echo get_term_link($term->slug, $taxonomy); ?>"><?php echo $term->name; ?></a>
		  </div>
		  
		  <?php } ?>
    
<?php endif;?>
</div>
</li>
		<?php
	}
	if($postcat)
	{
		?>
<li>
	<?php

$taxonomy = 'category';
$terms = get_terms($taxonomy); // Get all terms of a taxonomy

if ( $terms && !is_wp_error( $terms ) ) :
?>
  <h3>Post</h3>
						<span class="fa fa-angle-up"></span>
						<div class="toggle-panel">
        <?php foreach ( $terms as $term ) { ?>
          <div>
		   <a class="category-menu" href="<?php echo get_term_link($term->slug, $taxonomy); ?>"><?php echo $term->name; ?></a>
		  </div>
		  
		  <?php } ?>
    
<?php endif;?>
	</div>
	</li>
		<?php
	}
	?>
	</ul>
	</div>
	<?php
	}	
} 
register_widget('categorywidget');

/*end of custom category widget  */		
?>		
<?php
class style4posts extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'style4posts', // Base ID
			'style 4 posts', // Name
			array('description' => __( 'To display the posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		$posttype = $instance['posttype'];
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );


		$before_title = '<div class="side-widget"><h4>';
	   $after_title = '</h4>';
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}
		else
		{
			echo $before_title . $after_title;
		}
		
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		$posttype = esc_attr($instance['posttype']);
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		$posttype = '';
		
		
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>		
                 </p>						
			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$posttype) { //html
		global $post;
	
	
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	if($posttype == 'articlecategory' || $posttype == 'newsarticlecategory')
	{
	$listings = new WP_Query( array(
    'posts_per_page' => $posts_num,
	'offset'         => $posts_offset,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype,
            'field' => 'term_id',
            'terms' => $posts_cat
        )
    ),
) );
	}	
else{
	$listings = new WP_Query();
	$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
}
	if($listings->found_posts > 0) {
						
			?>
		<?php
			while ($listings->have_posts()) {
										
					$listings->the_post();
					
					?>
					<article class="style4">
							<a href="<?php echo get_the_permalink(); ?>" itemprop="url">
								<div class="overlay overlay-02"></div>
								<div class="post-thumb">
									<div class="small-title cat"><?php echo get_cat_name( $posts_cat ); ?></div>
									<div class="post-excerpt">
										<div class="meta">
											<span class="date" itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
										</div>
										<h3 class="text-white" itemprop="headline"><?php echo get_the_title(); ?></h3>
									</div>
									
					<?php
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					
	if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
}
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
}

			echo '</div>';
					echo '</a>';
					echo '</article>';	
					
				}
				?>
			</div>
				<div class="clearfix"></div>
				<?php
		
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('style4posts');

/*end of style 4 posts code */

/*most popular and recent comment posts */
class popular_post_widget extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'popular_post_widget', // Base ID
			'Popular post', // Name
			array('description' => __( 'Displays the popular & Most commented post'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		$title_recentcomment = $instance['title_recentcomment'];
		$title_popularpost = $instance['title_popularpost'];
		
		//echo $before_widget;
		$title = apply_filters( 'widget_title', $instance['title'] );


		$before_title = '<div class="side-widget"><h4>';
	   $after_title = '</h4>';
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}
		else
		{
			echo $before_title . $after_title;
		}
		
		$this->getRealtyListings($posts_num,$show_content,$content_limit,$more_text,$show_image,$title,$title_recentcomment,$title_popularpost);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		$instance['title_recentcomment'] = strip_tags($new_instance['title_recentcomment']);
		$instance['title_popularpost'] = strip_tags($new_instance['title_popularpost']);
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		$title_recentcomment = esc_attr($instance['title_recentcomment']);
		$title_popularpost = esc_attr($instance['title_popularpost']);
		
	} else {
		$title = '';
		$posts_num = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		$title_recentcomment = '';
		$title_popularpost = '';
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		
		<p>
		<label for="<?php echo $this->get_field_id('title_popularpost'); ?>"><?php _e('Title Popular Post', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title_popularpost'); ?>" name="<?php echo $this->get_field_name('title_popularpost'); ?>" type="text" value="<?php echo $title_popularpost; ?>" />
		</p>
		
		<p>
		<label for="<?php echo $this->get_field_id('title_recentcomment'); ?>"><?php _e('Title Recent Comment Post', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title_recentcomment'); ?>" name="<?php echo $this->get_field_name('title_recentcomment'); ?>" type="text" value="<?php echo $title_recentcomment; ?>" />
		</p>
		
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>

	
			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
				

			<?php
	
	}

	function getRealtyListings($posts_num,$show_content,$content_limit,$more_text,$show_image,$title,$title_recentcomment,$title_popularpost) { //html
		global $post;
	
if ( empty( $posts_num ) ) {
	$posts_num = 1;
	
	}
		
	$listings = new WP_Query( array(
	'post_type' =>array('post','article','newsarticle'),
	'meta_key' =>  'post_views_count',
	'orderby' => 'meta_value_num',
	'order' => 'DESC',
    'posts_per_page' => $posts_num
	
   ) );
		
	//	$listings = new WP_Query();
	//	$listings->query('post_type=newsarticle&meta_key=post_views_count&orderby=meta_value_num&order=DESC&posts_per_page=' . $posts_num);	
			
		if($listings->found_posts > 0) {
	?>
						<div role="tabpanel">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs nav-justified" role="tablist">
								<li role="presentation" class="active">
									<a href="#popular" aria-controls="popular" role="tab" data-toggle="tab"><?php echo $title_popularpost; ?></a>
								</li>
								<li role="presentation">
									<a href="#commented" aria-controls="commented" role="tab" data-toggle="tab"><?php echo $title_recentcomment; ?></a>
								</li>
								
							</ul>
							<!-- Tab panes -->
							<div class="tab-content">
							<div role="tabpanel" class="tab-pane active fade in" id="popular">
							<?php
							
							$i = 0;
							while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					
					if($i ==0)
					{
					
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
	
$category = get_the_category();
$firstCategory = $category[0]->cat_name;

				
				?>
					<article class="style4">
										<a href="<?php echo the_permalink(); ?>" itemprop="url">
											<div class="overlay overlay-02"></div>
											<div class="post-thumb">
												<div class="small-title cat"><?php echo $firstCategory; ?></div>
												<div class="post-excerpt">
													<div class="meta">
														<span class="date" itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
													</div>
													<h3 class="text-white" itemprop="headline"><?php echo the_title();?></h3>
												</div>
												<?php 
												genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
		?>
											</div>
										</a>
									</article>
			<?php
			
		}
		
		?>
		<?php
	
		if($i ==1)
		{
			?>
			<div class="mini-posts">	
					<article class="style2">
											<div class="row">
														<?php
														if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			echo '<div class="col-md-4 col-sm-4">';
		echo '<a href="'.get_the_permalink().'" itemprop="url">';
			
	echo '<div class="article-thumb">';
		
		genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
		

		
	
		echo '</div></a></div>';
	
		}
														?>
												<div class="col-md-8 col-sm-8">
													<div class="post-excerpt no-padding">
														<div class="meta">
															<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
														</div>
														<h5><a href="<?php echo the_permalink(); ?>" itemprop="headline"><?php the_title();?></a></h5>
													</div>
												</div>
											</div>
											<?php
											
											echo '<p>';	
					
					
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
	echo '</p>';
											
											?>
										</article>
			<?php
		}
				
				if($i !=0 && $i !=1)
		{
			?>
			<article class="style2">
		<div class="row">
				<?php
														if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			echo '<div class="col-md-4 col-sm-4">';
		echo '<a href="'.get_the_permalink().'" itemprop="url">';
			
	echo '<div class="article-thumb">';
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
	echo '</div></a></div>';
	
		}
														?>
												<div class="col-md-8 col-sm-8">
													<div class="post-excerpt no-padding">
														<div class="meta">
															<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
														</div>
														<h5><a href="<?php echo the_permalink(); ?>" itemprop="headline"><?php the_title();?></a></h5>
													</div>
												</div>
											</div>
											<?php
											
											echo '<p>';	
					
					
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
	echo '</p>';
											
											?>
										</article>
				<?php
		}	

				$i++;
							}
							wp_reset_query();
							?>
								</div>		
								</div>
								<div role="tabpanel" class="tab-pane fade in" id="commented">
								<?php
							
							$i = 0;
						
                	$listings1 = new WP_Query( array(
	'post_type' =>array('post','article','newsarticle'),
	//'meta_key' =>  'post_views_count',
	'orderby' => 'comment_count',
	'order' => 'DESC',
    'posts_per_page' => $posts_num
	) );

						
							//$listings1 = new WP_Query();
		//$listings1->query('post_type=newsarticle&orderby=comment_count&meta_value_num&order=DESC&posts_per_page=' . $posts_num);	
							
							while ($listings1->have_posts() && $i<$posts_num) {
					
					
					
					$listings1->the_post();
					
					if($i ==0)
					{
					
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
				
$category = get_the_category();
$firstCategory = $category[0]->cat_name;
				
				?>
					<article class="style4">
										<a itemprop="url" href="<?php echo the_permalink(); ?>">
											<div class="overlay overlay-02"></div>
											<div class="post-thumb">
												<div class="small-title cat"><?php echo $firstCategory; ?></div>
												<div class="post-excerpt">
													<div class="meta">
														<span class="date" itemprop="datePublished"><?php echo the_date('M j, Y'); ?></span>
													</div>
													<h3 class="text-white" itemprop="headline"><?php the_title();?></h3>
												</div>
												<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
												
											</div>
										</a>
									</article>
				<?php
				
				
		}
		
		?>
		<?php
	
		
		if($i ==1)
		{
			?>
			<div class="mini-posts">	
					<article class="style2">
											<div class="row">
											<?php
														if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			echo '<div class="col-md-4 col-sm-4">';
		echo '<a href="'.get_the_permalink().'" itemprop="url">';
			
	echo '<div class="article-thumb">';
		

	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
	
	
		echo '</div></a></div>';
	
		}
														?>
												<div class="col-md-8 col-sm-8">
													<div class="post-excerpt no-padding">
														<div class="meta">
															<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
														</div>
														<h5 itemprop="headline"><a href="<?php echo the_permalink(); ?>"><?php the_title();?></a></h5>
													</div>
												</div>
											</div>
											<?php
											
											echo '<p>';	
					
					
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
	echo '</p>';
											
											?>
										</article>
			<?php
		}
				
				
				if($i !=0 && $i !=1)
		{
			?>
					<article class="style2">
											<div class="row">
														<?php
														if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			echo '<div class="col-md-4 col-sm-4">';
		echo '<a href="'.get_the_permalink().'" itemprop="url">';
			
	echo '<div class="article-thumb">';
 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
		
	
		echo '</div></a></div>';
	
		}
														?>
												<div class="col-md-8 col-sm-8">
													<div class="post-excerpt no-padding">
														<div class="meta">
															<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
														</div>
														<h5 itemprop="headline"><a href="<?php echo the_permalink(); ?>"><?php the_title();?></a></h5>
													</div>
												</div>
											</div>
											<?php
											
											echo '<p>';	
					
					
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
	echo '</p>';
											
											?>
										</article>
			<?php
		}	

				$i++;
							}
							
							?>
							</div>		
								</div>
							</div>
						</div>
						<!-- TABS -->
	<?php
		}
	}	
}
register_widget('popular_post_widget');
 /*end of most popular and recent comment posts */


 
 /* code for home page starts here */
 
 
 //home slider code
 
 class homeslider extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homeslider', // Base ID
			'Home slider', // Name
			array('description' => __( 'To display the home slider'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$posttype = $instance['posttype'];

		
		//echo $before_widget;
		// Check if title is set
		$title = apply_filters( 'widget_title', $instance['title'] );
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);

		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$posttype = esc_attr($instance['posttype']);

		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$posttype = '';

	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
                 <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>
                 </p>					
				
	<?php
	
	}
	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$posttype) { //html
		global $post;
	
		
	if ( empty( $posts_num ) ) {
	$posts_num = 1;
	
	}
//$catinfo = get_term_by( 'id',$posts_cat, 'article' );
//print $catinfo->slug;
	
	if($posttype == 'articlecategory' || $posttype == 'newsarticlecategory')
	{
	$listings = new WP_Query( array(
    'posts_per_page' => $posts_num,
	'offset'         => $posts_offset,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype,
            'field' => 'term_id',
            'terms' => $posts_cat
        )
    ),
) );
	}	
else{
	$listings = new WP_Query();
	$posts_cat = get_cat_name( $posts_cat ); 
	$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
}
		
		if($listings->found_posts > 0) {

			?>
		<div class="container-fluid no-padding">
		<div class="home-slider-wrap">
		<div class="home-slider">
		<?php

				while ($listings->have_posts()) {

					$listings->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'homeslider' ); 
							
								$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					
					?>
						<div>
			<article class="style3 single text-center no-margin">
					<div class="overlay overlay-02"></div>
					<div class="post-thumb">
						<div class="container">
						<div class="post-excerpt">
							<div class="small-title cat"><?php echo get_cat_name( $posts_cat ); ?></div>

							<a itemprop="url" href="<?php echo get_the_permalink(); ?>"><h1 class="h1 text-white" itemprop="headline"><?php echo get_the_title(); ?></h1></a>
							<div class="meta">
								<span class="author"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/avatar/1.jpg" class="img-circle" alt=""> by <?php echo $display_name ?></span>
								<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
							</div>
							<div class="meta">
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
								<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
							</div>

						</div>
						</div>
						<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
					</div>
			</article>
		</div>
				<?php	
	
					
				}
				?>
			</div>
		<div class="hs-prev"><i class="fa fa-angle-left"></i></div>
		<div class="hs-next"><i class="fa fa-angle-right"></i></div>
		</div>
	</div>
				<?php
		
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homeslider');

/*end of slider code */

 ?>
  <?php
  //home top 1 code
 
 class hometop1 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'hometop1', // Base ID
			'Home Top 1', // Name
			array('description' => __( 'To display the home posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_cat1 = $instance['posts_cat1'];
		$posts_cat2 = $instance['posts_cat2'];
		$posts_offset1 = $instance['posts_offset1'];
		$posts_offset2 = $instance['posts_offset2'];
		$posttype1 = $instance['posttype1'];
		$posttype2 = $instance['posttype2'];

		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );



		
		
		$this->getRealtyListings($posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$posttype1,$posttype2);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_cat1'] = strip_tags($new_instance['posts_cat1']);
		$instance['posts_cat2'] = strip_tags($new_instance['posts_cat2']);
		$instance['posts_offset1'] = strip_tags($new_instance['posts_offset1']);
		$instance['posts_offset2'] = strip_tags($new_instance['posts_offset2']);
		$instance['posttype1'] = strip_tags($new_instance['posttype1']);
		$instance['posttype2'] = strip_tags($new_instance['posttype2']);

		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_cat1 = esc_attr($instance['posts_cat1']);
		$posts_cat2 = esc_attr($instance['posts_cat2']);
		$posts_offset1 = esc_attr($instance['posts_offset1']);
		$posts_offset2 = esc_attr($instance['posts_offset2']);
		$posttype1 = esc_attr($instance['posttype1']);
		$posttype2 = esc_attr($instance['posttype2']);

		
	} else {
		$title = '';
		$posts_cat1 = '';
		$posts_cat2 = '';
		$posts_offset1 = '';
		$posts_offset2 = '';
		$posttype1 = '';
		$posttype2 = '';

		
		
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		
	<fieldset style="border: 1px solid #ccc;padding: 10px;">
	<legend> Section 1</legend>

		
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset1' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset1'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat1' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat1' ),
						'id'              => $this->get_field_id( 'posts_cat1' ),
						'selected'        => $instance['posts_cat1'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
                 <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype1' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype1' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype1'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype1'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype1'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>
                 </p>					
			</fieldset>	
			<fieldset style="border: 1px solid #ccc;padding: 10px;">
	<legend> Section 2</legend>

		
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset2' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset2'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat2' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat2' ),
						'id'              => $this->get_field_id( 'posts_cat2' ),
						'selected'        => $instance['posts_cat2'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
                 <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype2' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype2' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype2'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype2'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype2'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>
                 </p>					
			</fieldset>	
	<?php
	
	}
	

	function getRealtyListings($posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$posttype1,$posttype2) { //html
		global $post;
	
	?>
	<div class="bg-dark">
	<div class="container">
		<div class="space60"></div>
		<div class="row">
		<?php
	
	if ( empty( $posts_num ) ) {
	$posts_num = 1;
	
	}

	
	if($posttype1 == 'articlecategory' || $posttype1 == 'newsarticlecategory')
	{
		$posts_num = 1;
	$listings1 = new WP_Query( array(
    'posts_per_page' => $posts_num,
	'offset'         => $posts_offset1,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype1,
            'field' => 'term_id',
            'terms' => $posts_cat1
        )
    ),
) );
	}	
else{
	$posts_num = 1;
	$listings1 = new WP_Query();
	$listings1->query('post_type=post&cat='.$posts_cat1.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset1);
}
		
		if($listings1->found_posts > 0) {

			?>
		<?php

				while ($listings1->have_posts()) {

					$listings1->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'singlepage' ); 
							
								$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					
					?>
					<div class="col-md-6">
				<article class="style3 article-home">
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">
							<div class="small-title cat"><?php echo get_cat_name( $posts_cat1 ); ?></div>
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h1 itemprop="headline" class="h1 text-white"><?php echo get_the_title(); ?></h1>
								<div class="meta">
									<span class="author"><img src="<?php echo get_stylesheet_directory_uri();?>/img/avatar/1.jpg" class="img-circle" alt=""> by <?php echo $display_name ?></span>
									<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
									<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
								</div>
							</div>
													<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
				
			</div>
			<?php	
	
					
				}
					
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found 1</p>';
		}




if($posttype2 == 'articlecategory' || $posttype2 == 'newsarticlecategory')
	{
		$posts_num = 4;
	$listings2 = new WP_Query( array(
    'posts_per_page' => $posts_num,
	'offset'         => $posts_offset2,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype2,
            'field' => 'term_id',
            'terms' => $posts_cat2
        )
    ),
) );
	}	
else{
	$posts_num = 4;
	$listings2 = new WP_Query();
	$listings2->query('post_type=post&cat='.$posts_cat2.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset2);
}
		
		if($listings2->found_posts > 0) {

			?>
		<?php
$i=0;
				while ($listings2->have_posts() && $i<$posts_num) {

					$listings2->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
							
								$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					?>
					<div class="col-md-3 col-sm-6">
					<?php
					if($i==0)
					{
						?>
							<article class="style4">
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">
							<div class="small-title cat"><?php echo get_cat_name( $posts_cat2 ); ?></div>
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
							</div>
																				<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
						
						<?php
					}
					if($i==1)
					{
					?>
		      						<article class="style4">
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">
							<div class="small-title cat"><?php echo get_cat_name( $posts_cat2 ); ?></div>
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
							</div>
<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
				
					
					<?php
					}
		          ?>
				  </div>
					<div class="col-md-3 col-sm-6">
					<?php
					if($i==2)
					{
						?>
						<article class="style4">
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">
							<div class="small-title cat"><?php echo get_cat_name( $posts_cat2 ); ?></div>
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
							</div>
																				<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
				<?php
					}
					if($i==3)
					{
					?>
		   						<article class="style4">
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">
							<div class="small-title cat"><?php echo get_cat_name( $posts_cat2 ); ?></div>
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
							</div>
																				<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
				 <?php
					}
		          ?>
				 </div>
		<?php
		$i++;
				}
		wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		}
				?>
		</div>
		<div class="space50"></div>
	</div>
</div>
<?php		
	}
	
} 
register_widget('hometop1');

/*end of home top 1 code */

 ?>
 <?php
 // Home top 2 code
 
 class hometop2 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'hometop2', // Base ID
			'Home Top 2', // Name
			array('description' => __( 'To display the home posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_cat1 = $instance['posts_cat1'];
		$posts_cat2 = $instance['posts_cat2'];
		$posts_offset1 = $instance['posts_offset1'];
		$posts_offset2 = $instance['posts_offset2'];
		$posttype1 = $instance['posttype1'];
		$posttype2 = $instance['posttype2'];

		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );

		
		$this->getRealtyListings($posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$posttype1,$posttype2);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_cat1'] = strip_tags($new_instance['posts_cat1']);
		$instance['posts_cat2'] = strip_tags($new_instance['posts_cat2']);
		$instance['posts_offset1'] = strip_tags($new_instance['posts_offset1']);
		$instance['posts_offset2'] = strip_tags($new_instance['posts_offset2']);
		$instance['posttype1'] = strip_tags($new_instance['posttype1']);
		$instance['posttype2'] = strip_tags($new_instance['posttype2']);

		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_cat1 = esc_attr($instance['posts_cat1']);
		$posts_cat2 = esc_attr($instance['posts_cat2']);
		$posts_offset1 = esc_attr($instance['posts_offset1']);
		$posts_offset2 = esc_attr($instance['posts_offset2']);
		$posttype1 = esc_attr($instance['posttype1']);
		$posttype2 = esc_attr($instance['posttype2']);

		
	} else {
		$title = '';
		$posts_cat1 = '';
		$posts_cat2 = '';
		$posts_offset1 = '';
		$posts_offset2 = '';
		$posttype1 = '';
		$posttype2 = '';

		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		
	<fieldset style="border: 1px solid #ccc;padding: 10px;">
	<legend> Section 1</legend>

		
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset1' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset1'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat1' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat1' ),
						'id'              => $this->get_field_id( 'posts_cat1' ),
						'selected'        => $instance['posts_cat1'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
                 <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype1' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype1' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype1'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype1'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype1'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>
                 </p>					
			</fieldset>	
			<fieldset style="border: 1px solid #ccc;padding: 10px;">
	<legend> Section 2</legend>

		
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset2' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset2'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat2' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat2' ),
						'id'              => $this->get_field_id( 'posts_cat2' ),
						'selected'        => $instance['posts_cat2'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
                 <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype2' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype2' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype2'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype2'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype2'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>
                 </p>					
			</fieldset>	
	<?php
	
	}
	

	function getRealtyListings($posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$posttype1,$posttype2) { //html
		global $post;
	
	?>
	<div class="container">
	<div class="row">
		<?php
	
	if ( empty( $posts_num ) ) {
	$posts_num = 1;
	
	}

	
	if($posttype1 == 'articlecategory' || $posttype1 == 'newsarticlecategory')
	{
		$posts_num = 1;
	$listings1 = new WP_Query( array(
    'posts_per_page' => $posts_num,
	'offset'         => $posts_offset1,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype1,
            'field' => 'term_id',
            'terms' => $posts_cat1
        )
    ),
) );
	}	
else{
	$posts_num = 1;
	$listings1 = new WP_Query();
	$listings1->query('post_type=post&cat='.$posts_cat1.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset1);
}
		
		if($listings1->found_posts > 0) {

			?>
		<?php

				while ($listings1->have_posts()) {

					$listings1->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'hometop2' ); 
							
								$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					
					?>
						<div class="col-md-8 col-sm-8">
					<article class="style3 style-alt">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="overlay overlay-02"></div>
							<div class="post-thumb">
								<div class="small-title cat"><?php echo get_cat_name( $posts_cat1 ); ?></div>
								<div class="post-excerpt">
									<div class="meta">
										<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h1 itemprop="headline" class="h1 text-white"><?php echo get_the_title(); ?></h1>
									<div class="meta">
										<span class="author"><img src="<?php echo get_stylesheet_directory_uri();?>/img/avatar/1.jpg" class="img-circle" alt=""> by <?php echo $display_name ?></span>
										<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
										<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
									</div>
								</div>
																					<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
							</div>
						</a>
					</article>
				</div>	
				<?php	
	
				}
					
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found 1</p>';
		}


if($posttype2 == 'articlecategory' || $posttype2 == 'newsarticlecategory')
	{
		$posts_num = 2;
	$listings2 = new WP_Query( array(
    'posts_per_page' => $posts_num,
	'offset'         => $posts_offset2,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype2,
            'field' => 'term_id',
            'terms' => $posts_cat2
        )
    ),
) );
	}	
else{
	$posts_num = 2;
	$listings2 = new WP_Query();
	$listings2->query('post_type=post&cat='.$posts_cat2.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset2);
}
		?>
		<div class="col-md-4 col-sm-4">
		<?php
		if($listings2->found_posts > 0) {

			?>
		<?php
      		while ($listings2->have_posts() && $i<$posts_num) {

					$listings2->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'hometop2' ); 
							
								$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					?>
					<article class="style4 style-alt margin-bottom-10">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="overlay overlay-02"></div>
							<div class="post-thumb">
								<div class="small-title cat"><?php echo get_cat_name( $posts_cat2 ); ?></div>
								<div class="post-excerpt">
									<div class="meta">
										<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
								</div>
						<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
							</div>
						</a>
					</article>
<?php
		
				}
		wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		}
				?>
		</div>
		</div>
		</div>
<?php		
	}
	
} 
register_widget('hometop2');

/*end of home top 2 code */

 ?>
 <?php
 /* Home style 1 section */

class homestyle1 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle1', // Base ID
			'Home style 1', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		$posttype = $instance['posttype'];
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$title,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		$posttype = esc_attr($instance['posttype']);
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		$posttype = '';
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
		  <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>		
                 </p>		

			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
	<?php
	
	}
	
	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$title,$posttype) { //html
		global $post;
	

	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
			if($posttype == 'articlecategory' || $posttype == 'newsarticlecategory')
	{
	$listings = new WP_Query( array(
    
	'posts_per_page' => $posts_num,
	'offset'         => $posts_offset,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype,
            'field' => 'term_id',
            'terms' => $posts_cat
        )
    ),
) );
	}	
else{
	$listings = new WP_Query();
	$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);	
}
		
		if($listings->found_posts > 0) {
		
			?>

			<!-- HOME SECTION 1 -->
			<div class="padding-top-60">
				<h3 class="margin-bottom-15"><b><?php echo $title; ?></b></h3>
				<div class="row">
		<?php
			
		$i=0;;
				while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					
					
					if($i==0)
					{
						
						
					?>
									<div class="col-md-6">
						<article class="article-home style-alt">
								<?php
				
					
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
		?>
			<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
								<div class="article-thumb">
			<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
								</div>
							</a>
							<div class="post-excerpt">
								<div class="small-title cat"><?php echo get_cat_name( $posts_cat ); ?></div>
								<h4 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
								<div class="meta">
									<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
                                      if ( empty( $display_name ) )
                                      $display_name = get_the_author_meta( 'nickname', $post->post_author );
                                          echo $display_name?></a></span>
									<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
									<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
								</div>
								
								
								<p>
								<?php
								
									if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}

?>
								</p>
							</div>
						</article>
					</div>	
	<div class="col-md-6">
						<div class="mini-posts">
				<?php	
				}
				?>
				<?php
		
		
			if($i != 0)
		{
		?>
					<article class="style2 style-alt">
								<div class="row">
					<?php
				
					
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
		?>
			<div class="col-md-4 col-sm-4">
										<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
											<div class="article-thumb">
											<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
			
?>
											</div>
										</a>
									</div>
		<?php
	
		}
			
			
				?>
									<div class="col-md-8 col-sm-8">
										<div class="post-excerpt no-padding">
											<div class="meta">
												<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
											</div>
											<h5 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
											<div class="meta">
												<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
											</div>
										</div>
									</div>
								</div>
							</article>
<?php		
			
		}
		
		$i++;
		
		
				}
		?>
		</div>
		</div>
		</div>
			</div>
		<?php
		
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homestyle1');

/*end of Home style 1 section  */

 
 /* start of home style 2 section */
class homestyle2 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle2', // Base ID
			'Home style 2', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$posttype = $instance['posttype'];
		
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$title,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$posttype = esc_attr($instance['posttype']);
		
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$posttype = '';
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
				 <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>		
                 </p>

			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$title,$posttype) { //html
		global $post;
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
		if($posttype == 'articlecategory' || $posttype == 'newsarticlecategory')
	{
	$listings = new WP_Query( array(
    'posts_per_page' => $posts_num,
	'offset'         => $posts_offset,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype,
            'field' => 'term_id',
            'terms' => $posts_cat
        )
    ),
) );
	}	
else{
	$listings = new WP_Query();
	$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
}
		
		
		if($listings->found_posts > 0) {
			
			
			?>
		<!-- HOME SECTION 2 -->
			<h4 class="margin-bottom-15"><b><?php echo $title; ?></b></h4>
			<div class="row padding-bottom-30">
		<?php
			
					while ($listings->have_posts()) {
										
					$listings->the_post();
					$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
				

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
					?>
					<div class="col-md-4 col-sm-4">
						<article class="style2 style-alt">
							<div class="margin-bottom-15">
								<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
									<div class="article-thumb">
								<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
			
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
								</a>
							</div>
							<div>
								<div class="post-excerpt no-padding">
									<div class="meta">
										<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h5 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
									<p>
									<?php 
												if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
									
									?>
									</p>
								</div>
							</div>
						</article>
					</div>
				<?php	
					
		
				}
				?>
			</div>
			<?php
		
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homestyle2');

/*end of Home style 2 section code */

 
 
 
 /*start of Home style 3 section code */
 
 class homestyle3 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle3', // Base ID
			'Home style 3', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		
		
		$title1 = $instance['title1'];
		$title2 = $instance['title2'];
		
		$posts_num = $instance['posts_num'];
		
		$posts_cat1 = $instance['posts_cat1'];
		$posts_cat2 = $instance['posts_cat2'];
		
		$posts_offset1 = $instance['posts_offset1'];
		$posts_offset2 = $instance['posts_offset2'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		$select_design = $instance['select_design'];
		$posttype1 = $instance['posttype1'];
		$posttype2 = $instance['posttype2'];
		
		//echo $before_widget;
		// Check if title is set
		
		$this->getRealtyListings($title1,$title2,$posts_num,$posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$show_content,$content_limit,$more_text,$show_image,$select_design,$posttype1,$posttype2);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		
		$instance['title1'] = strip_tags($new_instance['title1']);
		$instance['title2'] = strip_tags($new_instance['title2']);
		
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		
		$instance['posts_cat1'] = strip_tags($new_instance['posts_cat1']);
		$instance['posts_cat2'] = strip_tags($new_instance['posts_cat2']);
		
		$instance['posts_offset1'] = strip_tags($new_instance['posts_offset1']);
		$instance['posts_offset2'] = strip_tags($new_instance['posts_offset2']);
		
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		$instance['select_design'] = strip_tags($new_instance['select_design']);
		$instance['posttype1'] = strip_tags($new_instance['posttype1']);
		$instance['posttype2'] = strip_tags($new_instance['posttype2']);
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title1 = esc_attr($instance['title1']);
		$title2 = esc_attr($instance['title2']);
		$posts_num = esc_attr($instance['posts_num']);
		
		$posts_cat1 = esc_attr($instance['posts_cat1']);
		$posts_cat2 = esc_attr($instance['posts_cat2']);
		
		$posts_offset1 = esc_attr($instance['posts_offset1']);
		$posts_offset2 = esc_attr($instance['posts_offset2']);
		
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		$select_design = esc_attr($instance['select_design']);
		$posttype1 = esc_attr($instance['posttype1']);
		$posttype2 = esc_attr($instance['posttype2']);
		
	} else {
		$title1 = '';
		$title2 = '';
		
		$posts_num = '';
		
		$posts_cat1 = '';
		$posts_cat2 = '';
		
		$posts_offset1 = '';
		$posts_offset2 = '';
		
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		$select_design = '';
		$posttype1 = '';
		$posttype2 = '';
		
		
		
		
	}
	?>
<fieldset style="border: 1px solid #ccc;padding: 10px;">
  <legend>Section 1:</legend>
 <p>
		<label for="<?php echo $this->get_field_id('title1'); ?>"><?php _e('Title ', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title1'); ?>" name="<?php echo $this->get_field_name('title1'); ?>" type="text" value="<?php echo $title1; ?>" />
		</p>
  <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>"><?php _e( 'Number of Posts to Offset ', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset1' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset1'] ); ?>" size="2" />
				</p>
  <p>
						<label for="<?php echo $this->get_field_id( 'posts_cat1' ); ?>"><?php _e( 'Category '); ?>:</label>
					<?php
					$categories_args1 = array(
						'name'            => $this->get_field_name( 'posts_cat1' ),
						'id'              => $this->get_field_id( 'posts_cat1' ),
						'selected'        => $instance['posts_cat1'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args1 ); ?>
				</p>
				   <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype1' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype1' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype1'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype1'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype1'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>		
                 </p>	
 </fieldset>
	
<fieldset style="border: 1px solid #ccc;padding: 10px;">
  <legend>Section 2:</legend>	
	<p>
		<label for="<?php echo $this->get_field_id('title2'); ?>"><?php _e('Title ', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title2'); ?>" name="<?php echo $this->get_field_name('title2'); ?>" type="text" value="<?php echo $title2; ?>" />
		</p>
	
					<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>"><?php _e( 'Number of Posts to Offset ', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset2' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset2'] ); ?>" size="2" />
				</p>
				
				
				
				
				<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat2' ); ?>"><?php _e( 'Category '); ?>:</label>
					<?php
					$categories_args2 = array(
						'name'            => $this->get_field_name( 'posts_cat2' ),
						'id'              => $this->get_field_id( 'posts_cat2' ),
						'selected'        => $instance['posts_cat2'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args2 ); ?>
				</p>
				   <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype2' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype2' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype2'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype2'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype2'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>		
                 </p>	
				
 </fieldset>	
		<fieldset style="border: 1px solid #ccc;padding: 10px;">
  <legend>Other Options:</legend>	
	
			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'select_design' ) ); ?>"><?php _e( 'Design Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'select_design' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'select_design' ) ); ?>">
						<option value="design1" <?php selected( 'design1', $instance['select_design'] ); ?>><?php _e( 'design1', 'genesis' ); ?></option>
						<option value="design2" <?php selected( 'design2', $instance['select_design'] ); ?>><?php _e( 'design2', 'genesis' ); ?></option>
			
					</select>
				
				</p>
		<p>

			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				
		</p>
			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
			 </fieldset>		
	<?php
	
	}

	function getRealtyListings($title1,$title2,$posts_num,$posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$show_content,$content_limit,$more_text,$show_image,$select_design,$posttype1,$posttype2) { //html
		global $post;
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
	?>
		<!-- HOME SECTION 3 -->
			<div class="row">
<?php
	
	
		if($posttype1 == 'articlecategory' || $posttype1 == 'newsarticlecategory')
	{
	$listings1 = new WP_Query( array(
    
	'posts_per_page' => $posts_num,
	'offset'         => $posts_offset1,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype1,
            'field' => 'term_id',
            'terms' => $posts_cat1
        )
    ),
) );
	}	
else{
	$listings1 = new WP_Query();
	$listings1->query('post_type=post&cat='.$posts_cat1.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset1);	
}
		
		
		if($listings1->found_posts > 0) {
			
			
			?>
					<div class="col-md-6 col-sm-6">
					<h4 class="margin-bottom-15"><b><?php echo $title1 ?></b></h4>
		<?php
			
	
	
	$i = 0;
	
				while ($listings1->have_posts() && $i<$posts_num) {
										
					$listings1->the_post();
					
					$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 			
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
					
					
					if($i == 0)
					{
						if($select_design == 'design1')
						{
					?>
				
				<article class="article-home style-alt margin-bottom-10">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="article-thumb">
							<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
	
					
?>
							</div>
						</a>
						<div class="post-excerpt">
							<div class="small-title cat"><?php echo get_cat_name( $posts_cat1 ); ?></div>
							<h4 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
							<div class="meta">
								<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name;
?></a></span>
								<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
							</div>
							<p>
							<?php 
							
										if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
					?>
							</p>
						</div>
					</article>
						<?php
						}
						if($select_design == 'design2')
						{
							?>
							<article class="style4 style-alt margin-bottom-10">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="overlay overlay-02 wow fadeIn" style="visibility: visible; animation-name: fadeIn;"></div>
							<div class="post-thumb wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
								<div class="small-title cat wow fadeIn" style="visibility: visible; animation-name: fadeIn;"><?php echo get_cat_name( $posts_cat1 ); ?></div>
								<div class="post-excerpt wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
									<div class="meta wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
										<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
								</div>
								<img src="<?php echo $image[0]; ?>" class="img-full" alt="">
							</div>
						</a>
					</article>
							<?php
						}
						?>
			<div class="mini-posts">				
				<?php	
					}
					if($i != 0)
					{
						
						if ( !$show_image && $image ) 
						{
						?>
						<style>
						article.article-home.style-alt.margin-bottom-10
						{
							margin-bottom:-10px !important;
						}
						</style>
						<a itemprop="url" class="list-posts-custom" href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
						
					<?php
					
					}
					

					if ($show_image && $image ) 
					{
						
					?>
							<article class="style2 style-alt">
							<div class="row">
								
								<?php
									if ( $show_image && $image ) {
			

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
			
		?>
			<div class="col-md-4 col-sm-4">
									<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
										<div class="article-thumb">
										
										<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
				
?>
										</div>
									</a>
								</div>					
	<?php
	
		}
			?>					
								<div class="col-md-8 col-sm-8">
									<div class="post-excerpt no-padding">
										<div class="meta">
											<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
										</div>
										<h5 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
										<div class="meta">
											<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
										</div>
									</div>
								</div>
							</div>
						</article>
				<?php	
					}
					}
				$i ++;
				}
				?>
				</div>
			</div>
				
				<?php
		
			wp_reset_postdata(); 
		}
		
		else{
			echo '<p style="padding:25px;">No listing found</p>';
	
	} 
	
	?>
	<?php
	
	///this is section 2 code
		if($posttype2 == 'articlecategory' || $posttype2 == 'newsarticlecategory')
	{
	$listings2 = new WP_Query( array(
    'posts_per_page' => $posts_num,
	'offset'         => $posts_offset2,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype2,
            'field' => 'term_id',
            'terms' => $posts_cat2
        )
    ),
) );
}	
else{
	$listings2 = new WP_Query();
	$listings2->query('post_type=post&cat='.$posts_cat2.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset2);	
}	
		
		if($listings2->found_posts > 0) {
			
			
			?>
					<div class="col-md-6 col-sm-6">
					<h4 class="margin-bottom-15"><b><?php echo $title2 ?></b></h4>
		<?php
			
	
	
	$i = 0;
	
				while ($listings2->have_posts() && $i<$posts_num) {
										
					$listings2->the_post();
					
					$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 			
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
					
					
					if($i == 0)
					{
						if($select_design == 'design1')
						{
					?>
				
							
									<article class="article-home style-alt margin-bottom-10">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="article-thumb">
							
							<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
					</div>
						</a>
						<div class="post-excerpt">
							<div class="small-title cat"><?php echo get_cat_name( $posts_cat2 ); ?></div>
							<h4 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
							<div class="meta">
								<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name;
?></a></span>
								<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
							</div>
							<p>
							<?php 
							
										if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
							
							
							?>
							</p>
						</div>
					</article>	
						<?php
						}
						if($select_design == 'design2')
						{
							?>
							<article class="style4 style-alt margin-bottom-10">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="overlay overlay-02 wow fadeIn" style="visibility: visible; animation-name: fadeIn;"></div>
							<div class="post-thumb wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
								<div class="small-title cat wow fadeIn" style="visibility: visible; animation-name: fadeIn;"><?php echo get_cat_name( $posts_cat2 ); ?></div>
								<div class="post-excerpt wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
									<div class="meta wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
										<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
								</div>
								<img src="<?php echo $image[0]; ?>" class="img-full" alt="">
							</div>
						</a>
					</article>
							<?php
						}
						?>
					
					<div class="mini-posts">				
				<?php	
					}
					if($i != 0)
					{
						
						if ( !$show_image && $image ) 
						{
						?>
						<style>
						article.article-home.style-alt.margin-bottom-10
						{
							margin-bottom:-10px !important;
						}
						</style>
						<a class="list-posts-custom" href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
					<?php
					
					}
					

					if ($show_image && $image ) 
					{
						
					?>
							<article class="style2 style-alt">
							<div class="row">
								
								<?php
									if ( $show_image && $image ) {
			

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
			
		?>
			<div class="col-md-4 col-sm-4">
									<a href="<?php echo get_the_permalink(); ?>">
										<div class="article-thumb">
										<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
							</div>
									</a>
								</div>					
	<?php
	
		}
			?>					
								<div class="col-md-8 col-sm-8">
									<div class="post-excerpt no-padding">
										<div class="meta">
											<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
										</div>
										<h5 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
										<div class="meta">
											<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
										</div>
									</div>
								</div>
							</div>
						</article>
				<?php	
					}
					}
				$i ++;
				}
				?>
				</div>
			</div>
				
				<?php
		
			wp_reset_postdata(); 
		}
		
		else{
			echo '<p style="padding:25px;">No listing found</p>';
	
	} 
	
	
	
	?>
		</div>		
			<!-- // HOME SECTION 3 -->  

	<?php
	
	}

} 
register_widget('homestyle3');

/*end of Homme style 3 posts code */
 
 
 
 /*start of home style 4 posts code */
 
class homestyle4 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle4', // Base ID
			'Home style 4', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		$posttype = $instance['posttype'];
		
		//echo $before_widget;
		// Check if title is set
		
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$title,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		$posttype = esc_attr($instance['posttype']);
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		$posttype = '';
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
                <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>		
                 </p>	
				

			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
				
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$title,$posttype) { //html
		global $post;
	
	
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
	
	
	
			if($posttype == 'articlecategory' || $posttype == 'newsarticlecategory')
	{
	$listings = new WP_Query( array(
    
	'posts_per_page' => $posts_num,
	'offset'         => $posts_offset,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype,
            'field' => 'term_id',
            'terms' => $posts_cat
        )
    ),
) );
	}	
else{
	$listings = new WP_Query();
	$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
}	
		
		
		
		
		if($listings->found_posts > 0) {
			
			
			?>
	  <div style="padding-top:60px;">
	
		<h3 class="margin-bottom-15"><b><?php echo $title ?></b></h3>
		<?php
			
			$i = 0;
	
				while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					
					if($i == 0)
					{
								$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
			 	
		
		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'singlepage' ); 
					?>
					<article class="style3 style-alt">
				<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
					<div class="overlay overlay-02"></div>
					<div class="post-thumb">
						<div class="small-title cat"><?php echo get_cat_name( $posts_cat ); ?></div>
						<div class="post-excerpt">
							<div class="meta">
								<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
							</div>
							<h1 itemprop="headline" class="h1 text-white"><?php echo get_the_title(); ?></h1>
							<div class="meta">
								<span class="author"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/avatar/1.jpg" class="img-circle" alt=""> <?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name;
?></span>
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No';
                                     }
                                      ?></span>
								<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
							</div>
						</div>
						<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
					</div>
				</a>
			</article>	
				<?php
					
					}
					
					if($i !=0)
					{
						
						
					?>
	<article class="style2">
				<div class="row">
					
					<?php 
					
								$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					
					
					
	if ( $show_image && $image ) {
		

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
		
			
		?>
		<div class="col-md-4 col-sm-4">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="article-thumb">
<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
				</div>
						</a>
					</div>
		<?php
	
		}
					?>
					<div class="col-md-8 col-sm-8">
						<div class="post-excerpt">
							<div class="small-title cat"><?php echo get_cat_name( $posts_cat ); ?></div>
							<h3 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
							<div class="meta">
								<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name;
?></a></span>
								<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No';
                                     }
                                      ?></span>
							</div>
							<p>
							<?php
										if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
							?>
						</p>
						</div>
					</div>
				</div>
			</article>
					<?php	
					}
					
				
			
				$i++;	
				}
				?>
			</div>
				<?php
		
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homestyle4');

/*end of home style 4 posts code */


/*start of home style 5 posts code */


class homestyle5 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle5', // Base ID
			'Home style 5', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$select_design = $instance['select_design'];
		$posttype = $instance['posttype'];
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );


			
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$title,$select_design,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['select_design'] = strip_tags($new_instance['select_design']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$select_design = esc_attr($instance['select_design']);
		$posttype = esc_attr($instance['posttype']);
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$select_design = '';
		$posttype = '';
		
		
		
		
	}
	?>
	
		<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'select_design' ) ); ?>"><?php _e( 'Design Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'select_design' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'select_design' ) ); ?>">
						<option value="design1" <?php selected( 'design1', $instance['select_design'] ); ?>><?php _e( 'design 1', 'genesis' ); ?></option>
						<option value="design2" <?php selected( 'design2', $instance['select_design'] ); ?>><?php _e( 'design 2', 'genesis' ); ?></option>
					</select>
					
				</p>
	
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
							'taxonomy'          => array('category','articlecategory','newsarticlecategory'),
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
                <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
						<option value="articlecategory" <?php selected( 'articlecategory', $instance['posttype'] ); ?>><?php _e( 'Article', 'genesis' ); ?></option>
						<option value="newsarticlecategory" <?php selected( 'newsarticlecategory', $instance['posttype'] ); ?>><?php _e( 'News Article', 'genesis' ); ?></option>
					    <option value="post" <?php selected( 'post', $instance['posttype'] ); ?>><?php _e( 'Posts', 'genesis' ); ?></option>
					</select>		
                 </p>	
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$title,$select_design,$posttype) { //html
		global $post;
	
	
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	 	if($posttype == 'articlecategory' || $posttype == 'newsarticlecategory')
	{
	$listings = new WP_Query( array(
    
	'posts_per_page' => $posts_num,
	'offset'         => $posts_offset,
    'tax_query' => array(
        array (
            'taxonomy' => $posttype,
            'field' => 'term_id',
            'terms' => $posts_cat
        )
    ),
) );
	}	
else{
	$listings = new WP_Query();
	$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
}
		
		if($listings->found_posts > 0) {
			
			
			
			if($select_design == 'design1')
			{
			
			?>
			  <div class="info-content margin-top-60">
					<h4 class="margin-bottom-15"><b><?php echo $title; ?></b></h4>
					<div class="row">
		<?php
			
	$i = 0;
				while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					
					$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					
					   if($i==0)
		{
					?>
			
				<div class="col-md-8 col-sm-8">
							<article class="style3 style-alt">
								<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
									<div class="overlay overlay-02"></div>
									<div class="post-thumb">
										<div class="small-title cat"><?php echo get_cat_name( $posts_cat ); ?></div>
										<div class="post-excerpt">
											<div class="meta">
												<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
											</div>
											<h1 itemprop="headline" class="h1 text-white"><?php echo get_the_title(); ?></h1>
											<div class="meta">
											<?php 
											$display_name = get_the_author_meta( 'display_name', $post->post_author );
                                             if ( empty( $display_name ) )
                                          $display_name = get_the_author_meta( 'nickname', $post->post_author );
											?>
												<span class="author"><img src="<?php echo get_stylesheet_directory_uri();?>/img/avatar/1.jpg" class="img-circle" alt=""> by <?php echo $display_name; ?></span>
												<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
												<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
											</div>
										</div>
										<?php
										
		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style5' ); 
		genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
	genesis_markup(array(
	'close' => ''
));	

										?>
									</div>
								</a>
							</article>
						</div>
						<div class="col-md-4 col-sm-4">
		<?php
		}
        if($i !=0)
		{			
		?>		
				
				<article class="style4 style-alt margin-bottom-10">
								<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
									<div class="overlay overlay-02"></div>
									<div class="post-thumb">
										<div class="small-title cat"><?php echo get_cat_name($posts_cat); ?></div>
										<div class="post-excerpt">
											<div class="meta">
												<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
											</div>
											<h5 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h5>
										</div>
										<?php 
				 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style5' ); 
		
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
						
	genesis_markup(array(
	'close' => ''
));	

										?>
									</div>
								</a>
					</article>	
				<?php	
		}
					$i++;
				}
				?>
					</div>
				</div>
				</div>
				<?php
		
			wp_reset_postdata(); 
		}
		if($select_design == 'design2')
		{
		?>	
		<div class="padding-top-60">
					<h3 class="margin-bottom-15"><b>The Lead</b></h3>
					
					<div class="row style5">
					<?php
					while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					?>
						<div class="col-sm-4">
							<article class="style4">
								<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
									<div class="overlay overlay-02"></div>
									<div class="post-thumb">
										<div class="post-excerpt">
											<div class="meta">
												<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
											</div>
											<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
										</div>
								<?php		
		$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
		$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style51' ); 
	
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
?>
									</div>
								</a>
							</article>
						</div>
				
				
					<?php
					}
					?>
				
					
					</div>
				
				</div>	
		<?php	
		}
		
		}
		else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homestyle5');

/*end of home style 5 posts code */




//start for the featured video widget code

class featuredvideo extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'featuredvideo', // Base ID
			'Video Posts', // Name
			array('description' => __( 'To display the Video posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );


		$before_title = '<div class="side-widget"><h4>';
	   $after_title = '</h4>';
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}
		else
		{
			echo $before_title . $after_title;
		}
		
		$this->getRealtyListings($posts_num,$posts_offset,$show_content,$content_limit,$more_text,$show_image);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		
	} else {
		$title = '';
		$posts_num = '';
		
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		
		
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		

			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_offset,$show_content,$content_limit,$more_text,$show_image) { //html
		global $post;
	
	
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
$listings = new WP_Query();	
$listings->query('post_type=video&posts_per_page=' . $posts_num.'&offset='.$posts_offset);


?>
<?php

while ($listings->have_posts())
{	
$listings->the_post(); 
?>

				<article class="article-home margin-bottom-20">
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						
								
						<?php
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
				 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			if ( $show_image && $image ) 
			{
		
		?>
		<div class="article-thumb">
							<div class="play"></div>
							<div class="overlay overlay-02"></div>
												
<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
</div>
		<?php
	
		}
		else
		{
		?>	
					<div class="article-thumb">
							<div class="play"></div>
							<div class="overlay overlay-02"></div>
							<?php 
	genesis_markup( array(
		'html5'   => '<img style="display:none !important" src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
						<img src="http://img.youtube.com/vi/<?php echo get_post_meta( get_the_ID(), 'youtubelink',true ); ?>/mqdefault.jpg" class="img-responsive" alt="">
						</div>
		<?php
        }
?>		
						
				
					</a>
					<div class="post-excerpt">
						<h3 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
						<div class="meta">
							<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name; ?></a></span>
							<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
							<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
						</div>
					</div>
				</article>
<?php 
} 
wp_reset_query(); 
	
	 
	}
	
} 
register_widget('featuredvideo');

//end for the featured video widget code


//custom post type for video

/** Add Custom Post Types */

//custom post types
function custom_magazine_theme_custom_posts()
{
    $labels_article = array(
	'name'               => 'article',
	'singular_name'      => 'article',
	'menu_name'          => 'Article',
	'name_admin_bar'     => 'Article',
	'add_new'            => 'Add New',
	'add_new_item'       => 'Add New Article',
	'new_item'           => 'article',
	'edit_item'          => 'article',
	'view_item'          => 'article',
	'all_items'          => 'article',
	'search_items'       => 'article',	
	);

	$args_article = array(
	'labels'             => $labels_article,       
	'public'             => true,
	'publicly_queryable' => true,
	'show_ui'            => true,
	'show_in_menu'       => true,
	'query_var'          => true,
	'exclude_from_search' => false,
	'capability_type'    => 'post',
	'menu_icon'          => 'dashicons-welcome-write-blog',
	'has_archive'        => true,
	'hierarchical'       => true,
	//'rewrite'            => array( 'slug' => 'article', 'with_front' => false ), // Important!
	'supports'           => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
	);

	register_post_type( 'article', $args_article );
			
			
			
	
    $labels_newsarticle = array(
	'name'               => 'news article',
	'singular_name'      => 'news article',
	'menu_name'          => 'News Article',
	'name_admin_bar'     => 'News Article',
	'add_new'            => 'Add New',
	'add_new_item'       => 'Add New News Article',
	'new_item'           => 'news article',
	'edit_item'          => 'news article',
	'view_item'          => 'news article',
	'all_items'          => 'news article',
	'search_items'       => 'news article',	
	);

	$args_newsarticle = array(
	'labels'             => $labels_newsarticle,       
	'public'             => true,
	'publicly_queryable' => true,
	'show_ui'            => true,
	'show_in_menu'       => true,
	'exclude_from_search' => false,
	'query_var'          => true,
	'capability_type'    => 'post',
	'menu_icon'          => 'dashicons-welcome-write-blog',
	'has_archive'        => true,
	'hierarchical'       => true,
	//'rewrite'            => array( 'slug' => 'newsarticle', 'with_front' => false ), // Important!
	'supports'           => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', )
	);

	register_post_type( 'newsarticle', $args_newsarticle );



	
    $labels_video = array(
	'name'               => 'video',
	'singular_name'      => 'video',
	'menu_name'          => 'Video',
	'name_admin_bar'     => 'Video',
	'add_new'            => 'Add New',
	'add_new_item'       => 'Add New Video',
	'new_item'           => 'video',
	'edit_item'          => 'video',
	'view_item'          => 'video',
	'all_items'          => 'video',
	'search_items'       => 'video',	
	);

	$args_video = array(
	'labels'             => $labels_video,       
	'public'             => true,
	'publicly_queryable' => true,
	'show_ui'            => true,
	'show_in_menu'       => true,
	'exclude_from_search' => false,
	'query_var'          => true,
	'capability_type'    => 'post',
	'menu_icon'          => 'dashicons-video-alt3',
	'has_archive'        => true,
	'hierarchical'       => true,
	//'rewrite'            => array( 'slug' => 'video', 'with_front' => false ), // Important!
	'supports'           => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', )
	);

	register_post_type( 'video', $args_video );		
}


add_action('init','custom_magazine_theme_custom_posts');



function my_custom_taxonomies_magazine_theme() 
{
    $labels_taxonomy_newsarticle = array(
  'name'              => _x( 'News Article Categories', 'taxonomy general name', 'textdomain' ),
  'singular_name'     => _x( 'News Article Categories', 'taxonomy singular name', 'textdomain' ),
  'search_items'      => __( 'Search News Article Categories', 'textdomain' ),
  'all_items'         => __( 'All News Article Categories', 'textdomain' ),
  'parent_item'       => __( 'Parent News Article Categories', 'textdomain' ),
  'parent_item_colon' => __( 'Parent News Article Categories:', 'textdomain' ),
  'edit_item'         => __( 'Edit News Article Categories', 'textdomain' ),
  'update_item'       => __( 'Update News Article Categories', 'textdomain' ),
  'add_new_item'      => __( 'Add New News Article Categories', 'textdomain' ),
  'new_item_name'     => __( 'New News Article Categories Name', 'textdomain' ),
  'menu_name'         => __( 'News Article Categories', 'textdomain' ),
 );

 $args_taxonomy_newsarticle = array(
  'hierarchical'      => true,
  'public'             => true,
  'labels'            => $labels_taxonomy_newsarticle,
  'show_ui'           => true,
  'show_admin_column' => true,
  'exclude_from_search' => false,
  'query_var'         => true,
  'show_in_nav_menus' => true,
 // 'rewrite'           => array( 'slug' => 'newsarticle' ),
 );

 register_taxonomy( 'newsarticlecategory', array( 'newsarticle' ), $args_taxonomy_newsarticle );	



 $labels_taxonomy_article = array(
  'name'              => _x( 'Article Categories', 'taxonomy general name', 'textdomain' ),
  'singular_name'     => _x( 'Article Categories', 'taxonomy singular name', 'textdomain' ),
  'search_items'      => __( 'Search Article Categories', 'textdomain' ),
  'all_items'         => __( 'All Article Categories', 'textdomain' ),
  'parent_item'       => __( 'Parent Article Categories', 'textdomain' ),
  'parent_item_colon' => __( 'Parent Article Categories:', 'textdomain' ),
  'edit_item'         => __( 'Edit Article Categories', 'textdomain' ),
  'update_item'       => __( 'Update Article Categories', 'textdomain' ),
  'add_new_item'      => __( 'Add New Article Categories', 'textdomain' ),
  'new_item_name'     => __( 'New Article Categories Name', 'textdomain' ),
  'menu_name'         => __( 'Article Categories', 'textdomain' ),
 );

 $args_taxonomy_article = array(
  'hierarchical'      => true,
  'public'             => true,
  'labels'            => $labels_taxonomy_article,
  'show_ui'           => true,
  'show_admin_column' => true,
  'exclude_from_search' => false,
  'query_var'         => true,
  'show_in_nav_menus' =>true,
  //'rewrite'           => array( 'slug' => 'article' ),
 );

 register_taxonomy( 'articlecategory', array( 'article' ), $args_taxonomy_article );

 
 }
add_action( 'init', 'my_custom_taxonomies_magazine_theme' );


//code for adding the custom meta field for video custom post type

function video_add_custom_metabox() {

	add_meta_box(
		'video_meta',
		__( 'Video link' ),
		'video_meta_callback',
		'video',
		'normal',
		'high'
	);

}
add_action( 'add_meta_boxes', 'video_add_custom_metabox' );

function video_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'video_nonce' );
	$video_stored_meta = get_post_meta( $post->ID ); ?>

	
	
	
	<table class="form-table">
<tbody>

	<tr valign="top">
		<th scope="row"><label for="youtubelink">Youtube Link</label></th>
<td><p><input class="large-text" type="text" name="youtubelink" id="genesis_custom_body_class" value="<?php if ( ! empty ( $video_stored_meta['youtubelink'] ) ) echo esc_attr( $video_stored_meta['youtubelink'][0] ); ?>" placeholder="eg. EKyirtVHsK0"></p></td>
	</tr>



</tbody>
</table>
	
	
<?php
}

function video_meta_save( $post_id ) {
	// Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'video_nonce' ] ) && wp_verify_nonce( $_POST[ 'video_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }


		if ( isset( $_POST[ 'youtubelink' ] ) ) {
		update_post_meta( $post_id, 'youtubelink', sanitize_text_field( $_POST[ 'youtubelink' ] ) );
	}
	
			
	
}	
	add_action( 'save_post', 'video_meta_save' );
?>
<?php
add_filter( 'pre_get_posts', 'tgm_io_cpt_search' );
/**
 * This function modifies the main WordPress query to include an array of 
 * post types instead of the default 'post' post type.
 *
 * @param object $query  The original query.
 * @return object $query The amended query.
 */
function tgm_io_cpt_search( $query ) {
	
    if ( $query->is_search ) {
	$query->set( 'post_type', array( 'post', 'article', 'newsarticle', 'video' ) );
    }
    
    return $query;
}
?>
<?php
// custom fields for company information in settings

/**
 *
 * The page content surrounding the settings fields. Usually you use this to instruct non-techy people what to do.
 *
 */
function theme_settings_page(){ 
	?>
	<div class="wrap">
		<form method="post" action="options.php">
			<?php
			settings_fields("section");
			do_settings_sections("theme-options");
			submit_button();
			?>
		</form>
	</div>
	
	<?php }
/**
 *
 * Next comes the settings fields to display. Use anything from inputs and textareas, to checkboxes multi-selects.
 *
 */

// Founding date
function display_support_founddate(){ ?>
	
	<input type="text" name="founddate" placeholder="Enter Founding date" value="<?php echo get_option('founddate'); ?>" size="35">

<?php }
// Founder name
function display_support_foundname(){ ?>
	
	<input type="text" name="foundname" placeholder="Enter Founder name" value="<?php echo get_option('foundname'); ?>" size="35">
<?php }
Address:
// streetAddress
function display_support_streetaddress(){ ?>
	
	<input type="text" name="streetaddress" placeholder="Enter street Address" value="<?php echo get_option('streetaddress'); ?>" size="35">

<?php }

// addressLocality
function display_support_addresslocality(){ ?>
	
	<input type="text" name="addresslocality" placeholder="Enter address Locality" value="<?php echo get_option('addresslocality'); ?>" size="35">

<?php }

// addressRegion
function display_support_addressregion(){ ?>
	
	<input type="text" name="addressregion" placeholder="Enter address Region" value="<?php echo get_option('addressregion'); ?>" size="35">

<?php }

// postalCode
function display_support_postalcode(){ ?>
	
	<input type="text" name="postalcode" placeholder="Enter postal Code" value="<?php echo get_option('postalcode'); ?>" size="35">

<?php }

// addressCountry
function display_support_addresscountry(){ ?>
	
	<input type="text" name="addresscountry" placeholder="Enter address Country" value="<?php echo get_option('addresscountry'); ?>" size="35">

<?php }

// contact type
function display_support_contacttype(){ ?>
	
	<input type="text" name="contacttype" placeholder="Enter contact Type" value="<?php echo get_option('contacttype'); ?>" size="35">

<?php }
 
// Phone
function display_support_phone_element(){ ?>
	
	<input type="tel" name="support_phone" placeholder="Enter phone number" value="<?php echo get_option('support_phone'); ?>" size="35">

<?php }
// Fax
function display_support_fax_element(){ ?>
	
	<input type="tel" name="support_fax" placeholder="Enter fax number" value="<?php echo get_option('support_fax'); ?>" size="35">

<?php }
// Email
function display_support_email_element(){ ?>
	
	<input type="email" name="support_email" placeholder="Enter email address" value="<?php echo get_option('support_email'); ?>" size="35">
	
<?php }

// link1
function display_support_link1(){ ?>
	
	<input type="text" name="link1" placeholder="Enter link1" value="<?php echo get_option('link1'); ?>" size="35">

<?php }

// link2
function display_support_link2(){ ?>
	
	<input type="text" name="link2" placeholder="Enter link2" value="<?php echo get_option('link2'); ?>" size="35">

<?php }

// link3
function display_support_link3(){ ?>
	
	<input type="text" name="link3" placeholder="Enter link3" value="<?php echo get_option('link3'); ?>" size="35">

<?php }

// link4
function display_support_link4(){ ?>
	
	<input type="text" name="link4" placeholder="Enter link4" value="<?php echo get_option('link4'); ?>" size="35">

<?php }

/**
 *
 * Here you tell WP what to enqueue into the <form> area. You need:
 *
 * 1. add_settings_section
 * 2. add_settings_field
 * 3. register_setting
 *
 */
function display_custom_info_fields(){
	
	add_settings_section("section", "Company Information", null, "theme-options");

	
	add_settings_field("founddate", "Founding Date", "display_support_founddate", "theme-options", "section");
	add_settings_field("foundname", "Founder Name", "display_support_foundname", "theme-options", "section");
	add_settings_field("streetaddress", "Street Address", "display_support_streetaddress", "theme-options", "section");
	add_settings_field("addresslocality", "Address Locality", "display_support_addresslocality", "theme-options", "section");
	add_settings_field("addressregion", "Address Region", "display_support_addressregion", "theme-options", "section");
	add_settings_field("postalcode", "postal Code", "display_support_postalcode", "theme-options", "section");
	add_settings_field("addresscountry", "Address Country", "display_support_addresscountry", "theme-options", "section");
	
	add_settings_field("link1", "link1", "display_support_link1", "theme-options", "section");
	add_settings_field("link2", "link2", "display_support_link2", "theme-options", "section");
	add_settings_field("link3", "link3", "display_support_link3", "theme-options", "section");
	add_settings_field("link4", "link4", "display_support_link4", "theme-options", "section");
	
	add_settings_field("contacttype", "Support Type.", "display_support_contacttype", "theme-options", "section");
	add_settings_field("support_phone", "Support Phone No.", "display_support_phone_element", "theme-options", "section");
	add_settings_field("support_fax", "Support Fax No.", "display_support_fax_element", "theme-options", "section");
	add_settings_field("support_email", "Support Email address", "display_support_email_element", "theme-options", "section");
	
	
	register_setting("section", "founddate");
	register_setting("section", "foundname");
	register_setting("section", "streetaddress");
	register_setting("section", "addresslocality");
	register_setting("section", "addressregion");
	register_setting("section", "postalcode");
	register_setting("section", "addresscountry");
	register_setting("section", "link1");
	register_setting("section", "link2");
	register_setting("section", "link3");
	register_setting("section", "link4");
	
	
	register_setting("section", "contacttype");
	register_setting("section", "support_phone");
	register_setting("section", "support_fax");
	register_setting("section", "support_email");
	
}
add_action("admin_init", "display_custom_info_fields");
/**
 *
 * Tie it all together by adding the settings page to wherever you like. For this example it will appear
 * in Settings > Contact Info
 *
 */
function add_custom_info_menu_item(){
	
	add_options_page("Contact Info", "Contact Info", "manage_options", "contact-info", "theme_settings_page");
	
}
add_action("admin_menu", "add_custom_info_menu_item");


// Start of code for the Theme Custom Navigation Menu widget class

     class Theme_Custom_Menu_Widget extends WP_Widget {

        function Theme_Custom_Menu_Widget() {
            $widget_ops = array( 'description' => __('Add a custom menu to your sidebar.') );
            parent::__construct( 'nav_menu', __('Theme Custom Menu'), $widget_ops );
        }

        function widget($args, $instance) {
            // Get menu
            $nav_menu = ! empty( $instance['nav_menu'] ) ? wp_get_nav_menu_object( $instance['nav_menu'] ) : false;

            if ( !$nav_menu )
                return;

            /** This filter is documented in wp-includes/default-widgets.php */
            $instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

            echo $args['before_widget'];

            if ( !empty($instance['title']) )
                echo $args['before_title'] . $instance['title'] . $args['after_title'];

            wp_nav_menu( array( 'fallback_cb' => '', 
			'menu' => $nav_menu,
			'container_class' => 'custom_container',
			'menu_class' => 'menu',
			'link_before' => '<span itemprop="name">',
			'link_after' => '</span>',

			) );

            echo $args['after_widget'];
        }

        function update( $new_instance, $old_instance ) {
            $instance['title'] = strip_tags( stripslashes($new_instance['title']) );
            $instance['nav_menu'] = (int) $new_instance['nav_menu'];
            return $instance;
        }

        function form( $instance ) {
            $title = isset( $instance['title'] ) ? $instance['title'] : '';
            $nav_menu = isset( $instance['nav_menu'] ) ? $instance['nav_menu'] : '';

            // Get menus
            $menus = wp_get_nav_menus( array( 'orderby' => 'name' ) );

            // If no menus exists, direct the user to go and create some.
            if ( !$menus ) {
                echo '<p>'. sprintf( __('No menus have been created yet. <a href="%s">Create some</a>.'), admin_url('nav-menus.php') ) .'</p>';
                return;
            }
            ?>
            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:') ?></label>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('nav_menu'); ?>"><?php _e('Select Menu:'); ?></label>
                <select id="<?php echo $this->get_field_id('nav_menu'); ?>" name="<?php echo $this->get_field_name('nav_menu'); ?>">
                    <option value="0"><?php _e( '&mdash; Select &mdash;' ) ?></option>
            <?php
                foreach ( $menus as $menu ) {
                    echo '<option value="' . $menu->term_id . '"'
                        . selected( $nav_menu, $menu->term_id, false )
                        . '>'. esc_html( $menu->name ) . '</option>';
                }
            ?>
                </select>
            </p>
            <?php
        }
    }

    add_action('widgets_init', create_function('', 'return register_widget("Theme_Custom_Menu_Widget");'));
	// end of code for the Theme Custom Navigation Menu widget class