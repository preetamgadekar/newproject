<?php
/**
 * Genesis Sample.
 *
 * This file adds the required CSS to the front end to the Genesis Sample Theme.
 *
 * @package Genesis Sample
 * @author  StudioPress
 * @license GPL-2.0+
 * @link    http://www.studiopress.com/
 */

add_action( 'wp_enqueue_scripts', 'genesis_sample_css' );
/**
* Checks the settings for the link color, and accent color.
* If any of these value are set the appropriate CSS is output.
*
* @since 2.2.3
*/
function genesis_sample_css() {

	$handle  = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';

	$color_link = get_theme_mod( 'genesis_sample_link_color', genesis_sample_customizer_get_default_link_color() );
	$color_accent = get_theme_mod( 'genesis_sample_accent_color', genesis_sample_customizer_get_default_accent_color() );
//echo $color_link;
	$css = '';

	$css .= ( genesis_sample_customizer_get_default_link_color() !== $color_link ) ? sprintf( '
      .header .navbar-default .navbar-nav > li > a > span:hover
	  {
		  color:'.$color_link.' !important;
	  }
	  .dropdown-v1 .dropdown-menu > li > a:hover
	  {
		  color:'.$color_link.' !important;
	  }
	  a.link,
	  
	  .dropdown-v1 .dropdown-menu > li > a > span:hover,
	.dropdown-parent:hover > a ,
.dropdown-parent > a:hover ,
.dropdown-v1 .dropdown-menu>li>a:hover,
	  a:hover,div#bs-example-navbar-collapse-1 .navbar-nav > li > a:hover,
	   .header .navbar-default .navbar-nav > li.dropdown.megamenu > a > span:hover,
		.entry-title a:focus,
		.entry-title a:hover,
		.genesis-nav-menu a:focus,
		.genesis-nav-menu a:hover,
		.genesis-nav-menu .current-menu-item > a,
		.genesis-nav-menu .sub-menu .current-menu-item > a:focus,
		.genesis-nav-menu .sub-menu .current-menu-item > a:hover,
		.menu-toggle:focus,
		.menu-toggle:hover,
		.sub-menu-toggle:focus,
		.sub-menu-toggle:hover {
			color: %s !important;
		}

		', $color_link ) : '';

	$css .= ( genesis_sample_customizer_get_default_accent_color() !== $color_accent ) ? sprintf( '

	div#respond p.form-submit input#submit:hover {
    background: '.$color_accent.' !important;
	}			
     
.hs-prev:hover ,
.hs-next:hover {
	background: '.$color_accent.' !important;
	
}
	 input#author:focus,input#email:focus,textarea#comment:focus
		{
			border:1px solid '.$color_accent.' !important;
		}		
		.hs-prev.slick-arrow:hover,.hs-next.slick-arrow:hover
			 {
				 border: 1.5px solid #fff;
			 }	
			 .megamenu > .dropdown-menu
			 {
				    border-top: 1px solid '.$color_accent.' !important; 
			 }
			 .dropdown-v1 > .dropdown-menu
			 {
				 border-top: 1px solid '.$color_accent.' !important;  
			 }
		.post-nav .text-right i,
		.post-nav .text-left i		

		{
		
			color: %s !important;
		}
		', $color_accent, genesis_sample_color_contrast( $color_accent ) ) : '';

	if ( $css ) {
		wp_add_inline_style( $handle, $css );
	}

}
