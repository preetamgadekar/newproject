$( document ).ready(function() {
    console.log('dfdfd');
    $('#pageparentdiv h2 span').each(function() {
        var text = $(this).text();
        $(this).text(text.replace('Post Attributes', 'Post Type')); 
    });
	  $('#pageparentdiv .inside p label').each(function() {
        var text = $(this).text();
        $(this).text(text.replace('Template', '')); 
    });
	$('#formatdiv h2 span').each(function() {
        var text = $(this).text();
        $(this).text(text.replace('Format', 'Post Format')); 
    });
 });

 
$(document).ready(function() {

	
	  if($('#post-format-video').is(':checked')) 
	  {
		  $("#page_template option[value='video-template-video.php']").show();
		  $("#page_template option[value='videolyrics-template-video.php']").show();
              $("#page_template option[value='article-template-single.php']").hide();
	  $("#page_template option[value='newsarticle-template-single.php']").hide();
	  $("#page_template option[value='movies-template-single.php']").hide();
	  $("#video_meta").show();
	  $("#songcredits_meta").hide();
	  $("#movieinfo_meta").hide();
	  $("#movie_meta").hide();
	  }
	  
	  
	  
	    if($('#post-format-0').is(':checked')) 
	  {
		  $("#page_template option[value='video-template-video.php']").hide();
		  $("#page_template option[value='videolyrics-template-video.php']").hide();
              $("#page_template option[value='article-template-single.php']").show();
	  $("#page_template option[value='newsarticle-template-single.php']").show();
	  $("#page_template option[value='movies-template-single.php']").show();
	  $("#video_meta").hide();
	  $("#songcredits_meta").hide();
	   $("#movieinfo_meta").hide();
	  $("#movie_meta").hide();
	  
	  }


	
	     //$("#page_template option[value='video-template-video.php']").hide();  
   $('input[type="radio"]').click(function() {
       if($(this).attr('id') == 'post-format-0') {
       $("#page_template option[value='article-template-single.php']").show();
	  $("#page_template option[value='newsarticle-template-single.php']").show();  
	  $("#page_template option[value='movies-template-single.php']").show();  
     $("#page_template option[value='video-template-video.php']").hide(); 
	   $("#page_template option[value='videolyrics-template-video.php']").hide();
  $("#video_meta").hide();	 
  $("#songcredits_meta").hide();
 $("#movieinfo_meta").hide();
	  $("#movie_meta").hide();  
			 
 $('#page_template option[value="default"]').attr("selected", "selected");	

 
       }

        if($(this).attr('id') == 'post-format-video')  {
			   $("#page_template option[value='video-template-video.php']").show();
			   $("#page_template option[value='videolyrics-template-video.php']").show();
              $("#page_template option[value='article-template-single.php']").hide();
	  $("#page_template option[value='newsarticle-template-single.php']").hide();
	  $("#page_template option[value='movies-template-single.php']").hide();
	  $("#video_meta").hide();
	  $("#songcredits_meta").hide();
	   $("#movieinfo_meta").hide();
	  $("#movie_meta").hide();
	   $('#page_template option[value="default"]').attr("selected", "selected");	
       }
	 
	   
   });
 
  if($('#page_template').val() == 'movies-template-single.php') {
       $("#movieinfo_meta").show();
	  $("#movie_meta").show();
        }
 
 if($('#page_template').val() == 'videolyrics-template-video.php') {
             $("#songcredits_meta").show();
        }
 
  if($('#page_template').val() == 'default') {
             $("#video_meta").hide();
        }
		
 
 $("#page_template").change(function() {
   var val = $(this).val();
   if (val == "videolyrics-template-video.php")
	   {
      $("#songcredits_meta").show();
	  $("#video_meta").show();
   }
  
     
});
 
 
  $("#page_template").change(function() {
   var val = $(this).val();
   if (val == "movies-template-single.php")
	   {
      $("#movieinfo_meta").show();
	  $("#movie_meta").show();
   }
   else
   {
	   $("#movieinfo_meta").hide();
	  $("#movie_meta").hide();
   }
  
     
});
 
 
 
  $("#page_template").change(function() {
   var val = $(this).val();
   if (val == "video-template-video.php")
	   {
      $("#video_meta").show();
	   $("#songcredits_meta").hide();
   }

     
});


  $("#page_template").change(function() {
   var val = $(this).val();
   if (val == "default")
	   {
     $("#songcredits_meta").hide();
	  $("#video_meta").hide();
   }

     
});

	
   
})

