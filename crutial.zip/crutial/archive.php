<?php get_header();?>
<script type="application/ld+json">
 { "@context": "http://schema.org",
 "@type": "Organization",
 "name": "<?php echo get_bloginfo('name'); ?>",
 "legalName" : "<?php echo get_bloginfo('name'); ?>",
 "url": "<?php echo get_site_url(); ?>",
 "logo": "<?php echo get_header_image(); ?>",
 "foundingDate": "<?php echo get_option('founddate'); ?>",
 "founders":  {
 "@type": "Person",
 "name": "<?php echo get_option('foundname'); ?>"
 },
 "address": {
 "@type": "PostalAddress",
 "streetAddress": "<?php echo get_option('streetaddress'); ?>",
 "addressLocality": "<?php echo get_option('addresslocality'); ?>",
 "addressRegion": "<?php echo get_option('addressregion'); ?>",
 "postalCode": "<?php echo get_option('postalcode'); ?>",
 "addressCountry": "<?php echo get_option('addresscountry'); ?>"
 },
 "contactPoint": {
 "@type": "ContactPoint",
 "contactType": "<?php echo get_option('contacttype'); ?>",
 "telephone": "<?php echo get_option('support_phone'); ?>",
 "email": "<?php echo get_option('support_email'); ?>"
 },
 "sameAs": [ 
 "<?php echo get_option('link1'); ?>",
 "<?php echo get_option('link2'); ?>",
 "<?php echo get_option('link3'); ?>",
 "<?php echo get_option('link4'); ?>",
 "<?php echo get_option('link5'); ?>"
 ]}
</script>
	<?php
	  if ( is_active_sidebar( 'topadd-sidebar-widget' ))
	  {
	  genesis_widget_area( 'topadd-sidebar-widget', array(
		'before' => '<div class="topaddpositon">',
		'after'  => '</div>',
	) );
	  }
	  			add_filter( 'get_the_content_more_link', 'sp_read_more_link' );
function sp_read_more_link() {
	return '... </br></br><a class="small-title rmore" href="' . get_permalink() . '">Read More</a>';
	
	}
	  ?>
<div class="inner-content">
		<div class="container">		
			<div class="section-head">
			<?php genesis_do_breadcrumbs(); ?>
				<h1><?php echo single_cat_title(); ?></h1>
			</div>

			<div class="row">
				<div class="col-md-8">

				

				  <?php
			   

   
	
while(have_posts()):the_post();
		
		
	//	$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
		//	$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			

$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );



				
				
					genesis_markup( array(
		'html5'   => '<article class="style2" %s>',
		'context' => 'entry'
	) );
?>
					
					
					
						<div class="row">
							<div class="col-md-6 col-sm-6">
								
									<?php
									
										genesis_markup( array(
		'html5'   => '<div class="article-thumb" %s>',
		'context' => 'entry-image'
	) );
							
									
	 genesis_do_post_image(); 
									
							
	genesis_markup( array(
		'close'   => '</div>',
		
	) );

?>
									
									
									
									
									
								
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="post-excerpt">
									<div class="small-title cat"><?php the_category(); ?></div>
					<?php 
	genesis_markup( array(
		'html5'   => '<h3 %s>',
		'context' => 'entry-title'
	) );
?>
 <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
<?php 
	genesis_markup( array(
		'close'   => '</h3>',
		
	) );

?>
									
									
									
									
									
									<div class="meta">
									
							<?php	
							genesis_markup( array(
		'html5'   => '	<span %s>',
		'context' => 'author-box'
	) );

	echo 	'by <a href="#" class="link">'. $display_name.'</a>';

	genesis_markup( array(
		'close'   => '</span>',
		
	) );


				
										
					genesis_markup( array(
		'html5'   => '<span %s>',
		'context' => 'entry-time'
	) );
								
				?>			
						on <?php the_date('M j, Y'); ?>
					<?php	
								genesis_markup( array(
		                        'close'   => '</span>',
		                         ) );
								 
								?>					
										
																			
										
										<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();if($commmentcount != '0'){echo	$commmentcount;}else{echo 'No Comments';}?></span>
									</div>
							
							<?php
								genesis_markup( array(
		'html5'   => '<div %s>',
		'context' => 'entry-content'
	) );
								
							
					
		
		genesis_do_post_content();
				
											
									genesis_markup( array(
		                        'close'   => '</div>',
		                         ) );
								 
								 ?>
								</div>
							</div>
						</div>
					
					<?php 
	genesis_markup( array(
		'close'   => '</article>',
		
	) );


			
		

endwhile;		
			?>		
					
					
					<ul class="pagi-nation">
				<?php 
                 genesis_posts_nav();
				?>
	  				</ul>
					
				</div>

				
		<?php 

    genesis_markup(array(
         'html5' => '<aside class="col-md-4" %s>',
		 'context' => 'sidebar-primary'
		 ));
		 ?>
			
				

				<?php
	  if ( is_active_sidebar( 'home-sidebar-widget' ))
	  {
	  genesis_widget_area( 'home-sidebar-widget', array(
		'before' => '',
		'after'  => '',
	) );
	  }
	  ?>

		



<?php 
genesis_markup(array(
'close' => '</aside>'
));						
	?>					
				
				

			</div>
		</div>
	</div>







  <?php 
  get_footer();
    ?>