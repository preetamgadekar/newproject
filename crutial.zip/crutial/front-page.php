<?php
/**
 * This file adds the Front Page Template to any Genesis Child Theme.
 */
 get_header();
?>
<script type="application/ld+json">
 { "@context": "http://schema.org",
 "@type": "Organization",
 "name": "<?php echo get_bloginfo('name'); ?>",
 "legalName" : "<?php echo get_bloginfo('name'); ?>",
 "url": "<?php echo get_site_url(); ?>",
 "logo": "<?php echo get_header_image(); ?>",
 "foundingDate": "<?php echo get_option('founddate'); ?>",
 "founders":  {
 "@type": "Person",
 "name": "<?php echo get_option('foundname'); ?>"
 },
 "address": {
 "@type": "PostalAddress",
 "streetAddress": "<?php echo get_option('streetaddress'); ?>",
 "addressLocality": "<?php echo get_option('addresslocality'); ?>",
 "addressRegion": "<?php echo get_option('addressregion'); ?>",
 "postalCode": "<?php echo get_option('postalcode'); ?>",
 "addressCountry": "<?php echo get_option('addresscountry'); ?>"
 },
 "contactPoint": {
 "@type": "ContactPoint",
 "contactType": "<?php echo get_option('contacttype'); ?>",
 "telephone": "<?php echo get_option('support_phone'); ?>",
 "email": "<?php echo get_option('support_email'); ?>"
 },
 "sameAs": [ 
 "<?php echo get_option('link1'); ?>",
 "<?php echo get_option('link2'); ?>",
 "<?php echo get_option('link3'); ?>",
 "<?php echo get_option('link4'); ?>",
 "<?php echo get_option('link5'); ?>"
 ]}
</script>
	<?php
	  if ( is_active_sidebar( 'topadd-sidebar-widget' ))
	  {
	  genesis_widget_area( 'topadd-sidebar-widget', array(
		'before' => '<div class="topaddpositon">',
		'after'  => '</div>',
	) );
	  }
	  ?>
<?php
	  if ( is_active_sidebar( 'home-slider' ))
	  {
	  genesis_widget_area( 'home-slider', array(
		'before' => '',
		'after'  => '',
	) );
	  }
	  ?>
	  <div class="container">
	<div class="row">
		<div class="col-md-8">
	  <?php
	  if ( is_active_sidebar( 'home-middle' ))
	  {
	  genesis_widget_area( 'home-middle', array(
		'before' => '',
		'after'  => '',
	) );
	  }
	  ?>
  </div>
	  <!-- ASIDE 1  -->
	  <?php 
    genesis_markup(array(
         'html5' => '<aside class="col-md-4 padding-top-60" %s>',
		 'context' => 'sidebar-primary'
		 ));
		 ?>
	<?php
	  if ( is_active_sidebar( 'home-sidebar-widget' ))
	  {
	  genesis_widget_area( 'home-sidebar-widget', array(
		'before' => '',
		'after'  => '',
	) );
	  }
	  ?>
<?php 
genesis_markup(array(
'close' => '</aside>'
));						
	?>			
	<!-- // ASIDE 1  -->  
  </div>
  </div>
<?php
get_footer();
?>