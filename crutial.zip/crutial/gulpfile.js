var gulp = require('gulp');
var concat = require('gulp-concat');
var cleanCSS = require('gulp-clean-css');
var uglify = require('gulp-uglify-cli')
 
gulp.task('combine-scripts', function() {
	return gulp.src([
      './js/theme.js',
      './js/instagramLite.min.js',
      './js/jquery.matchHeight.min.js',
      './js/modernizr-2.8.3-respond-1.4.2.min.js',
      './js/responsive-menus.js',
      './js/responsive-menus.min.js',
      './js/tweecool.min.js',
     
    ])
    .pipe(concat({ path: 'scripts-combine.js', stat: { mode: 0666 }}))
	.pipe(uglify())
    .pipe(gulp.dest('./js'));
});
/*
gulp.task('combine-styles', function() {
	return gulp.src([
      './css/ts.css',
	  './css/style.css',
      './css/animate.css',
  
    ])
    .pipe(concat({ path: 'styles-combine.css', stat: { mode: 0666 }}))
	.pipe(cleanCSS({rebase: false}))
    .pipe(gulp.dest('./css'));
});

*/


//gulp.task('default', ['combine-styles']);
gulp.task('default', ['combine-scripts']);