<?php
/**
 * Genesis Sample.
 *
 * This file adds functions to the Genesis Sample Theme.
 *
 * @package Genesis Sample
 * @author  StudioPress
 * @license GPL-2.0+
 * @link    http://www.studiopress.com/
 */
// Start the engine.
include_once( get_template_directory() . '/lib/init.php' );
// Setup Theme.
include_once( get_stylesheet_directory() . '/lib/theme-defaults.php' );
// Set Localization (do not remove).
add_action( 'after_setup_theme', 'genesis_sample_localization_setup' );
function genesis_sample_localization_setup(){
	load_child_theme_textdomain( 'genesis-sample', get_stylesheet_directory() . '/languages' );
}
// Add the helper functions.
include_once( get_stylesheet_directory() . '/lib/helper-functions.php' );
// Add Image upload and Color select to WordPress Theme Customizer.
require_once( get_stylesheet_directory() . '/lib/customize.php' );
// Include Customizer CSS.
include_once( get_stylesheet_directory() . '/lib/output.php' );
// Add WooCommerce support.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-setup.php' );
// Add the required WooCommerce styles and Customizer CSS.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-output.php' );
// Add the Genesis Connect WooCommerce notice.
include_once( get_stylesheet_directory() . '/lib/woocommerce/woocommerce-notice.php' );
// Child theme (do not remove).
define( 'CHILD_THEME_NAME', 'Genesis Sample' );
define( 'CHILD_THEME_URL', 'http://www.studiopress.com/' );
define( 'CHILD_THEME_VERSION', '2.3.1' );
// Enqueue Scripts and Styles.
add_action( 'wp_enqueue_scripts', 'genesis_sample_enqueue_scripts_styles' );
function genesis_sample_enqueue_scripts_styles() {
	wp_enqueue_style( 'genesis-sample-fonts', '//fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700', array(), CHILD_THEME_VERSION );
	wp_enqueue_style( 'dashicons' );
	$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
	wp_enqueue_script( 'genesis-sample-responsive-menu', get_stylesheet_directory_uri() . "/js/responsive-menus{$suffix}.js", array( 'jquery' ), CHILD_THEME_VERSION, true );
	wp_localize_script(
		'genesis-sample-responsive-menu',
		'genesis_responsive_menu',
		genesis_sample_responsive_menu_settings()
	);
}


add_action( 'wp_enqueue_scripts', 'enqueue_front_scripts_header');
add_action( 'genesis_footer', 'enqueue_front_scripts_footer');
function enqueue_front_scripts_header()
{
/// custom theme code starts here
	wp_enqueue_style( 'fontawesom', get_stylesheet_directory_uri() . '/js/font-awesome/css/font-awesome.css' );
		wp_enqueue_style( 'slickcss', get_stylesheet_directory_uri() . '/js/slick/slick.css');
		wp_enqueue_style( 'bootstrap', get_stylesheet_directory_uri() . '/js/bootstrap/bootstrap.min.css' );
//	wp_enqueue_style( 'animate', get_stylesheet_directory_uri() . '/css/animate.css' );
	//	wp_enqueue_style( 'style', get_stylesheet_directory_uri() . '/css/style.css' );
	//wp_enqueue_style( 'ts', get_stylesheet_directory_uri() . '/css/ts.css' );
	//wp_enqueue_style( 'bootstrapmin', get_stylesheet_directory_uri() . '/js/font-awesome/css/font-awesome.min.css' );
	
	wp_enqueue_style( 'styles-combine', get_stylesheet_directory_uri() . '/css/styles-combine.css' );
}
function enqueue_front_scripts_footer()
	{	
   // wp_enqueue_script( 'modernizr-2.8.3-respond-1.4.2.mi', get_stylesheet_directory_uri() . '/js/modernizr-2.8.3-respond-1.4.2.min.js');
	
		wp_enqueue_script( 'bootstrapmin', get_stylesheet_directory_uri() . '/js/bootstrap/bootstrap.min.js',array('jquerymin'));
		wp_enqueue_script( 'jquerymin', get_stylesheet_directory_uri() . '/js/jquery.min.js');
		
		wp_enqueue_script( 'slickmin', get_stylesheet_directory_uri() . '/js/slick/slick.min.js');
		//wp_enqueue_script( 'theme', get_stylesheet_directory_uri() . '/js/theme.js');
		//wp_enqueue_script( 'slick', get_stylesheet_directory_uri() . '/js/slick/slick.js');
//	wp_enqueue_script( 'instagramLitemin', get_stylesheet_directory_uri() . '/js/instagramLite.min.js');
	//	wp_enqueue_script( 'tweecool.min', get_stylesheet_directory_uri() . '/js/tweecool.min.js');
	
	
	
		wp_enqueue_script( 'style-scripts', get_stylesheet_directory_uri() . '/js/scripts-combine.js');
}

add_action('admin_enqueue_scripts','cutomscript_load_admin_script');
function cutomscript_load_admin_script()
{
	 wp_enqueue_script( 'admincustomscript', get_stylesheet_directory_uri() . '/js/admincustomscript.js',array('jquery'));
}

// Define our responsive menu settings.
function genesis_sample_responsive_menu_settings() {
	$settings = array(
		'mainMenu'         => __( 'Menu', 'genesis-sample' ),
		'menuIconClass'    => 'dashicons-before dashicons-menu',
		'subMenu'          => __( 'Submenu', 'genesis-sample' ),
		'subMenuIconClass' => 'dashicons-before dashicons-arrow-down-alt2',
		'menuClasses'      => array(
			'combine' => array(
				'.nav-primary',
				'.nav-header',
			),
			'others'  => array(),
		),
	);
	return $settings;
}

add_action( 'init', 'register_my_menus' );


// Add HTML5 markup structure.
add_theme_support( 'html5', array( 'caption', 'comment-form', 'comment-list', 'gallery', 'search-form' ) );
// Add Accessibility support.
add_theme_support( 'genesis-accessibility', array( '404-page', 'drop-down-menu', 'headings', 'rems', 'search-form', 'skip-links' ) );
// Add viewport meta tag for mobile browsers.
add_theme_support( 'genesis-responsive-viewport' );
// Add support for custom header.
add_theme_support( 'custom-header', array(
	'width'           => 600,
	'height'          => 160,
	'header-selector' => '.site-title a',
	'header-text'     => false,
	'flex-height'     => true,
) );
// Add support for custom background.
add_theme_support( 'custom-background' );
// Add support for after entry widget.
add_theme_support( 'genesis-after-entry-widget-area' );
// Add support for 3-column footer widgets.
add_theme_support( 'genesis-footer-widgets', 3 );
// Add Image Sizes.
add_image_size( 'featured-image', 720, 400, TRUE );
// Rename primary and secondary navigation menus.
add_theme_support( 'genesis-menus', array( 'primary' => __( 'After Header Menu', 'genesis-sample' ), 'secondary' => __( 'Footer Menu', 'genesis-sample' ) ) );
// Reposition the secondary navigation menu.
remove_action( 'genesis_after_header', 'genesis_do_subnav' );
add_action( 'genesis_footer', 'genesis_do_subnav', 5 );
// Reduce the secondary navigation menu to one level depth.
add_filter( 'wp_nav_menu_args', 'genesis_sample_secondary_menu_args' );
function genesis_sample_secondary_menu_args( $args ) {
	if ( 'secondary' != $args['theme_location'] ) {
		return $args;
	}
	$args['depth'] = 1;
	return $args;
}
// Modify size of the Gravatar in the author box.
add_filter( 'genesis_author_box_gravatar_size', 'genesis_sample_author_box_gravatar' );
function genesis_sample_author_box_gravatar( $size ) {
	return 90;
}
// Modify size of the Gravatar in the entry comments.
add_filter( 'genesis_comment_list_args', 'genesis_sample_comments_gravatar' );
function genesis_sample_comments_gravatar( $args ) {

	$args['avatar_size'] = 60;

	return $args;
}
/*genesis custom footers code */
//* Remove site footer widgets
remove_theme_support( 'genesis-footer-widgets' );
//* Remove site footer elements
remove_action( 'genesis_footer', 'genesis_footer_markup_open', 5 );
remove_action( 'genesis_footer', 'genesis_do_footer' );
remove_action( 'genesis_footer', 'genesis_footer_markup_close', 15 );
//Remove Existing Footer
 add_action( 'widgets_init', 'magazine_extra_widgets' );
 function magazine_extra_widgets()
 {
	 			genesis_register_sidebar(array(
    'id' => 'topadd-sidebar-widget',
	'name' => __( 'Top Add Section widgets','magazine'),
	'description' =>__( 'Top Add Section widgets'),
	));	
	 
genesis_register_sidebar(array(
    'id' => 'home-slider',
	'name' => __( 'Home slider','magazine'),
	'description' =>__( 'This is for Home slider'),
	));
		genesis_register_sidebar(array(
    'id' => 'home-middle',
	'name' => __( 'Home Middle','magazine'),
	'description' =>__( 'This is for Home Middle'),
	));
 genesis_register_sidebar( array(
	'id'          => 'theme-footer-head1',
	'name'        => __( 'Footer Head 1','magazine'),
	'description' => __( 'This is the footer head 1.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-head2',
	'name'        => __( 'Footer Head 2','magazine'),
	'description' => __( 'This is the footer head 2.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-head3',
	'name'        => __( 'Footer Head 3','magazine'),
	'description' => __( 'This is the footer head 3.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-1',
	'name'        => __( 'Footer 1','magazine'),
	'description' => __( 'This is the footer 1.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-2',
	'name'        => __( 'Footer 2','magazine'),
	'description' => __( 'This is the footer 2.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-3',
	'name'        => __( 'Footer 3','magazine'),
	'description' => __( 'This is the footer 3.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-4',
	'name'        => __( 'Footer 4','magazine'),
	'description' => __( 'This is the footer 4.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-5',
	'name'        => __( 'Footer 5','magazine'),
	'description' => __( 'This is the footer 5.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-6',
	'name'        => __( 'Footer 6','magazine'),
	'description' => __( 'This is the footer 6.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-bottom1',
	'name'        => __( 'Footer bottom 1','magazine'),
	'description' => __( 'This is the footer bottom 1.','magazine'),
) );
genesis_register_sidebar( array(
	'id'          => 'theme-footer-bottom2',
	'name'        => __( 'Footer bottom 2','magazine'),
	'description' => __( 'This is the footer bottom 2.','magazine'),
) );
genesis_register_sidebar(array(
    'id' => 'home-sidebar-widget',
	'name' => __( 'Home Page Sidebar widgets','magazine'),
	'description' =>__( 'This is for Home page sidebar widgets'),
	));
genesis_register_sidebar(array(
    'id' => 'post-sidebar-widget',
	'name' => __( 'Post Page Sidebar widgets','magazine'),
	'description' =>__( 'This is for post page sidebar widgets'),
	));
genesis_register_sidebar(array(
    'id' => 'single-sidebar-widget',
	'name' => __( 'Single Page Sidebar widgets','magazine'),
	'description' =>__( 'This is for single page sidebar widgets'),
	));
	
	
//mega menu widgets
genesis_register_sidebar(array(
    'id' => 'megamenu1-sidebar-widget',
	'name' => __( 'megamenu 1 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
genesis_register_sidebar(array(
    'id' => 'megamenu2-sidebar-widget',
	'name' => __( 'megamenu 2 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
genesis_register_sidebar(array(
    'id' => 'megamenu3-sidebar-widget',
	'name' => __( 'megamenu 3 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
genesis_register_sidebar(array(
    'id' => 'megamenu4-sidebar-widget',
	'name' => __( 'megamenu 4 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
genesis_register_sidebar(array(
    'id' => 'megamenu5-sidebar-widget',
	'name' => __( 'megamenu 5 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
	genesis_register_sidebar(array(
    'id' => 'megamenu6-sidebar-widget',
	'name' => __( 'megamenu 6 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
	
	
		genesis_register_sidebar(array(
    'id' => 'megamenu7-sidebar-widget',
	'name' => __( 'megamenu 7 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
		genesis_register_sidebar(array(
    'id' => 'megamenu8-sidebar-widget',
	'name' => __( 'megamenu 8 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
		genesis_register_sidebar(array(
    'id' => 'megamenu9-sidebar-widget',
	'name' => __( 'megamenu 9 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
		genesis_register_sidebar(array(
    'id' => 'megamenu10-sidebar-widget',
	'name' => __( 'megamenu 10 Sidebar widgets','magazine'),
	'description' =>__( 'This is menu sidebar widgets'),
	));	
		
 }
add_action('genesis_footer','magazine_footer_widget');	
// Position the Footer Area
function magazine_footer_widget() {
	genesis_markup( array(
		'html5'   => '<footer class="margin-top-30"><div class="container">',
	) );
	
  if ( is_active_sidebar( 'theme-footer-head1' ) || is_active_sidebar( 'theme-footer-head2' ) || is_active_sidebar( 'theme-footer-head3' ))
	  
   {	
genesis_markup( array(
		'html5'   => '<div class="footer-head"><div class="row center-content">',
	) );
	genesis_widget_area ('theme-footer-head1', array(
		'before' => '<div class ="col-md-2 col-sm-3">',
		'after'  => '</div>',
	));
		genesis_widget_area ('theme-footer-head2', array(
		'before' => '<div class ="col-md-6 col-sm-5">',
		'after'  => '</div>',
	));
		genesis_widget_area ('theme-footer-head3', array(
		'before' => '<div class ="col-md-4 col-sm-4">',
		'after'  => '</div>',
	));
genesis_markup( array(
		'close'   => '</div></div>',
    ) );
	  }
	
	  if ( is_active_sidebar( 'theme-footer-1' ) || is_active_sidebar( 'theme-footer-2' ) || is_active_sidebar( 'theme-footer-3' ) || is_active_sidebar( 'theme-footer-4' ) || is_active_sidebar( 'theme-footer-5' ) || is_active_sidebar( 'theme-footer-6' ))
	  
   {
	genesis_markup( array(
		'html5'   => '<div class="footer-content"><div class="row">',
	) );
	genesis_widget_area ('theme-footer-1', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-2', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-3', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-4', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-5', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_widget_area ('theme-footer-6', array(
		'before' => '<div class ="col-md-2 col-sm-2">',
		'after'  => '</div>',
	));
	genesis_markup( array(
		'close'   => '</div></div>',
	) );
   }
   
    if ( is_active_sidebar( 'theme-footer-bottom1' ) || is_active_sidebar( 'theme-footer-bottom2' ))
	  
   {
	genesis_markup( array(
		'html5'   => '<div class="footer-bottom" %s><div class="row">',
		'context' => 'site-footer',
	) );
	genesis_widget_area ('theme-footer-bottom1', array(
		'before' => '<div class="col-md-6 col-sm-6">',
		'after'  => '</div>',
	));
		genesis_widget_area ('theme-footer-bottom2', array(
		'before' => '<div class="col-md-6 col-sm-6 text-right">',
		'after'  => '</div>',
	));
		genesis_markup( array(
		'close'   => '</div></div>',
	) );
   }
   
	genesis_markup( array(
		'close'   => '</div></footer>',
	) );
	}
//* Do NOT include the opening php tag shown above. Copy the code shown below.
//* Remove Skip Links from a template
remove_action ( 'genesis_before_header', 'genesis_skip_links', 5 );
//* Dequeue Skip Links Script
add_action( 'wp_enqueue_scripts','child_dequeue_skip_links' );
function child_dequeue_skip_links() {
	wp_dequeue_script( 'skip-links' );
}
		//remove initial header functions
remove_action( 'genesis_header', 'genesis_header_markup_open', 5 );
remove_action( 'genesis_header', 'genesis_header_markup_close', 15 );
remove_action( 'genesis_header', 'genesis_do_header' );
//add in the new header markup - prefix the function name - here sm_ is used
add_action( 'genesis_header', 'sm_genesis_header_markup_open', 5 );
//New Header functions
function sm_genesis_header_markup_open() {

		genesis_markup( array(
		'html5'   => '<header class="header header5 header-megamenu" %s>',
		'context' => 'site-header',
	) );
	// Added in content
?>
<nav class="navbar navbar-default" role="navigation">
<div class="container">
<div class="search-bar">
<?php		
		get_search_form();
?>			
		</div>
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
<?php			
if ( get_header_image() ) : 
	genesis_markup(array (
	 'html5' => '<div class="navbar-brand" ><div %s>'.get_bloginfo( 'name' ).'</div>',
	 'context' => 'site-title'
	));
	genesis_markup(array (
'html5' => '<p class="site-description" %s>',
'context' => 'site-description'
));
echo get_option('blogdescription');
genesis_markup(array (
'close' =>'</p>'
));
$header_image = get_header_image();
	echo '<div class="mainlogo"><a href="'. esc_url( home_url( '/' ) ).'"><img src="'.esc_url($header_image).'" id="imagelogo" alt=""/></a></div>';
genesis_markup(array (
	'close' => '</div>'
	));
 endif; // End header image check. 
?>
</div>
	<div class="search-trigger pull-right"><i class="fa fa-search"></i></div>
			<!-- <div class="login pull-right"><i class="fa fa-ellipsis-h"></i></div> -->
			<!-- Collect the nav links, forms, and other content for toggling -->
<?php			
				genesis_markup(array(
				'html5' => '<div class = "collapse navbar-collapse navbar-ex1-collapse" %s>',
				'context' => 'nav-primary'
				));
	
		if(has_nav_menu('main-menu'))
	{
	wp_nav_menu( array( 
'theme_location' => 'main-menu', 
'container' => false,
 'items_wrap'  => '<ul id="%1$s" class="nav navbar-nav">%3$s</ul>',
'walker' => new WP_Bootstrap_Navwalker()
 ) );
	}
if(get_option('megamenuactivate')=='1')
{
	?>
<ul class="nav navbar-nav">
<?php
	  if ( is_active_sidebar( 'megamenu1-sidebar-widget' ))
	  {
		  if(get_option('megamenu1select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu1-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu1').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu1select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu1-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }
	  
	  }
	   if(get_option('megamenu1select')=='nomenu' && get_option('megamenu1') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu1').'" href="'.get_option('megamenu1url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu1').'</span></a></li>';
	   }
	  if ( is_active_sidebar( 'megamenu2-sidebar-widget' ))
	  {
		  if(get_option('megamenu2select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu2-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu2').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu2select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu1-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }
	  
	  }
	   if(get_option('megamenu2select')=='nomenu' && get_option('megamenu2') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu2').'" href="'.get_option('megamenu2url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu2').'</span></a></li>';
	   }
	  if ( is_active_sidebar( 'megamenu3-sidebar-widget' ))
	  {
		  if(get_option('megamenu3select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu3-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu3').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu3select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu3-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }
	  
	  }
	   if(get_option('megamenu3select')=='nomenu' && get_option('megamenu3') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu3').'" href="'.get_option('megamenu3url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu3').'</span></a></li>';
	   }
	  if ( is_active_sidebar( 'megamenu4-sidebar-widget' ))
	  {
		  if(get_option('megamenu4select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu4-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu4').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu4select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu4-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }
	
	  }
	     if(get_option('megamenu4select')=='nomenu' && get_option('megamenu4') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu4').'" href="'.get_option('megamenu4url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu4').'</span></a></li>';
	   }
	  if ( is_active_sidebar( 'megamenu5-sidebar-widget' ))
	  {
		  if(get_option('megamenu5select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu5-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu5').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu5select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu5-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }
	 
	  }
	    if(get_option('megamenu5select')=='nomenu' && get_option('megamenu5') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu5').'" href="'.get_option('megamenu5url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu5').'</span></a></li>';
	   }
	  if ( is_active_sidebar( 'megamenu6-sidebar-widget' ))
	  {
		  if(get_option('megamenu6select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu6-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu6').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu6select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu6-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }
	
	  }
	     if(get_option('megamenu6select')=='nomenu' && get_option('megamenu6') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu6').'" href="'.get_option('megamenu6url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu6').'</span></a></li>';
	   }
	  if ( is_active_sidebar( 'megamenu7-sidebar-widget' ))
	  {
		  if(get_option('megamenu7select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu7-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu7').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu7select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu7-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }

	  }
	  	   if(get_option('megamenu7select')=='nomenu' && get_option('megamenu7') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu7').'" href="'.get_option('megamenu7url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu7').'</span></a></li>';
	   }
	  if ( is_active_sidebar( 'megamenu8-sidebar-widget' ))
	  {
		  if(get_option('megamenu8select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu8-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu8').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu8select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu8-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }
	
	  }
	     if(get_option('megamenu8select')=='nomenu' && get_option('megamenu8') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu8').'" href="'.get_option('megamenu8url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu8').'</span></a></li>';
	   }
	  if ( is_active_sidebar( 'megamenu9-sidebar-widget' ))
	  {
		  if(get_option('megamenu9select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu9-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu9').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu9select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu9-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }
	 
	  }
	    if(get_option('megamenu9select')=='nomenu' && get_option('megamenu9') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu9').'" href="'.get_option('megamenu9url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu9').'</span></a></li>';
	   }
	  if ( is_active_sidebar( 'megamenu10-sidebar-widget' ))
	  {
		  if(get_option('megamenu10select')=='megamenu')
		  {
	  genesis_widget_area( 'megamenu10-sidebar-widget', array(
		'before' => '<li class="dropdown megamenu"><a href="#" class="dropdown-toggle" data-toggle="dropdown">'.get_option('megamenu10').' <span class="fa fa-angle-down"></span></a>
							<ul class="dropdown-menu"><li><div class="row">',
		'after'  => '</div></li></ul></li>',
		
	) );
		  }
	 if(get_option('megamenu10select')=='normalmenu')
		  {
		 genesis_widget_area( 'megamenu10-sidebar-widget', array(
		'before' => '',
		'after'  => '',
		
	) );
	  }
	
	  }
	     if(get_option('megamenu10select')=='nomenu' && get_option('megamenu10') !='')
	   {
		  echo'<li class="menu-item menu-item-type-post_type menu-item-object-page"><a title="'.get_option('megamenu10').'" href="'.get_option('megamenu10url').'" itemprop="url"><span itemprop="name">'.get_option('megamenu10').'</span></a></li>';
	   }
?>
	  
</ul>
<?php 
}
genesis_markup( array(
		'close'   => '</div>',
		) );
?>
		</div>	
		</nav>
<?php
genesis_markup( array(
		'close'   => '</header>'
       ) );
}
//end of header menu code
/**
 * WP Bootstrap Navwalker */
if ( ! class_exists( 'WP_Bootstrap_Navwalker' ) ) {
	/**
	 * WP_Bootstrap_Navwalker class.
	 *
	 * @extends Walker_Nav_Menu
	 */
	class WP_Bootstrap_Navwalker extends Walker_Nav_Menu {
		
		public function start_lvl( &$output, $depth = 0, $args = array() ) {
			$indent  = str_repeat( "\t", $depth );
			$output .= "\n$indent<ul role=\"menu\" class=\" dropdown-menu\" >\n";
		}
		public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
			$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
		
			if ( 0 === strcasecmp( $item->attr_title, 'divider' ) && 1 === $depth ) {
				$output .= $indent . '<li role="presentation" class="divider">';
			} elseif ( 0 === strcasecmp( $item->title, 'divider' ) && 1 === $depth ) {
				$output .= $indent . '<li role="presentation" class="divider">';
			} elseif ( 0 === strcasecmp( $item->attr_title, 'dropdown-header' ) && 1 === $depth ) {
				$output .= $indent . '<li role="presentation" class="dropdown-header">' . esc_attr( $item->title );
			} elseif ( 0 === strcasecmp( $item->attr_title, 'disabled' ) ) {
				$output .= $indent . '<li role="presentation" class="disabled"><a href="#">' . esc_attr( $item->title ) . '</a>';
			} else {
				$value       = '';
				$class_names = $value;
				$classes     = empty( $item->classes ) ? array() : (array) $item->classes;
				$classes[]   = 'menu-item-' . $item->ID;
				$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args, $depth ) );
				if ( $args->has_children ) {
					$class_names .= ' dropdown dropdown-v1';
				}
				if ( in_array( 'current-menu-item', $classes, true ) ) {
					$class_names .= ' dropdown dropdown-v1';
				}
				$class_names = $class_names ? ' class="' . esc_attr( $class_names ) . '"' : '';
				$id          = apply_filters( 'nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args );
				$id          = $id ? ' id="' . esc_attr( $id ) . '"' : '';
				$output     .= $indent . '<li' . $id . $value . $class_names . '>';
				$atts        = array();
				//if ( empty( $item->attr_title ) ) {
					//$atts['title'] = ! empty( $item->title ) ? strip_tags( $item->title ) : '';
				//} else {
					//$atts['title'] = $item->attr_title;
				//}
				$atts['target'] = ! empty( $item->target ) ? $item->target : '';
				$atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
				// If item has_children add atts to a.
				if ( $args->has_children && 0 === $depth ) {
					$atts['href']          = '#';
					$atts['data-toggle']   = 'dropdown';
					$atts['class']         = 'dropdown-toggle';
					//$atts['aria-haspopup'] = 'true';
				} else {
					$atts['href'] = ! empty( $item->url ) ? $item->url : '';
				}
				$atts       = apply_filters( 'nav_menu_link_attributes', $atts, $item, $args );
				$attributes = '';
				foreach ( $atts as $attr => $value ) {
					if ( ! empty( $value ) ) {
						$value       = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
						$attributes .= ' ' . $attr . '="' . $value . '"';
					}
				}
				$item_output = $args->before;
				
				if ( ! empty( $item->attr_title ) ) {
					$pos = strpos( esc_attr( $item->attr_title ), 'glyphicon' );
					if ( false !== $pos ) {
						$item_output .= '<a' . $attributes . '><span class="glyphicon ' . esc_attr( $item->attr_title ) . '" aria-hidden="true"></span>&nbsp;';
					} else {
						$item_output .= '<a' . $attributes . '><i class="fa ' . esc_attr( $item->attr_title ) . '" aria-hidden="true"></i>&nbsp;';
					}
				} else {
					$item_output .= '<a' . $attributes . '><span itemprop="name">';
				}
				$item_output .= $args->link_before . apply_filters( 'the_title', $item->title, $item->ID ) . $args->link_after;
				$item_output .= ( $args->has_children && 0 === $depth ) ? ' <span class="fa fa-angle-down"></span></a>' : '</span></a>';
				$item_output .= $args->after;
				$output      .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
			} // End if().
		}
		
		public function display_element( $element, &$children_elements, $max_depth, $depth, $args, &$output ) {
			if ( ! $element ) {
				return; }
			$id_field = $this->db_fields['id'];
			// Display this element.
			if ( is_object( $args[0] ) ) {
				$args[0]->has_children = ! empty( $children_elements[ $element->$id_field ] ); }
			parent::display_element( $element, $children_elements, $max_depth, $depth, $args, $output );
		}
		
		public static function fallback( $args ) {
			if ( current_user_can( 'edit_theme_options' ) ) {
				/* Get Arguments. */
				$container       = $args['container'];
				$container_id    = $args['container_id'];
				$container_class = $args['container_class'];
				$menu_class      = $args['menu_class'];
				$menu_id         = $args['menu_id'];
				if ( $container ) {
					echo '<' . esc_attr( $container );
					if ( $container_id ) {
						echo ' id="' . esc_attr( $container_id ) . '"';
					}
					if ( $container_class ) {
						echo ' class="' . esc_attr( $container_class ) . '"'; }
					echo '>';
				}
				echo '<ul';
				if ( $menu_id ) {
					echo ' id="' . esc_attr( $menu_id ) . '"'; }
				if ( $menu_class ) {
					echo ' class="' . esc_attr( $menu_class ) . '"'; }
				echo '>';
				echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '" title="">' . esc_attr( 'Add a menu', '' ) . '</a></li>';
				echo '</ul>';
				if ( $container ) {
					echo '</' . esc_attr( $container ) . '>'; }
			}
		}
	}
} // End if().
//* Remove primary/secondary navigation menus
remove_theme_support( 'genesis-menus' );
function register_additional_menu_main() {
register_nav_menu( 'main-menu' ,__( 'Main Menu' ));
}

add_action( 'init', 'register_additional_menu_main' );
//add_action( 'genesis_before', 'add_main_nav_genesis' ); 

//enables the shortcode in widget area
add_filter('widget_text', 'do_shortcode');

//customization to the genesis serch form 
 function magazine_search_form( $form, $search_text, $button_text) 
 {
	$onfocus = " onfocus=\"if (this.value == '$search_text') {this.value = '';}\"";
	$onblur = " onblur=\"if (this.value == '') {this.value = '$search_text';}\"";
	$form = '<form itemprop="potentialAction" itemscope="" itemtype="https://schema.org/SearchAction" method="get" class="footer-search" action="' . home_url() . '/">
	<input id="s" type="search"  value="' . esc_attr( $search_text ) . '" name="s" class="s search-input"' . $onfocus . $onblur . ' />
	<button type="submit" class="searchsubmit search-submit" value="" /><i class="fa fa-search"></i></button>
	<div class="search-close"><i class="fa fa-times"></i></div>
	</form>';
	return $form;
}
add_filter( 'genesis_search_form', 'magazine_search_form', 10, 4);

//code for the post count views
//Set the Post Custom Field in the WP dashboard as Name/Value pair 
function bac_PostViews($post_ID) {
    //Set the name of the Posts Custom Field.
    $count_key = 'post_views_count'; 
    //Returns values of the custom field with the specified key from the specified post.
    $count = get_post_meta($post_ID, $count_key, true);
    //If the the Post Custom Field value is empty. 
    if($count == ''){
        $count = 0; // set the counter to zero.
        //Delete all custom fields with the specified key from the specified post. 
        delete_post_meta($post_ID, $count_key);
        //Add a custom (meta) field (Name/value)to the specified post.
        add_post_meta($post_ID, $count_key, '0');
        return $count . ' View';
    //If the the Post Custom Field value is NOT empty.
    }else{
        $count++; //increment the counter by 1.
        //Update the value of an existing meta key (custom field) for the specified post.
        update_post_meta($post_ID, $count_key, $count);
         
        //If statement, is just to have the singular form 'View' for the value '1'
        if($count == '1'){
        return $count . ' View';
        }
        //In all other cases return (count) Views
        else {
        return $count . ' Views';
        }
    }
}

//below to enable the shortcode in genesis
add_filter( 'post_content', 'shortcode_unautop');
add_filter( 'post_content', 'do_shortcode');

// Modify comments header text in comments
add_filter( 'genesis_title_comments', 'child_title_comments');
function child_title_comments() {
    return __(comments_number( '<h3>No Responses</h3>', '<h3>1 Response</h3>', '<h3>% Responses...</h3>' ), 'genesis');
}
 
// Unset URL from comment form
function crunchify_move_comment_form_below( $fields ) { 
    $comment_field = $fields['comment']; 
    unset( $fields['comment'] ); 
    $fields['comment'] = $comment_field; 
    return $fields; 
} 
add_filter( 'comment_form_fields', 'crunchify_move_comment_form_below' ); 
 add_filter('comment_form_field_url', '__return_false');
 
// Add placeholder for Name and Email
function modify_comment_form_fields($fields){
   $fields['author'] = '<h5>Leave a reply</h5><div class="row"><div class="col-md-6">' . '<input class="form-control" id="author" placeholder="Your Name" name="author" type="text" value="' .
				esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' />'.
				( $req ? '<span class="required">*</span>' : '' )  .
				'</div>';
    $fields['email'] = '<div class="col-md-6">' . '<input class="form-control" id="email" placeholder="Your email address" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) .
				'" size="30"' . $aria_req . ' />'  .
				( $req ? '<span class="required">*</span>' : '' ) 
				 .
				'</div></div>';
	//$fields['comment'] = '<textarea id="comment" name="comment" placeholder="Your Comment here" cols="45" rows="1" aria-required="true"></textarea></form></div>';
    return $fields;
}
add_filter('comment_form_default_fields','modify_comment_form_fields');

//customizing the comment textarea
function wpsites_customize_comment_form_text_area($arg) {
 $arg['comment_field'] = '<textarea id="comment" name="comment" placeholder="Your Comment here" cols="45" rows="1" aria-required="true"></textarea>';
 return $arg;
}

add_filter('comment_form_defaults', 'wpsites_customize_comment_form_text_area');
//* Customize the comment respond title
add_filter( 'comment_form_defaults', 'bg_comment_respond_title' );
function bg_comment_respond_title( $defaults ) {
	$defaults['title_reply'] = __( '', 'bg' );
	return $defaults;
}

//* Customize the submit button text in comments
add_filter( 'comment_form_defaults', 'sp_comment_submit_button' );
function sp_comment_submit_button( $defaults ) {
$defaults['label_submit'] = __( 'SUBMIT', 'bg' );	
return $defaults;
}

function mytheme_comment($comment, $args, $depth) {
    if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li ';
        $add_below = 'div-comment';
    }?>
    <<?php echo $tag; comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID() ?>"><?php 
    if ( 'div' != $args['style'] ) { ?>
 
  <div id="user_comments">
  <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
<?php
	 genesis_markup( array(
	   
		'html5'   => '<div %s>',
		'context' => 'comment'
	) );
	   
    }
?>
	<div class="comment-author">
<?php 
		genesis_markup(array(
		'html5' => '<span %s>',
		'context' => 'comment-author'
		));
      if ( $args['avatar_size'] != 0 ) {
              //  echo get_avatar( $comment, $args['avatar_size'] );
echo '<img src="'. get_stylesheet_directory_uri().'/img/avatar/1-med.png"  alt=""> ';				
            } 
           printf( __( '<cite class="fn" itemprop="name">%s</cite> <span class="says">&nbsp;</span>' ), get_comment_author_link() );
        genesis_markup(array(
		'close' => '</span>'

            ));		
		genesis_markup(array(
		'html5' => '<div class="comment-meta commentmetadata" %s>',
		'context' => 'entry-time'
		));
		?> 
     <span href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>"><?php
                /* translators: 1: date, 2: time */
                printf( 
                    __('%1$s at %2$s'), 
                    get_comment_date('M j, Y'),  
                    get_comment_time() 
                ); ?>
            </span><?php 
            edit_comment_link( __( '(Edit)' ), '  ', '' ); ?>
					  <?php 
		genesis_markup(array(
		'close' => '</div>',
		
		));
		?> 
		</div>
		<?php 
        if ( $comment->comment_approved == '0' ) { ?>
            <em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.' ); ?></em><br/><?php 
        } ?>
      <span itemprop="text"> <?php comment_text(); ?> </span>
        <div class="comment-meta""><span> <i class="fa fa-reply"></i> <?php 
                comment_reply_link( 
                    array_merge( 
                        $args, 
                        array( 
						
                            'add_below' => $add_below, 
                            'depth'     => $depth, 
                            'max_depth' => $args['max_depth'] 
                        ) 
                    ) 
                ); ?>
        </span></div><?php 
    if ( 'div' != $args['style'] ) : ?>
       <?php 
	   genesis_markup(array (
	   'close' => '</div>'
	   ));
	 genesis_markup( array(
	   
		'close'   => '</div>',
	) );
  ?> 
   </div>
	   <?php
    endif;
}
add_filter( 'genesis_register_sidebar_defaults', 'custom_register_sidebar_defaults' );
function custom_register_sidebar_defaults( $defaults ) {
	$defaults['before_title'] = '<h4>';
	$defaults['after_title'] = '</h4>';
	return $defaults;
}
/*
// Replace h3 with h4 for all widget titles for footer
add_filter( 'genesis_register_sidebar_defaults', 'custom_register_sidebar_defaults' );
function custom_register_sidebar_defaults( $defaults ) {
	$defaults['before_title'] = '<h5 class="text-white">';
	$defaults['after_title'] = '</h5>';
	return $defaults;
}
//Insert SPAN tag into widgettitle  

add_filter( 'dynamic_sidebar_params', 'b3m_wrap_widget_titles', 20 );
function b3m_wrap_widget_titles( array $params ) {
        // $params will ordinarily be an array of 2 elements, we're only interested in the first element
		$widget =& $params[0];
       // $widget['before_title'] = '<div class="side-widget"><h4>';
        //$widget['after_title'] = '</h4>';
   
        return $params;
		
}*/
add_theme_support( 'post-thumbnails' );   

		add_image_size( 'style4', 370, 230, true );
		add_image_size( 'style5', 509, 342, true );
		add_image_size( 'style51', 243, 243, true );
		//add_image_size( 'style2', 113, 70, true );
		add_image_size( 'style3', 236, 147, true );
		add_image_size( 'singlepage', 770, 379, true );
		add_image_size( 'homeslider', 1349, 390, true );
		add_image_size( 'hometop2', 776, 488, true );

		// start of custom category widget code
class categorywidget extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'categorywidget', // Base ID
			'Theme Category Widget', // Name
			array('description' => __( 'To display category widget'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		
			//echo $before_widget;
		// Check if title is set
		
	
		
		$this->getRealtyListings($title);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
				
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		
		
		
	} else {
		$title = '';
			
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	
							
			
	<?php
	}

	function getRealtyListings($title) { //html
		global $post;
	?>
		 <div class="side-widget">
		<h4><?php echo $title ?></h4>
		<ul id="toggle-view">
	<li>
	<?php

$taxonomy = 'category';
$terms = get_terms($taxonomy); // Get all terms of a taxonomy

if ( $terms && !is_wp_error( $terms ) ) :
?>
  <h3>Post</h3>
						<span class="fa fa-angle-up"></span>
						<div class="toggle-panel">
        <?php foreach ( $terms as $term ) { ?>
          <div>
		   <a class="category-menu" href="<?php echo get_term_link($term->slug, $taxonomy); ?>"><?php echo $term->name; ?></a>
		  </div>
			  <?php } ?>
    <?php endif;?>
	</div>
	</li>
	</ul>
	</div>
	<?php
	}	
} 
register_widget('categorywidget');

/*end of custom category widget  */		
class style4posts extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'style4posts', // Base ID
			'style 4 posts', // Name
			array('description' => __( 'To display the posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );


		$before_title = '<div class="side-widget"><h4>';
	   $after_title = '</h4>';
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}
		else
		{
			echo $before_title . $after_title;
		}
		
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);

		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
	
		
		
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
								
			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image) { //html
		global $post;
	
	
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
	$excategory_id = get_cat_ID('movie');
	//$listings = new WP_Query();
	//$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
		$listings = new WP_Query( array(
       'post_type' => 'post',
	   'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset,
		'cat' => $posts_cat,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => 'NOT IN'
           ) )
) );

	if($listings->found_posts > 0) {
						
			while ($listings->have_posts()) {
										
					$listings->the_post();
					
					?>
					<article class="style4">
						<div class="small-title cat"><?php the_category(); ?></div>
							<a href="<?php echo get_the_permalink(); ?>" itemprop="url">
								<div class="overlay overlay-02"></div>
								<div class="post-thumb">								
									<div class="post-excerpt">
										<div class="meta">
											<span class="date" itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
										</div>
										<h3 class="text-white" itemprop="headline"><?php echo get_the_title(); ?></h3>
									</div>
					<?php
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					
	if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
}
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
}

			echo '</div>';
					echo '</a>';
					echo '</article>';	
					
				}
				?>
			</div>
				<div class="clearfix"></div>
				<?php
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
} 
register_widget('style4posts');

/*end of style 4 posts code */

/*most popular and recent comment posts */
class popular_post_widget extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'popular_post_widget', // Base ID
			'Popular post', // Name
			array('description' => __( 'Displays the popular & Most commented post'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		$title_recentcomment = $instance['title_recentcomment'];
		$title_popularpost = $instance['title_popularpost'];
		
		//echo $before_widget;
		$title = apply_filters( 'widget_title', $instance['title'] );


		$before_title = '<div class="side-widget"><h4>';
	   $after_title = '</h4>';
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}
		else
		{
			echo $before_title . $after_title;
		}
		
		$this->getRealtyListings($posts_num,$show_content,$content_limit,$more_text,$show_image,$title,$title_recentcomment,$title_popularpost);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		$instance['title_recentcomment'] = strip_tags($new_instance['title_recentcomment']);
		$instance['title_popularpost'] = strip_tags($new_instance['title_popularpost']);
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		$title_recentcomment = esc_attr($instance['title_recentcomment']);
		$title_popularpost = esc_attr($instance['title_popularpost']);
		
	} else {
		$title = '';
		$posts_num = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		$title_recentcomment = '';
		$title_popularpost = '';
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		
		<p>
		<label for="<?php echo $this->get_field_id('title_popularpost'); ?>"><?php _e('Title Popular Post', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title_popularpost'); ?>" name="<?php echo $this->get_field_name('title_popularpost'); ?>" type="text" value="<?php echo $title_popularpost; ?>" />
		</p>
		
		<p>
		<label for="<?php echo $this->get_field_id('title_recentcomment'); ?>"><?php _e('Title Recent Comment Post', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title_recentcomment'); ?>" name="<?php echo $this->get_field_name('title_recentcomment'); ?>" type="text" value="<?php echo $title_recentcomment; ?>" />
		</p>
		
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>

	
			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
			<?php
	
	}

	function getRealtyListings($posts_num,$show_content,$content_limit,$more_text,$show_image,$title,$title_recentcomment,$title_popularpost) { //html
		global $post;
	
if ( empty( $posts_num ) ) {
	$posts_num = 1;
	
	}
		
	$listings = new WP_Query();
	$listings->query('post_type=post&meta_key=post_views_count&orderby=meta_value_num&order=DESC&posts_per_page=' . $posts_num);
			
		if($listings->found_posts > 0) {
	?>
						<div role="tabpanel">
							<!-- Nav tabs -->
							<ul class="nav nav-tabs nav-justified" role="tablist">
								<li role="presentation" class="active">
									<a href="#popular" aria-controls="popular" role="tab" data-toggle="tab"><?php echo $title_popularpost; ?></a>
								</li>
								<li role="presentation">
									<a href="#commented" aria-controls="commented" role="tab" data-toggle="tab"><?php echo $title_recentcomment; ?></a>
								</li>
								
							</ul>
							<!-- Tab panes -->
							<div class="tab-content">
							<div role="tabpanel" class="tab-pane active fade in" id="popular">
							<?php
							
							$i = 0;
							while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					
					if($i ==0)
					{
					
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
	
			?>
					<article class="style4">
					<div class="small-title cat"><?php the_category(); ?></div>
										<a href="<?php echo the_permalink(); ?>" itemprop="url">
											<div class="overlay overlay-02"></div>
											<div class="post-thumb">												
												<div class="post-excerpt">
													<div class="meta">
														<span class="date" itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
													</div>
													<h3 class="text-white" itemprop="headline"><?php echo the_title();?></h3>
												</div>
												<?php 
												genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
		?>
											</div>
										</a>
									</article>
			<?php
			
		}
		
		if($i ==1)
		{
			?>
			<div class="mini-posts">	
					<article class="style2">
											<div class="row">
														<?php
														if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			echo '<div class="col-md-4 col-sm-4">';
		echo '<a href="'.get_the_permalink().'" itemprop="url">';
			
	echo '<div class="article-thumb">';
		
		genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
		

		
	
		echo '</div></a></div>';
	
		}
  	?>
												<div class="col-md-8 col-sm-8">
													<div class="post-excerpt no-padding">
														<div class="meta">
															<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
														</div>
														<h5><a href="<?php echo the_permalink(); ?>" itemprop="headline"><?php the_title();?></a></h5>
													</div>
												</div>
											</div>
											<?php
											
											echo '<p>';	
					
					
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
	echo '</p>';
											
											?>
										</article>
			<?php
		}
				
				if($i !=0 && $i !=1)
		{
			?>
			<article class="style2">
		<div class="row">
				<?php
			if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			echo '<div class="col-md-4 col-sm-4">';
		echo '<a href="'.get_the_permalink().'" itemprop="url">';
			
	echo '<div class="article-thumb">';
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
	echo '</div></a></div>';
	
		}
				?>
												<div class="col-md-8 col-sm-8">
													<div class="post-excerpt no-padding">
														<div class="meta">
															<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
														</div>
														<h5><a href="<?php echo the_permalink(); ?>" itemprop="headline"><?php the_title();?></a></h5>
													</div>
												</div>
											</div>
											<?php
											
											echo '<p>';	
					
					
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
	echo '</p>';
			?>
		</article>
				<?php
		}	

				$i++;
							}
							wp_reset_query();
							?>
								</div>		
								</div>
								<div role="tabpanel" class="tab-pane fade in" id="commented">
								<?php
							
							$i = 0;
						
					
							$listings1 = new WP_Query();
		$listings1->query('post_type=post&orderby=comment_count&meta_value_num&order=DESC&posts_per_page=' . $posts_num);	
							
							while ($listings1->have_posts() && $i<$posts_num) {
					
					
					
					$listings1->the_post();
					
					if($i ==0)
					{
					
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
				?>
					<article class="style4">
						<div class="small-title cat"><?php the_category(); ?></div>
										<a itemprop="url" href="<?php echo the_permalink(); ?>">
											<div class="overlay overlay-02"></div>
											<div class="post-thumb">												
												<div class="post-excerpt">
													<div class="meta">
														<span class="date" itemprop="datePublished"><?php echo the_date('M j, Y'); ?></span>
													</div>
													<h3 class="text-white" itemprop="headline"><?php the_title();?></h3>
												</div>
												<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
				</div>
										</a>
									</article>
				<?php
				
				
		}
		
		if($i ==1)
		{
			?>
			<div class="mini-posts">	
					<article class="style2">
											<div class="row">
											<?php
														if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			echo '<div class="col-md-4 col-sm-4">';
		echo '<a href="'.get_the_permalink().'" itemprop="url">';
			
	echo '<div class="article-thumb">';
		

	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
	
	
		echo '</div></a></div>';
	
		}
														?>
												<div class="col-md-8 col-sm-8">
													<div class="post-excerpt no-padding">
														<div class="meta">
															<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
														</div>
														<h5 itemprop="headline"><a href="<?php echo the_permalink(); ?>"><?php the_title();?></a></h5>
													</div>
												</div>
											</div>
											<?php
											
											echo '<p>';	
					
					
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
	echo '</p>';
											
											?>
										</article>
			<?php
		}
				
				
				if($i !=0 && $i !=1)
		{
			?>
					<article class="style2">
											<div class="row">
														<?php
														if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			echo '<div class="col-md-4 col-sm-4">';
		echo '<a href="'.get_the_permalink().'" itemprop="url">';
			
	echo '<div class="article-thumb">';
 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
		
	
		echo '</div></a></div>';
	
		}
														?>
												<div class="col-md-8 col-sm-8">
													<div class="post-excerpt no-padding">
														<div class="meta">
															<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
														</div>
														<h5 itemprop="headline"><a href="<?php echo the_permalink(); ?>"><?php the_title();?></a></h5>
													</div>
												</div>
											</div>
											<?php
											
											echo '<p>';	
					
					
				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
	echo '</p>';
											
											?>
										</article>
			<?php
		}	

				$i++;
							}
							
							?>
							</div>		
								</div>
							</div>
						</div>
						<!-- TABS -->
	<?php
		}
	}	
}
register_widget('popular_post_widget');
 /*end of most popular and recent comment posts */


 
 /* code for home page starts here */
 
 
 //home slider code
 
 class homeslider extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homeslider', // Base ID
			'Home slider', // Name
			array('description' => __( 'To display the home slider'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$posttype = $instance['posttype'];
		
		
		//echo $before_widget;
		// Check if title is set
		$title = apply_filters( 'widget_title', $instance['title'] );
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);

		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$posttype = esc_attr($instance['posttype']);

		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$posttype = '';
	

	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
	  <p>
  <label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
	<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
		<option value="NOT IN" <?php selected( 'NOT IN', $instance['posttype'] ); ?>><?php _e( 'Post', 'genesis' ); ?></option>
		<option value="IN" <?php selected( 'IN', $instance['posttype'] ); ?>><?php _e( 'Video', 'genesis' ); ?></option>
		<option value="" <?php selected( '', $instance['posttype'] ); ?>><?php _e( 'Both', 'genesis' ); ?></option>
		</select>
	</p>
	
	
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
           				
	<?php
	
	}
	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$posttype) { //html
		global $post;
	
		
	if ( empty( $posts_num ) ) {
	$posts_num = 1;
	
	}
$excategory_id = get_cat_ID('movie');
	
		$listings = new WP_Query( array(
       'post_type' => 'post',
	     'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset,
		'cat' => $posts_cat,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );
	

	//$listings = new WP_Query();	
	//$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);

		
		if($listings->found_posts > 0) {

			?>
		<div class="container-fluid no-padding">
		<div class="home-slider-wrap">
		<div class="home-slider">
		<?php

				while ($listings->have_posts()) {

					$listings->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'homeslider' ); 
					$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					
					?>
						<div>
			<article class="style3 single text-center no-margin">
					<div class="overlay overlay-02"></div>
					<div class="post-thumb">
						<div class="container">
						<div class="post-excerpt">
							<div class="small-title cat"><?php the_category(); ?></div>

							<a itemprop="url" href="<?php echo get_the_permalink(); ?>"><h3 class="h3 text-white" itemprop="headline"><?php echo get_the_title(); ?></h3></a>
							<div class="meta">
								<span class="author"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/avatar/1.jpg" class="img-circle" alt=""> by <?php echo $display_name ?></span>
								<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
							</div>
							<div class="meta">
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
								<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
							</div>

						</div>
						</div>
						<?php
						 $image1 = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
					
	genesis_markup( array(
    'html5'   => '<img class="bg-img img-responsive" sizes="(min-width: 780px) 1349px, (max-width: 768px) 220px, (min-width: 460px) 420px, 100vw"
     srcset="'.$image1[0].' 420w,    
             '. $image[0].' 1349w,    
            '. $image1[0].' 260w,    
             '. $image1[0].' 220w"    
        src="'. $image[0].'"
        alt=""
%s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
					</div>
			</article>
		</div>
				<?php	
	
					
				}
				?>
			</div>
		<div class="hs-prev"><i class="fa fa-angle-left"></i></div>
		<div class="hs-next"><i class="fa fa-angle-right"></i></div>
		</div>
	</div>
				<?php
		
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homeslider');

/*end of slider code */

  //home top 1 code
 
 class hometop1 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'hometop1', // Base ID
			'Home Top 1', // Name
			array('description' => __( 'To display the home posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_cat1 = $instance['posts_cat1'];
		$posts_cat2 = $instance['posts_cat2'];
		$posts_offset1 = $instance['posts_offset1'];
		$posts_offset2 = $instance['posts_offset2'];
		$posttype = $instance['posttype'];
		
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );



		
		
		$this->getRealtyListings($posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_cat1'] = strip_tags($new_instance['posts_cat1']);
		$instance['posts_cat2'] = strip_tags($new_instance['posts_cat2']);
		$instance['posts_offset1'] = strip_tags($new_instance['posts_offset1']);
		$instance['posts_offset2'] = strip_tags($new_instance['posts_offset2']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
	
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_cat1 = esc_attr($instance['posts_cat1']);
		$posts_cat2 = esc_attr($instance['posts_cat2']);
		$posts_offset1 = esc_attr($instance['posts_offset1']);
		$posts_offset2 = esc_attr($instance['posts_offset2']);
		$posttype = esc_attr($instance['posttype']);
		
		
	} else {
		$title = '';
		$posts_cat1 = '';
		$posts_cat2 = '';
		$posts_offset1 = '';
		$posts_offset2 = '';
		$posttype = '';
			
		
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
			  <p>
  <label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
	<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
		<option value="NOT IN" <?php selected( 'NOT IN', $instance['posttype'] ); ?>><?php _e( 'Post', 'genesis' ); ?></option>
		<option value="IN" <?php selected( 'IN', $instance['posttype'] ); ?>><?php _e( 'Video', 'genesis' ); ?></option>
		<option value="" <?php selected( '', $instance['posttype'] ); ?>><?php _e( 'Both', 'genesis' ); ?></option>
		</select>
	</p>
		
	<fieldset style="border: 1px solid #ccc;padding: 10px;">
	<legend> Section 1</legend>

		
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset1' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset1'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat1' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat1' ),
						'id'              => $this->get_field_id( 'posts_cat1' ),
						'selected'        => $instance['posts_cat1'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
          					
			</fieldset>	
			<fieldset style="border: 1px solid #ccc;padding: 10px;">
	<legend> Section 2</legend>

		
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset2' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset2'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat2' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat2' ),
						'id'              => $this->get_field_id( 'posts_cat2' ),
						'selected'        => $instance['posts_cat2'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
         				
			</fieldset>	
	<?php
	
	}
	

	function getRealtyListings($posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$posttype) { //html
		global $post;
	
	?>
	<div class="bg-dark">
	<div class="container">
		<div class="space60"></div>
		<div class="row">
		<?php
	
	if ( empty( $posts_num ) ) {
	$posts_num = 1;
	
	}

	
$posts_num = 1;
	$excategory_id = get_cat_ID('movie');
		
			$listings1 = new WP_Query( array(
       'post_type' => 'post',
	     'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset1,
		'cat' => $posts_cat1,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );
	//$listings1 = new WP_Query();
	//$listings1->query('post_type=post&cat='.$posts_cat1.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset1);


		
		if($listings1->found_posts > 0) {

			?>
		<?php

				while ($listings1->have_posts()) {

					$listings1->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'singlepage' ); 
							
								$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					
					?>
					<div class="col-md-6">
				<article class="style3 article-home">
				<div class="small-title cat"><?php the_category(); ?></div>
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">							
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h3 itemprop="headline" class="h3 text-white"><?php echo get_the_title(); ?></h3>
								<div class="meta">
									<span class="author"><img src="<?php echo get_stylesheet_directory_uri();?>/img/avatar/1.jpg" class="img-circle" alt=""> by <?php echo $display_name ?></span>
									<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
									<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
								</div>
							</div>
													<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
			</div>
			<?php	
	
					
				}
					
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found 1</p>';
		}



	$posts_num = 4;
		$excategory_id = get_cat_ID('movie');
	 
	//$listings2 = new WP_Query();
	//$listings2->query('post_type=post&cat='.$posts_cat2.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset2);
		$listings2 = new WP_Query( array(
       'post_type' => 'post',
	    'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset2,
		'cat' => $posts_cat2,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );

		
		if($listings2->found_posts > 0) {

$i=0;
				while ($listings2->have_posts() && $i<$posts_num) {

					$listings2->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
							
								$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					?>
					<div class="col-md-3 col-sm-6">
					<?php
					if($i==0)
					{
						?>
							<article class="style4">
							<div class="small-title cat"><?php the_category(); ?></div>
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">							
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
							</div>
																				<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
						
						<?php
					}
					if($i==1)
					{
					?>
		      						<article class="style4">
									<div class="small-title cat"><?php the_category(); ?></div>
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">							
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
							</div>
<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
			<?php
					}
		          ?>
				  </div>
					<div class="col-md-3 col-sm-6">
					<?php
					if($i==2)
					{
						?>
						<article class="style4">
						<div class="small-title cat"><?php the_category(); ?></div>
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">							
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
							</div>
																				<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
				<?php
					}
					if($i==3)
					{
					?>
		   						<article class="style4">
								<div class="small-title cat"><?php the_category(); ?></div>
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
						<div class="overlay overlay-02"></div>
						<div class="post-thumb">
							<div class="post-excerpt">
								<div class="meta">
									<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
								</div>
								<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
							</div>
																				<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
					</a>
				</article>
				 <?php
					}
		          ?>
				 </div>
		<?php
		$i++;
				}
		wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		}
				?>
		</div>
		<div class="space30"></div>
	</div>
</div>
<?php		
	}
	
} 
register_widget('hometop1');

/*end of home top 1 code */

 // Home top 2 code
 
 class hometop2 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'hometop2', // Base ID
			'Home Top 2', // Name
			array('description' => __( 'To display the home posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_cat1 = $instance['posts_cat1'];
		$posts_cat2 = $instance['posts_cat2'];
		$posts_offset1 = $instance['posts_offset1'];
		$posts_offset2 = $instance['posts_offset2'];
		$posttype = $instance['posttype'];


		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );

		
		$this->getRealtyListings($posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_cat1'] = strip_tags($new_instance['posts_cat1']);
		$instance['posts_cat2'] = strip_tags($new_instance['posts_cat2']);
		$instance['posts_offset1'] = strip_tags($new_instance['posts_offset1']);
		$instance['posts_offset2'] = strip_tags($new_instance['posts_offset2']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);


		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_cat1 = esc_attr($instance['posts_cat1']);
		$posts_cat2 = esc_attr($instance['posts_cat2']);
		$posts_offset1 = esc_attr($instance['posts_offset1']);
		$posts_offset2 = esc_attr($instance['posts_offset2']);
		$posttype = esc_attr($instance['posttype']);
	

		
	} else {
		$title = '';
		$posts_cat1 = '';
		$posts_cat2 = '';
		$posts_offset1 = '';
		$posts_offset2 = '';
		$posttype = '';
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
			  <p>
  <label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
	<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
		<option value="NOT IN" <?php selected( 'NOT IN', $instance['posttype'] ); ?>><?php _e( 'Post', 'genesis' ); ?></option>
		<option value="IN" <?php selected( 'IN', $instance['posttype'] ); ?>><?php _e( 'Video', 'genesis' ); ?></option>
		<option value="" <?php selected( '', $instance['posttype'] ); ?>><?php _e( 'Both', 'genesis' ); ?></option>
		</select>
	</p>
		
	<fieldset style="border: 1px solid #ccc;padding: 10px;">
	<legend> Section 1</legend>

		
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset1' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset1'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat1' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat1' ),
						'id'              => $this->get_field_id( 'posts_cat1' ),
						'selected'        => $instance['posts_cat1'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
             				
			</fieldset>	
			<fieldset style="border: 1px solid #ccc;padding: 10px;">
	<legend> Section 2</legend>

		
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset2' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset2'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat2' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat2' ),
						'id'              => $this->get_field_id( 'posts_cat2' ),
						'selected'        => $instance['posts_cat2'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
               				
			</fieldset>	
	<?php
	
	}
	

	function getRealtyListings($posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$posttype) { //html
		global $post;
	
	?>
	<div class="container">
	<div class="row">
		<?php
	
	if ( empty( $posts_num ) ) {
	$posts_num = 1;
	
	}

	
	$excategory_id = get_cat_ID('movie');
	
	$posts_num = 1;
	//$listings1 = new WP_Query();
	//$listings1->query('post_type=post&cat='.$posts_cat1.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset1);
		$listings1 = new WP_Query( array(
       'post_type' => 'post',
	    'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset1,
		'cat' => $posts_cat1,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );

		
		if($listings1->found_posts > 0) {


				while ($listings1->have_posts()) {

					$listings1->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'hometop2' ); 
							
								$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					
					?>
						<div class="col-md-8 col-sm-8">
					<article class="style3 style-alt">
					<div class="small-title cat"><?php the_category(); ?></div>
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="overlay overlay-02"></div>
							<div class="post-thumb">								
								<div class="post-excerpt">
									<div class="meta">
										<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h3 itemprop="headline" class="h3 text-white"><?php echo get_the_title(); ?></h3>
									<div class="meta">
										<span class="author"><img src="<?php echo get_stylesheet_directory_uri();?>/img/avatar/1.jpg" class="img-circle" alt=""> by <?php echo $display_name ?></span>
										<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
										<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
									</div>
								</div>
																					<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
							</div>
						</a>
					</article>
				</div>	
				<?php	
	
				}
					
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found 1</p>';
		}




	$posts_num = 2;
			$excategory_id = get_cat_ID('movie');
	
	//$listings2 = new WP_Query();
	//$listings2->query('post_type=post&cat='.$posts_cat2.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset2);
		$listings2 = new WP_Query( array(
       'post_type' => 'post',
	    'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset2,
		'cat' => $posts_cat2,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );

		?>
		<div class="col-md-4 col-sm-4">
		<?php
		if($listings2->found_posts > 0) {

      		while ($listings2->have_posts() && $i<$posts_num) {

					$listings2->the_post();
					
						$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
							
								$display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
					?>
					<article class="style4 style-alt margin-bottom-25">
					<div class="small-title cat"><?php the_category(); ?></div>
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="overlay overlay-02"></div>
							<div class="post-thumb">								
								<div class="post-excerpt">
									<div class="meta">
										<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
								</div>
						<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
?>
							</div>
						</a>
					</article>
<?php
		
				}
		wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		}
				?>
		</div>
		</div>
		</div>
<?php		
	}
	
} 
register_widget('hometop2');

/*end of home top 2 code */

 /* Home style 1 section */

class homestyle1 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle1', // Base ID
			'Home style 1', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		$posttype = $instance['posttype'];
		
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$title,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
	
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		$posttype = esc_attr($instance['posttype']);

		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		$posttype = '';
		
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
			  <p>
  <label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
	<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
		<option value="NOT IN" <?php selected( 'NOT IN', $instance['posttype'] ); ?>><?php _e( 'Post', 'genesis' ); ?></option>
		<option value="IN" <?php selected( 'IN', $instance['posttype'] ); ?>><?php _e( 'Video', 'genesis' ); ?></option>
		<option value="" <?php selected( '', $instance['posttype'] ); ?>><?php _e( 'Both', 'genesis' ); ?></option>
		</select>
	</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
			

			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
	<?php
	
	}
	
	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$title,$posttype) { //html
		global $post;
	

	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
	$excategory_id = get_cat_ID('movie');
	
	//$listings = new WP_Query();
	//$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);	
		$listings = new WP_Query( array(
       'post_type' => 'post',
	    'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset,
		'cat' => $posts_cat,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );
		
		if($listings->found_posts > 0) {
		
			?>
			<!-- HOME SECTION 1 -->
			<div class="padding-top-60">
				<h3 class="margin-bottom-15"><b><?php echo $title; ?></b></h3>
				<div class="row">
		<?php
			
		$i=0;;
				while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					
					
					if($i==0)
					{
						
						
					?>
									<div class="col-md-6">
						<article class="article-home style-alt">
								<?php
				
					
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
		?>
			<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
								<div class="article-thumb">
			<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
								</div>
							</a>
							<div class="post-excerpt">
								<div class="small-title cat"><?php the_category(); ?></div>
								<h4 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
								<div class="meta">
									<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
                                      if ( empty( $display_name ) )
                                      $display_name = get_the_author_meta( 'nickname', $post->post_author );
                                          echo $display_name?></a></span>
									<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
									<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
								</div>
							<p>
								<?php
								
									if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
?>
								</p>
							</div>
						</article>
					</div>	
	<div class="col-md-6">
						<div class="mini-posts">
				<?php	
				}
				?>
				<?php
		
		
			if($i != 0)
		{
		?>
					<article class="style2 style-alt">
								<div class="row">
					<?php
				
					
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
		?>
			<div class="col-md-4 col-sm-4">
										<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
											<div class="article-thumb">
											<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
			
?>
											</div>
										</a>
									</div>
		<?php
	
		}
			
			
				?>
									<div class="col-md-8 col-sm-8">
										<div class="post-excerpt no-padding">
											<div class="meta">
												<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
											</div>
											<h5 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
											<div class="meta">
												<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
											</div>
										</div>
									</div>
								</div>
							</article>
<?php		
			
		}
		
		$i++;
		
		
				}
		?>
		</div>
		</div>
		</div>
			</div>
		<?php
		
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homestyle1');

/*end of Home style 1 section  */

 
 /* start of home style 2 section */
class homestyle2 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle2', // Base ID
			'Home style 2', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$posttype = $instance['posttype'];
		
		
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$title,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);

		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$posttype = esc_attr($instance['posttype']);

		
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$posttype = '';

		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
			  <p>
  <label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
	<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
		<option value="NOT IN" <?php selected( 'NOT IN', $instance['posttype'] ); ?>><?php _e( 'Post', 'genesis' ); ?></option>
		<option value="IN" <?php selected( 'IN', $instance['posttype'] ); ?>><?php _e( 'Video', 'genesis' ); ?></option>
		<option value="" <?php selected( '', $instance['posttype'] ); ?>><?php _e( 'Both', 'genesis' ); ?></option>
		</select>
	</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
	

			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$title,$posttype) { //html
		global $post;
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	$excategory_id = get_cat_ID('movie');
	
	//$listings = new WP_Query();
	//$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
		$listings = new WP_Query( array(
       'post_type' => 'post',
	     'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset,
		'cat' => $posts_cat,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );
		
		
		if($listings->found_posts > 0) {
		
			?>
		<!-- HOME SECTION 2 -->
			<h4 class="margin-bottom-15"><b><?php echo $title; ?></b></h4>
			<div class="row padding-bottom-30">
		<?php
			
					while ($listings->have_posts()) {
										
					$listings->the_post();
					$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
				

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
					?>
					<div class="col-md-4 col-sm-4">
						<article class="style2 style-alt">
							<div class="margin-bottom-15">
								<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
									<div class="article-thumb">
								<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
			
	genesis_markup(array(
	'close' => ''
));	
					
?>
						</div>
								</a>
							</div>
							<div>
								<div class="post-excerpt no-padding">
									<div class="meta">
										<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h5 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
									<p>
									<?php 
												if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
			?>
									</p>
								</div>
							</div>
						</article>
					</div>
				<?php	
					
		
				}
				?>
			</div>
			<?php
		
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homestyle2');

/*end of Home style 2 section code */

 
 
 
 /*start of Home style 3 section code */
 
 class homestyle3 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle3', // Base ID
			'Home style 3', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		
		
		$title1 = $instance['title1'];
		$title2 = $instance['title2'];
		
		$posts_num = $instance['posts_num'];
		
		$posts_cat1 = $instance['posts_cat1'];
		$posts_cat2 = $instance['posts_cat2'];
		
		$posts_offset1 = $instance['posts_offset1'];
		$posts_offset2 = $instance['posts_offset2'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		$select_design = $instance['select_design'];
		$posttype = $instance['posttype'];
	
		
		//echo $before_widget;
		// Check if title is set
		
		$this->getRealtyListings($title1,$title2,$posts_num,$posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$show_content,$content_limit,$more_text,$show_image,$select_design,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		
		$instance['title1'] = strip_tags($new_instance['title1']);
		$instance['title2'] = strip_tags($new_instance['title2']);
		
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		
		$instance['posts_cat1'] = strip_tags($new_instance['posts_cat1']);
		$instance['posts_cat2'] = strip_tags($new_instance['posts_cat2']);
		
		$instance['posts_offset1'] = strip_tags($new_instance['posts_offset1']);
		$instance['posts_offset2'] = strip_tags($new_instance['posts_offset2']);
		
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		$instance['select_design'] = strip_tags($new_instance['select_design']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
	
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title1 = esc_attr($instance['title1']);
		$title2 = esc_attr($instance['title2']);
		$posts_num = esc_attr($instance['posts_num']);
		
		$posts_cat1 = esc_attr($instance['posts_cat1']);
		$posts_cat2 = esc_attr($instance['posts_cat2']);
		
		$posts_offset1 = esc_attr($instance['posts_offset1']);
		$posts_offset2 = esc_attr($instance['posts_offset2']);
		
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		$select_design = esc_attr($instance['select_design']);
		$posttype = esc_attr($instance['posttype']);

		
	} else {
		$title1 = '';
		$title2 = '';
		
		$posts_num = '';
		
		$posts_cat1 = '';
		$posts_cat2 = '';
		
		$posts_offset1 = '';
		$posts_offset2 = '';
		
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		$select_design = '';
		$posttype = '';

		
		
		
		
	}
	?>
		  <p>
  <label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
	<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
		<option value="NOT IN" <?php selected( 'NOT IN', $instance['posttype'] ); ?>><?php _e( 'Post', 'genesis' ); ?></option>
		<option value="IN" <?php selected( 'IN', $instance['posttype'] ); ?>><?php _e( 'Video', 'genesis' ); ?></option>
		<option value="" <?php selected( '', $instance['posttype'] ); ?>><?php _e( 'Both', 'genesis' ); ?></option>
		</select>
	</p>
	
<fieldset style="border: 1px solid #ccc;padding: 10px;">
  <legend>Section 1:</legend>
 <p>
		<label for="<?php echo $this->get_field_id('title1'); ?>"><?php _e('Title ', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title1'); ?>" name="<?php echo $this->get_field_name('title1'); ?>" type="text" value="<?php echo $title1; ?>" />
		</p>
  <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>"><?php _e( 'Number of Posts to Offset ', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset1' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset1' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset1'] ); ?>" size="2" />
				</p>
  <p>
						<label for="<?php echo $this->get_field_id( 'posts_cat1' ); ?>"><?php _e( 'Category '); ?>:</label>
					<?php
					$categories_args1 = array(
						'name'            => $this->get_field_name( 'posts_cat1' ),
						'id'              => $this->get_field_id( 'posts_cat1' ),
						'selected'        => $instance['posts_cat1'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args1 ); ?>
				</p>
	
 </fieldset>
	
<fieldset style="border: 1px solid #ccc;padding: 10px;">
  <legend>Section 2:</legend>	
	<p>
		<label for="<?php echo $this->get_field_id('title2'); ?>"><?php _e('Title ', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title2'); ?>" name="<?php echo $this->get_field_name('title2'); ?>" type="text" value="<?php echo $title2; ?>" />
		</p>
	
					<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>"><?php _e( 'Number of Posts to Offset ', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset2' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset2' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset2'] ); ?>" size="2" />
				</p>
				
				
				
				
				<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat2' ); ?>"><?php _e( 'Category '); ?>:</label>
					<?php
					$categories_args2 = array(
						'name'            => $this->get_field_name( 'posts_cat2' ),
						'id'              => $this->get_field_id( 'posts_cat2' ),
						'selected'        => $instance['posts_cat2'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args2 ); ?>
				</p>
			
				
 </fieldset>	
		<fieldset style="border: 1px solid #ccc;padding: 10px;">
  <legend>Other Options:</legend>	
	
			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'select_design' ) ); ?>"><?php _e( 'Design Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'select_design' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'select_design' ) ); ?>">
						<option value="design1" <?php selected( 'design1', $instance['select_design'] ); ?>><?php _e( 'design1', 'genesis' ); ?></option>
						<option value="design2" <?php selected( 'design2', $instance['select_design'] ); ?>><?php _e( 'design2', 'genesis' ); ?></option>
			
					</select>
				
				</p>
		<p>

			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				
		</p>
			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
			 </fieldset>		
	<?php
	
	}

	function getRealtyListings($title1,$title2,$posts_num,$posts_cat1,$posts_cat2,$posts_offset1,$posts_offset2,$show_content,$content_limit,$more_text,$show_image,$select_design,$posttype) { //html
		global $post;
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
	?>
		<!-- HOME SECTION 3 -->
			<div class="row">
<?php
$excategory_id = get_cat_ID('movie');
	 
	//$listings1 = new WP_Query();
	//$listings1->query('post_type=post&cat='.$posts_cat1.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset1);	
		$listings1 = new WP_Query( array(
       'post_type' => 'post',
	     'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset1,
		'cat' => $posts_cat1,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );
		
		
		if($listings1->found_posts > 0) {
		?>
					<div class="col-md-6 col-sm-6">
					<h4 class="margin-bottom-15"><b><?php echo $title1 ?></b></h4>
		<?php

	$i = 0;
	
				while ($listings1->have_posts() && $i<$posts_num) {
										
					$listings1->the_post();
					
					$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 			
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
					
					
					if($i == 0)
					{
						if($select_design == 'design1')
						{
					?>
				
				<article class="article-home style-alt margin-bottom-10">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="article-thumb">
							<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
	
					
?>
							</div>
						</a>
						<div class="post-excerpt">
							<div class="small-title cat"><?php the_category(); ?></div>
							<h4 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
							<div class="meta">
								<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name;
?></a></span>
								<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
							</div>
							<p>
							<?php 
							
										if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
					?>
							</p>
						</div>
					</article>
						<?php
						}
						if($select_design == 'design2')
						{
							?>
							<article class="style4 style-alt margin-bottom-10">
							<div class="small-title cat"><?php the_category(); ?></div>
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="overlay overlay-02"></div>
							<div class="post-thumb">								
								<div class="post-excerpt">
									<div class="meta">
										<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
								</div>
								<img src="<?php echo $image[0]; ?>" class="bg-img img-responsive" alt="">
							</div>
						</a>
					</article>
							<?php
						}
						?>
			<div class="mini-posts">				
				<?php	
					}
					if($i != 0)
					{
						
						if ( !$show_image && $image ) 
						{
						?>
						<style>
						article.article-home.style-alt.margin-bottom-10
						{
							margin-bottom:-10px !important;
						}
						</style>
						<a itemprop="url" class="list-posts-custom" href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
				<?php
					
					}
					

					if ($show_image && $image ) 
					{
						
					?>
							<article class="style2 style-alt">
							<div class="row">
							<?php
									if ( $show_image && $image ) {
			

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	?>
			<div class="col-md-4 col-sm-4">
									<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
										<div class="article-thumb">
									<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
				
?>
										</div>
									</a>
								</div>					
	<?php
	
		}
			?>					
								<div class="col-md-8 col-sm-8">
									<div class="post-excerpt no-padding">
										<div class="meta">
											<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
										</div>
										<h5 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
										<div class="meta">
											<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
										</div>
									</div>
								</div>
							</div>
						</article>
				<?php	
					}
					}
				$i ++;
				}
				?>
				</div>
			</div>
			<?php
		
			wp_reset_postdata(); 
		}
		
		else{
			echo '<p style="padding:25px;">No listing found</p>';
	
	} 
	
	$excategory_id = get_cat_ID('movie');
	 
	///this is section 2 code

	//$listings2 = new WP_Query();
	//$listings2->query('post_type=post&cat='.$posts_cat2.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset2);	
		$listings2 = new WP_Query( array(
       'post_type' => 'post',
	    'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset2,
		'cat' => $posts_cat2,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );
		
		if($listings2->found_posts > 0) {
			
			
			?>
					<div class="col-md-6 col-sm-6">
					<h4 class="margin-bottom-15"><b><?php echo $title2 ?></b></h4>
		<?php
			
	
	
	$i = 0;
	
				while ($listings2->have_posts() && $i<$posts_num) {
										
					$listings2->the_post();
					
					$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 			
					 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
					
					
					if($i == 0)
					{
						if($select_design == 'design1')
						{
					?>
				<article class="article-home style-alt margin-bottom-10">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="article-thumb">
					<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
					</div>
						</a>
						<div class="post-excerpt">
							<div class="small-title cat"><?php the_category(); ?></div>
							<h4 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
							<div class="meta">
								<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name;
?></a></span>
								<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
							</div>
							<p>
							<?php 
							
										if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
			?>
							</p>
						</div>
					</article>	
						<?php
						}
						if($select_design == 'design2')
						{
							?>
							<article class="style4 style-alt margin-bottom-10">
								<div class="small-title cat"><?php the_category(); ?></div>
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="overlay overlay-02"></div>
							<div class="post-thumb">							
								<div class="post-excerpt">
									<div class="meta">
										<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
									</div>
									<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
								</div>
								<img src="<?php echo $image[0]; ?>" class="bg-img img-responsive" alt="">
							</div>
						</a>
					</article>
							<?php
						}
						?>
				<div class="mini-posts">				
				<?php	
					}
					if($i != 0)
					{
						
						if ( !$show_image && $image ) 
						{
						?>
						<style>
						article.article-home.style-alt.margin-bottom-10
						{
							margin-bottom:-10px !important;
						}
						</style>
						<a class="list-posts-custom" href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
					<?php
					
					}
					

					if ($show_image && $image ) 
					{
						
					?>
							<article class="style2 style-alt">
							<div class="row">
								<?php
									if ( $show_image && $image ) {
			

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
			
		?>
			<div class="col-md-4 col-sm-4">
									<a href="<?php echo get_the_permalink(); ?>">
										<div class="article-thumb">
										<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
							</div>
									</a>
								</div>					
	<?php
	
		}
			?>					
								<div class="col-md-8 col-sm-8">
									<div class="post-excerpt no-padding">
										<div class="meta">
											<span itemprop="datePublished"><?php echo get_the_date('M j, Y'); ?></span>
										</div>
										<h5 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h5>
										<div class="meta">
											<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
										</div>
									</div>
								</div>
							</div>
						</article>
				<?php	
					}
					}
				$i ++;
				}
				?>
				</div>
			</div>
				<?php
		
			wp_reset_postdata(); 
		}
		
		else{
			echo '<p style="padding:25px;">No listing found</p>';
	
	} 
	?>
		</div>		
			<!-- // HOME SECTION 3 -->  
<?php
	
	}

} 
register_widget('homestyle3');

/*end of Homme style 3 posts code */
 
 
 
 /*start of home style 4 posts code */
 
class homestyle4 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle4', // Base ID
			'Home style 4', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		$posttype = $instance['posttype'];
	
		
		//echo $before_widget;
		// Check if title is set
		
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$title,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
	
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		$posttype = esc_attr($instance['posttype']);
		
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		$posttype = '';
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
			  <p>
  <label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
	<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
		<option value="NOT IN" <?php selected( 'NOT IN', $instance['posttype'] ); ?>><?php _e( 'Post', 'genesis' ); ?></option>
		<option value="IN" <?php selected( 'IN', $instance['posttype'] ); ?>><?php _e( 'Video', 'genesis' ); ?></option>
		<option value="" <?php selected( '', $instance['posttype'] ); ?>><?php _e( 'Both', 'genesis' ); ?></option>
		</select>
	</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
     	
				

			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
<?php
	
	}

	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image,$title,$posttype) { //html
		global $post;
	
	
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
	
	$excategory_id = get_cat_ID('movie');

	//$listings = new WP_Query();
	//$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
		$listings = new WP_Query( array(
       'post_type' => 'post',
	    'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset,
		'cat' => $posts_cat,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );
		if($listings->found_posts > 0) {
			
			
			?>
	  <div style="padding-top:60px;">
	
		<h3 class="margin-bottom-15"><b><?php echo $title ?></b></h3>
		<?php
			
			$i = 0;
	
				while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					
					if($i == 0)
					{
								$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
			 	
		
		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'singlepage' ); 
					?>
					<article class="style3 style-alt">
						<div class="small-title cat"><?php the_category(); ?></div>
				<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
					<div class="overlay overlay-02"></div>
					<div class="post-thumb">					
						<div class="post-excerpt">
							<div class="meta">
								<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
							</div>
							<h3 itemprop="headline" class="h3 text-white"><?php echo get_the_title(); ?></h3>
							<div class="meta">
								<span class="author"><img src="<?php echo get_stylesheet_directory_uri(); ?>/img/avatar/1.jpg" class="img-circle" alt=""> <?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name;
?></span>
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No';
                                     }
                                      ?></span>
								<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
							</div>
						</div>
						<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
?>
					</div>
				</a>
			</article>	
				<?php
					
					}
					
					if($i !=0)
					{
						
						
					?>
	<article class="style2" id="homestylefour">
				<div class="row">
				<?php 
					
								$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					 	
					
					
					
	if ( $show_image && $image ) {
		

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
		
			
		?>
		<div class="col-md-4 col-sm-4">
						<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
							<div class="article-thumb">
<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
				</div>
						</a>
					</div>
		<?php
	
		}
					?>
					<div class="col-md-8 col-sm-8">
						<div class="post-excerpt">
							<div class="small-title cat"><?php the_category(); ?></div>
							<h3 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
							<div class="meta">
								<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name;
?></a></span>
								<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
								<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No';
                                     }
                                      ?></span>
							</div>
							<p>
							<?php
										if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
				
}
							?>
						</p>
						</div>
					</div>
				</div>
			</article>
					<?php	
					}
					
				
			
				$i++;	
				}
				?>
			</div>
				<?php
		
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homestyle4');

/*end of home style 4 posts code */


/*start of home style 5 posts code */


class homestyle5 extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'homestyle5', // Base ID
			'Home style 5', // Name
			array('description' => __( 'To display the posts on home page'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$select_design = $instance['select_design'];
		$posttype = $instance['posttype'];
		
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );


			
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$title,$select_design,$posttype);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['select_design'] = strip_tags($new_instance['select_design']);
		$instance['posttype'] = strip_tags($new_instance['posttype']);
		
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$select_design = esc_attr($instance['select_design']);
		$posttype = esc_attr($instance['posttype']);
		
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$select_design = '';
		$posttype = '';
		
		
		
		
		
	}
	?>
		  <p>
  <label for="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>"><?php _e( 'Post Type', 'genesis' ); ?>:</label>
	<select id="<?php echo esc_attr( $this->get_field_id( 'posttype' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posttype' ) ); ?>">
		<option value="NOT IN" <?php selected( 'NOT IN', $instance['posttype'] ); ?>><?php _e( 'Post', 'genesis' ); ?></option>
		<option value="IN" <?php selected( 'IN', $instance['posttype'] ); ?>><?php _e( 'Video', 'genesis' ); ?></option>
		<option value="" <?php selected( '', $instance['posttype'] ); ?>><?php _e( 'Both', 'genesis' ); ?></option>
		</select>
	</p>
  <p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'select_design' ) ); ?>"><?php _e( 'Design Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'select_design' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'select_design' ) ); ?>">
						<option value="design1" <?php selected( 'design1', $instance['select_design'] ); ?>><?php _e( 'design 1', 'genesis' ); ?></option>
						<option value="design2" <?php selected( 'design2', $instance['select_design'] ); ?>><?php _e( 'design 2', 'genesis' ); ?></option>
					</select>
					
				</p>
	
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
							
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
               
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$title,$select_design,$posttype) { //html
		global $post;
	
	
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	$excategory_id = get_cat_ID('movie');
	
	//$listings = new WP_Query();
	//$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
		$listings = new WP_Query( array(
       'post_type' => 'post',
	   'category__not_in' => $excategory_id,
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset,
		'cat' => $posts_cat,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => $posttype
           ) )
) );
		
		if($listings->found_posts > 0) {
			
			
			
			if($select_design == 'design1')
			{
			
			?>
			  <div class="info-content margin-top-60">
					<h4 class="margin-bottom-15"><b><?php echo $title; ?></b></h4>
					<div class="row">
		<?php
			
	$i = 0;
				while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					
					$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					
					   if($i==0)
		{
					?>
			<div class="col-md-8 col-sm-8">
							<article class="style3 style-alt">
							<div class="small-title cat"><?php the_category(); ?></div>
								<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
									<div class="overlay overlay-02"></div>
									<div class="post-thumb">										
										<div class="post-excerpt">
											<div class="meta">
												<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
											</div>
											<h3 itemprop="headline" class="h3 text-white"><?php echo get_the_title(); ?></h3>
											<div class="meta">
											<?php 
											$display_name = get_the_author_meta( 'display_name', $post->post_author );
                                             if ( empty( $display_name ) )
                                          $display_name = get_the_author_meta( 'nickname', $post->post_author );
											?>
												<span class="author"><img src="<?php echo get_stylesheet_directory_uri();?>/img/avatar/1.jpg" class="img-circle" alt=""> by <?php echo $display_name; ?></span>
												<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
												<span class="views"><i class="fa fa-eye"></i> <?php if(function_exists('bac_PostViews')) 
								{ 
                                echo bac_PostViews(get_the_ID()); 
                                }?></span>
											</div>
										</div>
										<?php
										
		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style5' ); 
		genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
	genesis_markup(array(
	'close' => ''
));	

										?>
									</div>
								</a>
							</article>
						</div>
						<div class="col-md-4 col-sm-4">
		<?php
		}
        if($i !=0)
		{			
		?>		
		<article class="style4 style-alt margin-bottom-10">
		<div class="small-title cat"><?php the_category(); ?></div>
								<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
									<div class="overlay overlay-02"></div>
									<div class="post-thumb">
										<div class="post-excerpt">
											<div class="meta">
												<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
											</div>
											<h5 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h5>
										</div>
										<?php 
				 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	genesis_markup( array(
		'html5'   => '<img style="min-height:165px !important;" src="'.$image[0].'" class="bg-img img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
						
	genesis_markup(array(
	'close' => ''
));	

										?>
									</div>
								</a>
					</article>	
				<?php	
		}
					$i++;
				}
				?>
					</div>
				</div>
				</div>
				<?php
		
			wp_reset_postdata(); 
		}
		if($select_design == 'design2')
		{
		?>	
		<div class="padding-top-60">
					<h3 class="margin-bottom-15"><b><?php echo $title; ?></b></h3>
				<div class="row style5">
					<?php
					while ($listings->have_posts() && $i<$posts_num) {
										
					$listings->the_post();
					?>
						<div class="col-sm-4">
							<article class="style4">
								<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
									<div class="overlay overlay-02"></div>
									<div class="post-thumb">
										<div class="post-excerpt">
											<div class="meta">
												<span itemprop="datePublished" class="date"><?php echo get_the_date('M j, Y'); ?></span>
											</div>
											<h3 itemprop="headline" class="text-white"><?php echo get_the_title(); ?></h3>
										</div>
								<?php		
		$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
		$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style51' ); 
	
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="bg-img img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
?>
									</div>
								</a>
							</article>
						</div>
				<?php
					}
					?>
				</div>
			</div>	
		<?php	
		}
		
		}
		else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('homestyle5');

/*end of home style 5 posts code */




//start for the featured video widget code

class featuredvideo extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'featuredvideo', // Base ID
			'Video Posts', // Name
			array('description' => __( 'To display the Video posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );


		$before_title = '<div class="side-widget"><h4>';
	   $after_title = '</h4>';
		if ( $title ) {
			echo $before_title . $title . $after_title;
		}
		else
		{
			echo $before_title . $after_title;
		}
		
		$this->getRealtyListings($posts_num,$posts_offset,$show_content,$content_limit,$more_text,$show_image);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
		
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		
	} else {
		$title = '';
		$posts_num = '';
		
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		
		
		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		

			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_offset,$show_content,$content_limit,$more_text,$show_image) { //html
		global $post;
	
	
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	
$listings = new WP_Query( array(
        'post_type' => 'post',
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset,
        'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => 'IN'
           ) )
       ));	
	
	
//$listings = new WP_Query();	
//$listings->query('post_type=video&posts_per_page=' . $posts_num.'&offset='.$posts_offset);


while ($listings->have_posts())
{	
$listings->the_post(); 
?>
	<article class="article-home margin-bottom-20">
					<a itemprop="url" href="<?php echo get_the_permalink(); ?>">
				<?php
				$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
				 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
			if ( $show_image && $image ) 
			{
		
		?>
		<div class="article-thumb">
							<div class="play"></div>
							<div class="overlay overlay-02"></div>
<?php 
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-responsive" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
					
					
?>
</div>
		<?php
	
		}

?>		
			</a>
					<div class="post-excerpt">
						<h3 itemprop="headline"><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h3>
						<div class="meta">
							<span>by <a href="#" class="link"><?php $display_name = get_the_author_meta( 'display_name', $post->post_author );
if ( empty( $display_name ) )
$display_name = get_the_author_meta( 'nickname', $post->post_author );
echo $display_name; ?></a></span>
							<span itemprop="datePublished">on <?php echo get_the_date('M j, Y'); ?></span>
							<span class="comment"><i class="fa fa-comment-o"></i> <?php  $commmentcount = get_comments_number();
                                        if($commmentcount != '0')
                                          {
                                       echo	$commmentcount;
                                         }
                                         else
                                        {
	                                echo 'No Comments';
                                     }
                                      ?></span>
						</div>
					</div>
				</article>
<?php 
} 
wp_reset_query(); 
	
	 
	}
	
} 
register_widget('featuredvideo');

//end for the featured video widget code





add_filter( 'pre_get_posts', 'tgm_io_cpt_search' );
/**
 * This function modifies the main WordPress query to include an array of 
 * post types instead of the default 'post' post type.
 *
 * @param object $query  The original query.
 * @return object $query The amended query.
 */
function tgm_io_cpt_search( $query ) {
	
    if ( $query->is_search ) {
	$query->set( 'post_type', array( 'post') );
    }
    
    return $query;
}
// custom fields for company information in settings

/**
 *
 * The page content surrounding the settings fields. Usually you use this to instruct non-techy people what to do.
 *
 */
function theme_settings_page(){ 
	?>
	<div class="wrap">
		<form method="post" action="options.php">
			<?php
			settings_fields("section");
			do_settings_sections("theme-options");
			submit_button();
			?>
		</form>
	</div>
	<?php }
/**
 *
 * Next comes the settings fields to display. Use anything from inputs and textareas, to checkboxes multi-selects.
 *
 */

// Founding date
function display_support_founddate(){ ?>
	
	<input type="text" name="founddate" placeholder="Enter Founding date" value="<?php echo get_option('founddate'); ?>" size="35">
<?php }
// Founder name
function display_support_foundname(){ ?>
	<input type="text" name="foundname" placeholder="Enter Founder name" value="<?php echo get_option('foundname'); ?>" size="35">
<?php }
Address:
// streetAddress
function display_support_streetaddress(){ ?>
	<input type="text" name="streetaddress" placeholder="Enter street Address" value="<?php echo get_option('streetaddress'); ?>" size="35">
<?php }

// addressLocality
function display_support_addresslocality(){ ?>
	<input type="text" name="addresslocality" placeholder="Enter address Locality" value="<?php echo get_option('addresslocality'); ?>" size="35">
<?php }

// addressRegion
function display_support_addressregion(){ ?>
	<input type="text" name="addressregion" placeholder="Enter address Region" value="<?php echo get_option('addressregion'); ?>" size="35">

<?php }

// postalCode
function display_support_postalcode(){ ?>
	<input type="text" name="postalcode" placeholder="Enter postal Code" value="<?php echo get_option('postalcode'); ?>" size="35">
<?php }
// addressCountry
function display_support_addresscountry(){ ?>
	<input type="text" name="addresscountry" placeholder="Enter address Country" value="<?php echo get_option('addresscountry'); ?>" size="35">
<?php }
// contact type
function display_support_contacttype(){ ?>
	<input type="text" name="contacttype" placeholder="Enter contact Type" value="<?php echo get_option('contacttype'); ?>" size="35">
<?php }
// Phone
function display_support_phone_element(){ ?>
	<input type="tel" name="support_phone" placeholder="Enter phone number" value="<?php echo get_option('support_phone'); ?>" size="35">
<?php }
// Fax
function display_support_fax_element(){ ?>
	<input type="tel" name="support_fax" placeholder="Enter fax number" value="<?php echo get_option('support_fax'); ?>" size="35">
<?php }
// Email
function display_support_email_element(){ ?>
	<input type="email" name="support_email" placeholder="Enter email address" value="<?php echo get_option('support_email'); ?>" size="35">
<?php }
// link1
function display_support_link1(){ ?>
	<input type="text" name="link1" placeholder="Enter link" value="<?php echo get_option('link1'); ?>" size="35">
<?php }
// link2
function display_support_link2(){ ?>
	<input type="text" name="link2" placeholder="Enter link" value="<?php echo get_option('link2'); ?>" size="35">
<?php }
// link3
function display_support_link3(){ ?>
	<input type="text" name="link3" placeholder="Enter link" value="<?php echo get_option('link3'); ?>" size="35">
<?php }
// link4
function display_support_link4(){ ?>
	<input type="text" name="link4" placeholder="Enter link" value="<?php echo get_option('link4'); ?>" size="35">
<?php }
// link5
function display_support_link5(){ ?>
	<input type="text" name="link5" placeholder="Enter link" value="<?php echo get_option('link5'); ?>" size="35">
<?php }
/**
 *
 * Here you tell WP what to enqueue into the <form> area. You need:
 *
 * 1. add_settings_section
 * 2. add_settings_field
 * 3. register_setting
 *
 */
function display_custom_info_fields(){
	
	add_settings_section("section", "Company Information", null, "theme-options");

	
	add_settings_field("founddate", "Founding Date", "display_support_founddate", "theme-options", "section");
	add_settings_field("foundname", "Founder Name", "display_support_foundname", "theme-options", "section");
	add_settings_field("streetaddress", "Street Address", "display_support_streetaddress", "theme-options", "section");
	add_settings_field("addresslocality", "Address Locality", "display_support_addresslocality", "theme-options", "section");
	add_settings_field("addressregion", "Address Region", "display_support_addressregion", "theme-options", "section");
	add_settings_field("postalcode", "postal Code", "display_support_postalcode", "theme-options", "section");
	add_settings_field("addresscountry", "Address Country", "display_support_addresscountry", "theme-options", "section");
	
	add_settings_field("link1", "Facebook link", "display_support_link1", "theme-options", "section");
	add_settings_field("link2", "Twitter link", "display_support_link2", "theme-options", "section");
	add_settings_field("link3", "Google link", "display_support_link3", "theme-options", "section");
	add_settings_field("link4", "Linked in link", "display_support_link4", "theme-options", "section");
	add_settings_field("link5", "Instagram link", "display_support_link5", "theme-options", "section");
	
	add_settings_field("contacttype", "Support Type.", "display_support_contacttype", "theme-options", "section");
	add_settings_field("support_phone", "Support Phone No.", "display_support_phone_element", "theme-options", "section");
	add_settings_field("support_fax", "Support Fax No.", "display_support_fax_element", "theme-options", "section");
	add_settings_field("support_email", "Support Email address", "display_support_email_element", "theme-options", "section");
	
	
	register_setting("section", "founddate");
	register_setting("section", "foundname");
	register_setting("section", "streetaddress");
	register_setting("section", "addresslocality");
	register_setting("section", "addressregion");
	register_setting("section", "postalcode");
	register_setting("section", "addresscountry");
	register_setting("section", "link1");
	register_setting("section", "link2");
	register_setting("section", "link3");
	register_setting("section", "link4");
	register_setting("section", "link5");
	
	
	register_setting("section", "contacttype");
	register_setting("section", "support_phone");
	register_setting("section", "support_fax");
	register_setting("section", "support_email");
	
}
add_action("admin_init", "display_custom_info_fields");
/**
 *
 * Tie it all together by adding the settings page to wherever you like. For this example it will appear
 * in Settings > Contact Info
 *
 */
function add_custom_info_menu_item(){
	
	add_options_page("Contact Info", "Contact Info", "manage_options", "contact-info", "theme_settings_page");
	
}
add_action("admin_menu", "add_custom_info_menu_item");


// Start of code for the Theme Custom Navigation Menu widget class

     class Theme_Custom_Menu_Widget extends WP_Widget {

        function Theme_Custom_Menu_Widget() {
            $widget_ops = array( 'description' => __('Add a custom menu to your sidebar.') );
            parent::__construct( 'nav_menu', __('Theme Custom Menu'), $widget_ops );
        }

        function widget($args, $instance) {
            // Get menu
            $nav_menu = ! empty( $instance['nav_menu'] ) ? wp_get_nav_menu_object( $instance['nav_menu'] ) : false;

            if ( !$nav_menu )
                return;

            /** This filter is documented in wp-includes/default-widgets.php */
            $instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

            echo $args['before_widget'];

            if ( !empty($instance['title']) )
                echo $args['before_title'] . $instance['title'] . $args['after_title'];

            wp_nav_menu( array( 'fallback_cb' => '', 
			'menu' => $nav_menu,
			'container_class' => 'custom_container',
			'menu_class' => 'menu',
			'link_before' => '<span itemprop="name">',
			'link_after' => '</span>',

			) );

            echo $args['after_widget'];
        }

        function update( $new_instance, $old_instance ) {
            $instance['title'] = strip_tags( stripslashes($new_instance['title']) );
            $instance['nav_menu'] = (int) $new_instance['nav_menu'];
            return $instance;
        }

        function form( $instance ) {
            $title = isset( $instance['title'] ) ? $instance['title'] : '';
            $nav_menu = isset( $instance['nav_menu'] ) ? $instance['nav_menu'] : '';

            // Get menus
            $menus = wp_get_nav_menus( array( 'orderby' => 'name' ) );

            // If no menus exists, direct the user to go and create some.
            if ( !$menus ) {
                echo '<p>'. sprintf( __('No menus have been created yet. <a href="%s">Create some</a>.'), admin_url('nav-menus.php') ) .'</p>';
                return;
            }
            ?>
            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:') ?></label>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('nav_menu'); ?>"><?php _e('Select Menu:'); ?></label>
                <select id="<?php echo $this->get_field_id('nav_menu'); ?>" name="<?php echo $this->get_field_name('nav_menu'); ?>">
                    <option value="0"><?php _e( '&mdash; Select &mdash;' ) ?></option>
            <?php
                foreach ( $menus as $menu ) {
                    echo '<option value="' . $menu->term_id . '"'
                        . selected( $nav_menu, $menu->term_id, false )
                        . '>'. esc_html( $menu->name ) . '</option>';
                }
            ?>
                </select>
            </p>
            <?php
        }
    }

    add_action('widgets_init', create_function('', 'return register_widget("Theme_Custom_Menu_Widget");'));
	// end of code for the Theme Custom Navigation Menu widget class
	
	
	// adding the new mega menu widget code
	
	class MyMegaMenuWidget extends WP_Widget {

    function __construct() {
        $widget_ops = array( 'description' => __('This to add the megamenu.') );
        parent::__construct( 'custom_menu_widget-1', __('Mega Menu'), $widget_ops );
    }

    function widget($args, $instance) {
        // Get menu
        $nav_menu = ! empty( $instance['nav_menu'] ) ? wp_get_nav_menu_object( $instance['nav_menu'] ) : false;

        if ( !$nav_menu )
            return;

        $instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

echo '<div class="col-md-3">';

        echo $args['before_widget'];

       // if ( !empty($instance['title']) )
            echo '<h5>' . $instance['title'] . '</h5>';

        wp_nav_menu( array( 'fallback_cb' => '', 
			'menu' => $nav_menu,
			//'container_class' => 'custom_container',
			'menu_class' => 'menu',
			'link_before' => '<span itemprop="name">',
			'link_after' => '</span>'
						) );


        echo $args['after_widget'];
echo '</div>';
    }

    function update( $new_instance, $old_instance ) {
        $instance['title'] = strip_tags( stripslashes($new_instance['title']) );
        $instance['nav_menu'] = (int) $new_instance['nav_menu'];
        return $instance;
    }

    function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $nav_menu = isset( $instance['nav_menu'] ) ? $instance['nav_menu'] : '';

        // Get menus
        $menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );

        // If no menus exists, direct the user to go and create some.
        if ( !$menus ) {
            echo '<p>'. sprintf( __('No menus have been created yet. <a href="%s">Create some</a>.'), admin_url('nav-menus.php') ) .'</p>';
            return;
        }
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:') ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('nav_menu'); ?>"><?php _e('Select Menu:'); ?></label>
            <select id="<?php echo $this->get_field_id('nav_menu'); ?>" name="<?php echo $this->get_field_name('nav_menu'); ?>">
        <?php
            foreach ( $menus as $menu ) {
                $selected = $nav_menu == $menu->term_id ? ' selected="selected"' : '';
                echo '<option'. $selected .' value="'. $menu->term_id .'">'. $menu->name .'</option>';
            }
        ?>
            </select>
        </p>
        <?php
    }
}

add_action( 'widgets_init', 'megamenu_register_widgets' );

function megamenu_register_widgets() {

      register_widget( 'MyMegaMenuWidget' );

}

//end of mega menu code


//normal style menu in mega menu
	
	class NormalMegaMenuWidget extends WP_Widget {

    function __construct() {
        $widget_ops = array( 'description' => __('This to add the Normal to megamenu.') );
        parent::__construct( 'normal_custom_mega_menu', __('Normal Menu'), $widget_ops );
    }

    function widget($args, $instance) {
        // Get menu
        $nav_menu = ! empty( $instance['nav_menu'] ) ? wp_get_nav_menu_object( $instance['nav_menu'] ) : false;

        if ( !$nav_menu )
            return;

        $instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );



    //  echo $args['before_widget'];

      //  if ( !empty($instance['title']) )
          

        wp_nav_menu( array( 'fallback_cb' => '', 
			'menu' => $nav_menu,
			'container' => false,
			'items_wrap'    => '%3$s',
			'menu_class' => 'menu',
			'walker' => new WP_Bootstrap_Navwalker()
			) );


     //  echo $args['after_widget'];

    }

    function update( $new_instance, $old_instance ) {
        $instance['title'] = strip_tags( stripslashes($new_instance['title']) );
        $instance['nav_menu'] = (int) $new_instance['nav_menu'];
        return $instance;
    }

    function form( $instance ) {
        $title = isset( $instance['title'] ) ? $instance['title'] : '';
        $nav_menu = isset( $instance['nav_menu'] ) ? $instance['nav_menu'] : '';

        // Get menus
        $menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );

        // If no menus exists, direct the user to go and create some.
        if ( !$menus ) {
            echo '<p>'. sprintf( __('No menus have been created yet. <a href="%s">Create some</a>.'), admin_url('nav-menus.php') ) .'</p>';
            return;
        }
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:') ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id('nav_menu'); ?>"><?php _e('Select Menu:'); ?></label>
            <select id="<?php echo $this->get_field_id('nav_menu'); ?>" name="<?php echo $this->get_field_name('nav_menu'); ?>">
        <?php
            foreach ( $menus as $menu ) {
                $selected = $nav_menu == $menu->term_id ? ' selected="selected"' : '';
                echo '<option'. $selected .' value="'. $menu->term_id .'">'. $menu->name .'</option>';
            }
        ?>
            </select>
        </p>
        <?php
    }
}

add_action( 'widgets_init', 'normalmegamenu_register_widgets' );

function normalmegamenu_register_widgets() {

      register_widget( 'NormalMegaMenuWidget' );

}

//end of normal style menu in mega menu

//start of megamenu post code


class megamenupost extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'megamenupost', // Base ID
			'Mega menu posts', // Name
			array('description' => __( 'To display the Megamenu posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$posts_num = $instance['posts_num'];
		$posts_cat = $instance['posts_cat'];
		$posts_offset = $instance['posts_offset'];
		$show_content = $instance['show_content'];
		$content_limit = $instance['content_limit'];
		$more_text = $instance['more_text'];
		$show_image = $instance['show_image'];

		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );


		
		$this->getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['posts_num'] = strip_tags($new_instance['posts_num']);
		$instance['posts_cat'] = strip_tags($new_instance['posts_cat']);
		$instance['posts_offset'] = strip_tags($new_instance['posts_offset']);
		$instance['show_content'] = strip_tags($new_instance['show_content']);
		$instance['content_limit'] = strip_tags($new_instance['content_limit']);
		$instance['more_text'] = strip_tags($new_instance['more_text']);
		$instance['show_image'] = strip_tags($new_instance['show_image']);
	
		
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$posts_num = esc_attr($instance['posts_num']);
		$posts_cat = esc_attr($instance['posts_cat']);
		$posts_offset = esc_attr($instance['posts_offset']);
		$show_content = esc_attr($instance['show_content']);
		$content_limit = esc_attr($instance['content_limit']);
		$more_text = esc_attr($instance['more_text']);
		$show_image = esc_attr($instance['show_image']);
		
		
	} else {
		$title = '';
		$posts_num = '';
		$posts_cat = '';
		$posts_offset = '';
		$show_content = '';
		$content_limit = '';
		$more_text = '';
		$show_image = '';
		

		
		
	}
	?>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		<p>
	<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>"><?php _e( 'Number of Posts to Show', 'genesis' ); ?>:</label>
		<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_num' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_num' ) ); ?>" value="<?php echo esc_attr( $instance['posts_num'] ); ?>" size="2" placeholder="1" />
				</p>
		</p>
	<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>"><?php _e( 'Number of Posts to Offset', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'posts_offset' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts_offset' ) ); ?>" value="<?php echo esc_attr( $instance['posts_offset'] ); ?>" size="2" />
				</p>
		
<p>
						<label for="<?php echo $this->get_field_id( 'posts_cat' ); ?>"><?php _e( 'Category'); ?>:</label>
					<?php
					$categories_args = array(
						'name'            => $this->get_field_name( 'posts_cat' ),
						'id'              => $this->get_field_id( 'posts_cat' ),
						'selected'        => $instance['posts_cat'],
						'orderby'         => 'Name',
						'hierarchical'    => 1,
						'show_option_all' => __( 'All Categories', 'genesis' ),
						'hide_empty'      => '0',
						
					);
					wp_dropdown_categories( $categories_args ); ?>
				</p>
								
			<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>"><?php _e( 'Content Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'show_content' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'show_content' ) ); ?>">
						<option value="content" <?php selected( 'content', $instance['show_content'] ); ?>><?php _e( 'Show Content', 'genesis' ); ?></option>
						<option value="excerpt" <?php selected( 'excerpt', $instance['show_content'] ); ?>><?php _e( 'Show Excerpt', 'genesis' ); ?></option>
						<option value="content-limit" <?php selected( 'content-limit', $instance['show_content'] ); ?>><?php _e( 'Show Content Limit', 'genesis' ); ?></option>
						<option value="" <?php selected( '', $instance['show_content'] ); ?>><?php _e( 'No Content', 'genesis' ); ?></option>
					</select>
					<br />
					<label for="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>"><?php _e( 'Limit content to', 'genesis' ); ?>
						<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'content_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'content_limit' ) ); ?>" value="<?php echo esc_attr( intval( $instance['content_limit'] ) ); ?>" size="3" />
						<?php _e( 'characters', 'genesis' ); ?>
					</label>
				</p>

				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>"><?php _e( 'More Text (if applicable)', 'genesis' ); ?>:</label>
					<input type="text" id="<?php echo esc_attr( $this->get_field_id( 'more_text' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'more_text' ) ); ?>" value="<?php echo esc_attr( $instance['more_text'] ); ?>" />
				</p>	
				
				
				
				<p>
					<input id="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show_image' ) ); ?>" value="1" <?php checked( $instance['show_image'] ); ?>/>
					<label for="<?php echo esc_attr( $this->get_field_id( 'show_image' ) ); ?>"><?php _e( 'Show Featured Image', 'genesis' ); ?></label>
				</p>
	<?php
	
	}

	function getRealtyListings($posts_num,$posts_cat,$posts_offset,$show_content,$content_limit,$more_text,$show_image) { //html
		global $post;
	
	
	
	if ( empty( $posts_num ) ) {
$posts_num = 1;

	}
	

	//$listings = new WP_Query();
	//$listings->query('post_type=post&cat='.$posts_cat.'&posts_per_page=' . $posts_num.'&offset='.$posts_offset);
		$listings = new WP_Query( array(
       'post_type' => 'post',
        'posts_per_page' => $posts_num,
		'offset' => $posts_offset,
		'cat' => $posts_cat,
       'tax_query' => array( array(
            'taxonomy' => 'post_format',
            'field' => 'slug',
            'terms' => array('post-format-video'),
            'operator' => 'NOT IN'
           ) )
) );

	if($listings->found_posts > 0) {
						
			while ($listings->have_posts()) {
										
					$listings->the_post();
					
					?>
						<div class="col-md-3">
											<div class="header-post">
												<a href="<?php echo get_the_permalink(); ?>">
													<div class="hp-thumb">
													<?php
																	$image = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
					
	if ( $show_image && $image ) {
			$role = empty( $instance['show_title'] ) ? '' : 'aria-hidden="true"';
				//printf( '<a href="%s" class="%s" %s>%s</a>', get_permalink(), esc_attr( $instance['image_alignment'] ), $role, wp_make_content_images_responsive( $image ) );
		 

		 $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'style4' ); 
		
	
	genesis_markup( array(
		'html5'   => '<img src="'.$image[0].'" class="img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
}
										?>
													</div>
												</a>
												
												<date><?php echo get_the_date('M j, Y'); ?></date>
												<h4><a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a></h4>
												<p>
				<?php

				if ( ! empty( $show_content ) ) {

				
				if ( 'excerpt' == $show_content ) {
					the_excerpt();
				}
				elseif ( 'content-limit' == $show_content ) {
					
			the_content_limit( (int) $content_limit, '<a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );
		            }

				
				else {

					global $more;

					$orig_more = $more;
					$more = 0;

					the_content( (int) $content_limit, '... <a class="more-link" href="' . get_permalink() . '">'.esc_html( $more_text ).'</a>' );

					$more = $orig_more;

				}
				
}

           echo '</p>';
			echo '</div>';
			echo '</div>';
					
					
				}
						
			wp_reset_postdata(); 
		}else{
			echo '<p style="padding:25px;">No listing found</p>';
		} 
	}
	
} 
register_widget('megamenupost');

//end of megamenu post code


//start of megamenu image/video code


class imagevideopost extends WP_Widget 
{
	function __construct() {
		parent::__construct(
			'imagevideopost', // Base ID
			'Mega menu Image / Video posts', // Name
			array('description' => __( 'To display the Megamenu Image/Video posts'))
		);
	}
	function widget($args, $instance) { //output
		extract( $args );
		// these are the widget options
		$title = apply_filters('widget_title', $instance['title']);
		$imgurl = $instance['imgurl'];
		$textcontent = $instance['textcontent'];
		$url = $instance['url'];
		$imagevideo = $instance['imagevideo'];
	
		
		//echo $before_widget;
		// Check if title is set
		
		$title = apply_filters( 'widget_title', $instance['title'] );
		
		$this->getRealtyListings($title,$imgurl,$textcontent,$url,$imagevideo);
		//echo $after_widget;
	}

	function update($new_instance, $old_instance) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['textcontent'] = strip_tags($new_instance['textcontent']);
		$instance['url'] = strip_tags($new_instance['url']);
		$instance['imgurl'] = strip_tags($new_instance['imgurl']);
		$instance['imagevideo'] = strip_tags($new_instance['imagevideo']);
					
		return $instance;
	}	
    
    // widget form creation
	function form($instance) {

	// Check values
	if( $instance) {
		$title = esc_attr($instance['title']);
		$imgurl = esc_attr($instance['imgurl']);
		$textcontent = esc_attr($instance['textcontent']);
		$url = esc_attr($instance['url']);
		$imagevideo = esc_attr($instance['imagevideo']);
	
		
	} else {
		$title = '';
		$imgurl = '';
		$show_content = '';
		$textcontent = '';
		$url = '';
		$imagevideo = '';
			
	}
	?>
				<p>
					<label for="<?php echo esc_attr( $this->get_field_id( 'imagevideo' ) ); ?>"><?php _e( 'Type', 'genesis' ); ?>:</label>
					<select id="<?php echo esc_attr( $this->get_field_id( 'imagevideo' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'imagevideo' ) ); ?>">
						<option value="image" <?php selected( 'image', $instance['imagevideo'] ); ?>><?php _e( 'image', 'genesis' ); ?></option>
						<option value="video" <?php selected( 'video', $instance['imagevideo'] ); ?>><?php _e( 'video', 'genesis' ); ?></option>
					</select>
					
				</p>
		<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
		</p>
		
		<p>
		<label for="<?php echo $this->get_field_id('url'); ?>"><?php _e('Link url', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('url'); ?>" name="<?php echo $this->get_field_name('url'); ?>" type="text" value="<?php echo $url; ?>" />
		</p>
		
		<p>
		<label for="<?php echo $this->get_field_id('imgurl'); ?>"><?php _e('Image Url', 'top_right'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('imgurl'); ?>" name="<?php echo $this->get_field_name('imgurl'); ?>" type="text" value="<?php echo $imgurl; ?>" />
		</p>
		
		
		<p>
		<label for="<?php echo $this->get_field_id('textcontent'); ?>"><?php _e('Content', 'top_right'); ?></label>
		<textarea class="widefat" id="<?php echo $this->get_field_id('textcontent'); ?>" name="<?php echo $this->get_field_name('textcontent'); ?>" rows="16" cols="20"><?php echo $textcontent; ?></textarea>
		</p>
		

	<?php
	
	}

	function getRealtyListings($title,$imgurl,$textcontent,$url,$imagevideo) { //html
		global $post;
	
	
	?>
	<div class="col-md-3">
											<div class="header-post">
                                              
											<a href="<?php echo $url; ?>">
													<div class="hp-thumb">
									<?php
  if($imagevideo == 'image')
  {
	genesis_markup( array(
		'html5'   => '<img src="'.$imgurl.'" class="img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
  }
  else
  {
	  ?>
	<div class="play"></div>
							<div class="overlay overlay-02"></div>
							<img style="display:none !important" src="" class="img-responsive" alt="" itemprop="image">	  
<?php 
 	genesis_markup( array(
		'html5'   => '<img src="'.$imgurl.'" class="img-full" alt="" %s/>',
		'context' => 'entry-image'
	) );
					
					
	genesis_markup(array(
	'close' => ''
));	
 }
											?>
											</div>
												</a>
												<h4><a href="<?php echo $url; ?>"><?php echo $title; ?></a></h4>
												<p><?php echo $textcontent; ?></p>
											</div>
										</div>
<?php
}
}

register_widget('imagevideopost');

//end of megamenu image/video code

// custom code for the mega menu titles
function megamenu_settings_page(){ 
	?>
	<div class="wrap">
		<form method="post" action="options.php">
			<?php
			settings_fields("section1");
			do_settings_sections("theme-options1");
			submit_button();
			?>
		</form>
	</div>
	<?php }
// megamenuactivate
function display_support_megamenuactivate(){ ?>
   <input type="checkbox" name="megamenuactivate" value="1" <?php checked( get_option('megamenuactivate') ); ?>/>
<?php }
// megamenu1
function display_support_megamenu1(){ ?>
	
	<input type="text" name="megamenu1" placeholder="Enter megamenu 1 title" value="<?php echo get_option('megamenu1'); ?>" size="35">
	<input type="text" name="megamenu1url" placeholder="Enter megamenu 1 url" value="<?php echo get_option('megamenu1url'); ?>" size="35">
	
		<select name="megamenu1select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu1select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu1select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu1select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }
// megamenu2
function display_support_megamenu2(){ ?>
	
	<input type="text" name="megamenu2" placeholder="Enter megamenu 2 title" value="<?php echo get_option('megamenu2'); ?>" size="35">
	<input type="text" name="megamenu2url" placeholder="Enter megamenu 2 url" value="<?php echo get_option('megamenu2url'); ?>" size="35">
	<select name="megamenu2select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu2select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu2select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu2select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }
// megamenu3
function display_support_megamenu3(){ ?>
	
	<input type="text" name="megamenu3" placeholder="Enter megamenu 3 title" value="<?php echo get_option('megamenu3'); ?>" size="35">
	<input type="text" name="megamenu3url" placeholder="Enter megamenu 3 url" value="<?php echo get_option('megamenu3url'); ?>" size="35">
	<select name="megamenu3select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu3select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu3select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu3select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }

// megamenu4
function display_support_megamenu4(){ ?>
	<input type="text" name="megamenu4" placeholder="Enter megamenu 4 title" value="<?php echo get_option('megamenu4'); ?>" size="35">
	<input type="text" name="megamenu4url" placeholder="Enter megamenu 4 url" value="<?php echo get_option('megamenu4url'); ?>" size="35">
	<select name="megamenu4select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu4select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu4select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu4select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }

// megamenu5
function display_support_megamenu5(){ ?>
	<input type="text" name="megamenu5" placeholder="Enter megamenu 5 title" value="<?php echo get_option('megamenu5'); ?>" size="35">
	<input type="text" name="megamenu5url" placeholder="Enter megamenu 5 url" value="<?php echo get_option('megamenu5url'); ?>" size="35">
	<select name="megamenu5select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu5select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu5select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu5select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }

// megamenu6
function display_support_megamenu6(){ ?>
	<input type="text" name="megamenu6" placeholder="Enter megamenu 6 title" value="<?php echo get_option('megamenu6'); ?>" size="35">
	<input type="text" name="megamenu6url" placeholder="Enter megamenu 6 url" value="<?php echo get_option('megamenu6url'); ?>" size="35">
	<select name="megamenu6select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu6select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu6select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu6select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }


// megamenu7
function display_support_megamenu7(){ ?>
	<input type="text" name="megamenu7" placeholder="Enter megamenu 7 title" value="<?php echo get_option('megamenu7'); ?>" size="35">
	<input type="text" name="megamenu7url" placeholder="Enter megamenu 7 url" value="<?php echo get_option('megamenu7url'); ?>" size="35">
	<select name="megamenu7select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu7select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu7select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu7select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }
// megamenu6
function display_support_megamenu8(){ ?>
	<input type="text" name="megamenu8" placeholder="Enter megamenu 8 title" value="<?php echo get_option('megamenu8'); ?>" size="35">
	<input type="text" name="megamenu8url" placeholder="Enter megamenu 8 url" value="<?php echo get_option('megamenu8url'); ?>" size="35">
	<select name="megamenu8select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu8select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu8select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu8select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }

// megamenu9
function display_support_megamenu9(){ ?>
	<input type="text" name="megamenu9" placeholder="Enter megamenu 9 title" value="<?php echo get_option('megamenu9'); ?>" size="35">
	<input type="text" name="megamenu9url" placeholder="Enter megamenu 9 url" value="<?php echo get_option('megamenu9url'); ?>" size="35">
	<select name="megamenu9select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu9select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu9select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu9select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }
// megamenu6
function display_support_megamenu10(){ ?>
	<input type="text" name="megamenu10" placeholder="Enter megamenu 10 title" value="<?php echo get_option('megamenu10'); ?>" size="35">
	<input type="text" name="megamenu10url" placeholder="Enter megamenu 10 url" value="<?php echo get_option('megamenu10url'); ?>" size="35">
	<select name="megamenu10select">
			<option value="nomenu" <?php selected( 'nomenu', get_option('megamenu10select') ); ?>><?php _e( 'No Menu', 'genesis' ); ?></option>
			<option value="normalmenu" <?php selected( 'normalmenu', get_option('megamenu10select') ); ?>><?php _e( 'Normal Menu', 'genesis' ); ?></option>
			<option value="megamenu" <?php selected( 'megamenu', get_option('megamenu10select') ); ?>><?php _e( 'Mega Menu', 'genesis' ); ?></option>
		</select>
<?php }

function display_megamenu_fields(){
	
	add_settings_section("section1", "Mega Menu Titles", null, "theme-options1");

	
	add_settings_field("megamenuactivate", "Megamenu Activate", "display_support_megamenuactivate", "theme-options1", "section1");
	add_settings_field("megamenu1", "Megamenu 1 Title", "display_support_megamenu1", "theme-options1", "section1");
	add_settings_field("megamenu2", "Megamenu 2 Title", "display_support_megamenu2", "theme-options1", "section1");
	add_settings_field("megamenu3", "Megamenu 3 Title", "display_support_megamenu3", "theme-options1", "section1");
	add_settings_field("megamenu4", "Megamenu 4 Title", "display_support_megamenu4", "theme-options1", "section1");
	add_settings_field("megamenu5", "Megamenu 5 Title", "display_support_megamenu5", "theme-options1", "section1");
	add_settings_field("megamenu6", "Megamenu 6 Title", "display_support_megamenu6", "theme-options1", "section1");
	add_settings_field("megamenu7", "Megamenu 7 Title", "display_support_megamenu7", "theme-options1", "section1");
	add_settings_field("megamenu8", "Megamenu 8 Title", "display_support_megamenu8", "theme-options1", "section1");
	add_settings_field("megamenu9", "Megamenu 9 Title", "display_support_megamenu9", "theme-options1", "section1");
	add_settings_field("megamenu10", "Megamenu 10 Title", "display_support_megamenu10", "theme-options1", "section1");
		
	register_setting("section1", "megamenuactivate");
	register_setting("section1", "megamenu1");
	register_setting("section1", "megamenu1select");
	register_setting("section1", "megamenu2");
	register_setting("section1", "megamenu2select");
	register_setting("section1", "megamenu3");
	register_setting("section1", "megamenu3select");
	register_setting("section1", "megamenu4");
	register_setting("section1", "megamenu4select");
	register_setting("section1", "megamenu5");
	register_setting("section1", "megamenu5select");
	register_setting("section1", "megamenu6");
	register_setting("section1", "megamenu6select");
	register_setting("section1", "megamenu7");
	register_setting("section1", "megamenu7select");
	register_setting("section1", "megamenu8");
	register_setting("section1", "megamenu8select");
	register_setting("section1", "megamenu9");
	register_setting("section1", "megamenu9select");
	register_setting("section1", "megamenu10");
	register_setting("section1", "megamenu10select");
	register_setting("section1", "megamenu1url");
	register_setting("section1", "megamenu2url");
	register_setting("section1", "megamenu3url");
	register_setting("section1", "megamenu4url");
	register_setting("section1", "megamenu5url");
	register_setting("section1", "megamenu6url");
	register_setting("section1", "megamenu7url");
	register_setting("section1", "megamenu8url");
	register_setting("section1", "megamenu9url");
	register_setting("section1", "megamenu10url");
	
	
	
	
	
}
add_action("admin_init", "display_megamenu_fields");
/**
 *
 * Tie it all together by adding the settings page to wherever you like. For this example it will appear
 * in Settings > Contact Info
 *
 */
function add_megamenutitles(){
	
	add_options_page("Mega Menu", "Mega Menu", "manage_options", "mega-menu", "megamenu_settings_page");
	
}
add_action("admin_menu", "add_megamenutitles");

//wordpress post formates
add_theme_support( 'post-formats', array( 'video' ) );


remove_theme_support( 'genesis-inpost-layouts' );
remove_theme_support( 'genesis_inpost_scripts_box' );
//* Remove content/sidebar/sidebar layout
genesis_unregister_layout( 'content-sidebar-sidebar' );

//* Remove sidebar/sidebar/content layout
genesis_unregister_layout( 'sidebar-sidebar-content' );

//* Remove sidebar/content/sidebar layout
genesis_unregister_layout( 'sidebar-content-sidebar' );

//* Remove full width content layout
genesis_unregister_layout( 'full-width-content' );

//* Remove sidebar content layout
genesis_unregister_layout( 'sidebar-content' );

//* Remove content sidebar layout
genesis_unregister_layout( 'content-sidebar' );

//* Remove all layouts from edit post/page screens
remove_theme_support( 'genesis-inpost-layouts' );

//social share code starts here 

function social_share_menu_item()
{
  add_submenu_page("options-general.php", "Social Share", "Social Share", "manage_options", "social-share", "social_share_page"); 
}

add_action("admin_menu", "social_share_menu_item");


function social_share_page()
{
   ?>
      <div class="wrap">
         <h1>Social Sharing Options</h1>
 
         <form method="post" action="options.php">
            <?php
               settings_fields("social_share_config_section");
 
               do_settings_sections("social-share");
                
               submit_button(); 
            ?>
         </form>
      </div>
   <?php
}








function social_share_settings()
{
    add_settings_section("social_share_config_section", "", null, "social-share");
 
    add_settings_field("social-share-facebook", "Do you want to display Facebook share button?", "social_share_facebook_checkbox", "social-share", "social_share_config_section");
    add_settings_field("social-share-twitter", "Do you want to display Twitter share button?", "social_share_twitter_checkbox", "social-share", "social_share_config_section");
    add_settings_field("social-share-linkedin", "Do you want to display LinkedIn share button?", "social_share_linkedin_checkbox", "social-share", "social_share_config_section");
    add_settings_field("social-share-reddit", "Do you want to display Reddit share button?", "social_share_reddit_checkbox", "social-share", "social_share_config_section");
 
    register_setting("social_share_config_section", "social-share-facebook");
    register_setting("social_share_config_section", "social-share-twitter");
    register_setting("social_share_config_section", "social-share-linkedin");
    register_setting("social_share_config_section", "social-share-reddit");
}
 
function social_share_facebook_checkbox()
{  
   ?>
        <input type="checkbox" name="social-share-facebook" value="1" <?php checked(1, get_option('social-share-facebook'), true); ?> /> Check for Yes
   <?php
}

function social_share_twitter_checkbox()
{  
   ?>
        <input type="checkbox" name="social-share-twitter" value="1" <?php checked(1, get_option('social-share-twitter'), true); ?> /> Check for Yes
   <?php
}

function social_share_linkedin_checkbox()
{  
   ?>
        <input type="checkbox" name="social-share-linkedin" value="1" <?php checked(1, get_option('social-share-linkedin'), true); ?> /> Check for Yes
   <?php
}

function social_share_reddit_checkbox()
{  
   ?>
        <input type="checkbox" name="social-share-reddit" value="1" <?php checked(1, get_option('social-share-reddit'), true); ?> /> Check for Yes
   <?php
}
 
add_action("admin_init", "social_share_settings");



function add_social_share_icons()
{
    $html = "<div class='social'>";

    global $post;

    $url = get_permalink($post->ID);
    $url = esc_url($url);

	
	
	
	
    if(get_option("social-share-facebook") == 1)
    {
        $html = $html . "<a target='_blank' href='http://www.facebook.com/sharer.php?u=" . $url . "' class='fa fa-facebook'></a>";
    }

    if(get_option("social-share-twitter") == 1)
    {
        $html = $html . "<a target='_blank' href='https://twitter.com/share?url=" . $url . "' class='fa fa-twitter'></a>";
    }

    if(get_option("social-share-linkedin") == 1)
    {
        $html = $html . "<a target='_blank' href='http://www.linkedin.com/shareArticle?url=" . $url . "' class='fa fa-linkedin'></a>";
    }

    if(get_option("social-share-reddit") == 1)
    {
        $html = $html . "<a target='_blank' href='http://reddit.com/submit?url=" . $url . "' class='fa fa-reddit'></a>";
    }

    $html = $html . "</div>";

    return $html;
}

add_shortcode('social_share_icons', 'add_social_share_icons');

//social share code ends here 

//code for adding the custom meta field for video custom post type

function video_add_custom_metabox() {

	add_meta_box(
		'video_meta',
		__( 'Video link' ),
		'video_meta_callback',
		'post',
		'normal',
		'high'
	);

}
add_action( 'add_meta_boxes', 'video_add_custom_metabox' );

function video_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'video_nonce' );
	$video_stored_meta = get_post_meta( $post->ID ); 
	?>	
	<table class="form-table">
<tbody>
	<tr valign="top">
		<th scope="row"><label for="embededvideolink">Embeded video link</label></th>
<td><p><input class="large-text" type="text" name="embededvideolink" id="genesis_custom_body_class" value="<?php if ( ! empty ( $video_stored_meta['embededvideolink'] ) ) echo esc_attr( $video_stored_meta['embededvideolink'][0] ); ?>" placeholder="Enter embeded video link"></p></td>
	</tr>
</tbody>
</table>
<?php
}
function video_meta_save( $post_id ) {
	// Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'video_nonce' ] ) && wp_verify_nonce( $_POST[ 'video_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }

		if ( isset( $_POST[ 'embededvideolink' ] ) ) {
		update_post_meta( $post_id, 'embededvideolink', sanitize_text_field( $_POST[ 'embededvideolink' ] ) );
	}
		
}	
add_action( 'save_post', 'video_meta_save' );	






//code for adding the custom meta field for song credits for video lyrics custom post type

function songcredits_add_custom_metabox() {

	add_meta_box(
		'songcredits_meta',
		__( 'Song Credits' ),
		'songcredits_meta_callback',
		'post',
		'normal',
		'high'
	);

}
add_action( 'add_meta_boxes', 'songcredits_add_custom_metabox' );

function songcredits_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'songcredits_nonce' );
	$songcredits_stored_meta = get_post_meta( $post->ID ); 
	?>	
	<table class="form-table">
<tbody>
	<tr valign="top">
		<th scope="row"><label for="album">Album Name</label></th>
<td><p><input class="large-text" type="text" name="album" id="genesis_custom_body_class" value="<?php if ( ! empty ( $songcredits_stored_meta['album'] ) ) echo esc_attr( $songcredits_stored_meta['album'][0] ); ?>" placeholder="Enter album name"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="genre">Genre</label></th>
<td><p><input class="large-text" type="text" name="genre" id="genesis_custom_body_class" value="<?php if ( ! empty ( $songcredits_stored_meta['genre'] ) ) echo esc_attr( $songcredits_stored_meta['genre'][0] ); ?>" placeholder="Enter album genre"></p></td>
	</tr>
			<tr valign="top">
		<th scope="row"><label for="language">Language</label></th>
<td><p><input class="large-text" type="text" name="language" id="genesis_custom_body_class" value="<?php if ( ! empty ( $songcredits_stored_meta['language'] ) ) echo esc_attr( $songcredits_stored_meta['language'][0] ); ?>" placeholder="Enter album language"></p></td>
	</tr>
	<tr valign="top">
		<th scope="row"><label for="song">Song</label></th>
<td><p><input class="large-text" type="text" name="song" id="genesis_custom_body_class" value="<?php if ( ! empty ( $songcredits_stored_meta['song'] ) ) echo esc_attr( $songcredits_stored_meta['song'][0] ); ?>" placeholder="Enter song name"></p></td>
	</tr>
	<tr valign="top">
		<th scope="row"><label for="singer">Singer</label></th>
<td><p><input class="large-text" type="text" name="singer" id="genesis_custom_body_class" value="<?php if ( ! empty ( $songcredits_stored_meta['singer'] ) ) echo esc_attr( $songcredits_stored_meta['singer'][0] ); ?>" placeholder="Enter singer name"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="producer">Producer</label></th>
<td><p><input class="large-text" type="text" name="producer" id="genesis_custom_body_class" value="<?php if ( ! empty ( $songcredits_stored_meta['producer'] ) ) echo esc_attr( $songcredits_stored_meta['producer'][0] ); ?>" placeholder="Enter producer name"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="lyrics">Lyrics</label></th>
<td><p><input class="large-text" type="text" name="lyrics" id="genesis_custom_body_class" value="<?php if ( ! empty ( $songcredits_stored_meta['lyrics'] ) ) echo esc_attr( $songcredits_stored_meta['lyrics'][0] ); ?>" placeholder="Enter lyrics by"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="music">Music</label></th>
<td><p><input class="large-text" type="text" name="music" id="genesis_custom_body_class" value="<?php if ( ! empty ( $songcredits_stored_meta['music'] ) ) echo esc_attr( $songcredits_stored_meta['music'][0] ); ?>" placeholder="Enter music by"></p></td>
	</tr>
			<tr valign="top">
		<th scope="row"><label for="recordLabel">RecordLabel</label></th>
<td><p><input class="large-text" type="text" name="recordLabel" id="genesis_custom_body_class" value="<?php if ( ! empty ( $songcredits_stored_meta['recordLabel'] ) ) echo esc_attr( $songcredits_stored_meta['recordLabel'][0] ); ?>" placeholder="Enter record Label by"></p></td>
	</tr>
</tbody>
</table>
<?php
}
function songcredits_meta_save( $post_id ) {
	// Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'songcredits_nonce' ] ) && wp_verify_nonce( $_POST[ 'songcredits_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }
if ( isset( $_POST[ 'album' ] ) ) {
		update_post_meta( $post_id, 'album', sanitize_text_field( $_POST[ 'album' ] ) );
	}
	if ( isset( $_POST[ 'genre' ] ) ) {
		update_post_meta( $post_id, 'genre', sanitize_text_field( $_POST[ 'genre' ] ) );
	}
		if ( isset( $_POST[ 'producer' ] ) ) {
		update_post_meta( $post_id, 'producer', sanitize_text_field( $_POST[ 'producer' ] ) );
	}
			if ( isset( $_POST[ 'language' ] ) ) {
		update_post_meta( $post_id, 'language', sanitize_text_field( $_POST[ 'language' ] ) );
	}
				if ( isset( $_POST[ 'recordLabel' ] ) ) {
		update_post_meta( $post_id, 'recordLabel', sanitize_text_field( $_POST[ 'recordLabel' ] ) );
	}
		if ( isset( $_POST[ 'song' ] ) ) {
		update_post_meta( $post_id, 'song', sanitize_text_field( $_POST[ 'song' ] ) );
	}
	if ( isset( $_POST[ 'singer' ] ) ) {
		update_post_meta( $post_id, 'singer', sanitize_text_field( $_POST[ 'singer' ] ) );
	}
	if ( isset( $_POST[ 'lyrics' ] ) ) {
		update_post_meta( $post_id, 'lyrics', sanitize_text_field( $_POST[ 'lyrics' ] ) );
	}
	if ( isset( $_POST[ 'music' ] ) ) {
		update_post_meta( $post_id, 'music', sanitize_text_field( $_POST[ 'music' ] ) );
	}
		
}	
add_action( 'save_post', 'songcredits_meta_save' );	

//code for adding the custom meta field for movie custom post type

function movie_add_custom_metabox() {

	add_meta_box(
		'movie_meta',
		__( 'Lyrics link' ),
		'movie_meta_callback',
		'post',
		'normal',
		'high'
	);

}
add_action( 'add_meta_boxes', 'movie_add_custom_metabox' );

function movie_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'movie_nonce' );
	$movie_stored_meta = get_post_meta( $post->ID ); 
	?>	
	<table class="form-table">
<tbody>
	<tr valign="top">
		<th scope="row"><label for="lyriclink1">Lyric link 1</label></th>
<td><p><input class="large-text" type="text" name="lyriclink1" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink1'] ) ) echo esc_attr( $movie_stored_meta['lyriclink1'][0] ); ?>" placeholder="Enter lyric link 1"></p></td>
	</tr>
	
		<tr valign="top">
		<th scope="row"><label for="lyriclink2">Lyric link 2</label></th>
<td><p><input class="large-text" type="text" name="lyriclink2" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink2'] ) ) echo esc_attr( $movie_stored_meta['lyriclink2'][0] ); ?>" placeholder="Enter lyric link 2"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="lyriclink3">Lyric link 3</label></th>
<td><p><input class="large-text" type="text" name="lyriclink3" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink3'] ) ) echo esc_attr( $movie_stored_meta['lyriclink3'][0] ); ?>" placeholder="Enter lyric link 3"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="lyriclink4">Lyric link 4</label></th>
<td><p><input class="large-text" type="text" name="lyriclink4" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink4'] ) ) echo esc_attr( $movie_stored_meta['lyriclink4'][0] ); ?>" placeholder="Enter lyric link 4"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="lyriclink5">Lyric link 5</label></th>
<td><p><input class="large-text" type="text" name="lyriclink5" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink5'] ) ) echo esc_attr( $movie_stored_meta['lyriclink5'][0] ); ?>" placeholder="Enter lyric link 5"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="lyriclink6">Lyric link 6</label></th>
<td><p><input class="large-text" type="text" name="lyriclink6" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink6'] ) ) echo esc_attr( $movie_stored_meta['lyriclink6'][0] ); ?>" placeholder="Enter lyric link 6"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="lyriclink7">Lyric link 7</label></th>
<td><p><input class="large-text" type="text" name="lyriclink7" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink7'] ) ) echo esc_attr( $movie_stored_meta['lyriclink7'][0] ); ?>" placeholder="Enter lyric link 7"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="lyriclink8">Lyric link 8</label></th>
<td><p><input class="large-text" type="text" name="lyriclink8" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink8'] ) ) echo esc_attr( $movie_stored_meta['lyriclink8'][0] ); ?>" placeholder="Enter lyric link 8"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="lyriclink9">Lyric link 9</label></th>
<td><p><input class="large-text" type="text" name="lyriclink9" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink9'] ) ) echo esc_attr( $movie_stored_meta['lyriclink9'][0] ); ?>" placeholder="Enter lyric link 9"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="lyriclink10">Lyric link 10</label></th>
<td><p><input class="large-text" type="text" name="lyriclink10" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movie_stored_meta['lyriclink10'] ) ) echo esc_attr( $movie_stored_meta['lyriclink10'][0] ); ?>" placeholder="Enter lyric link 10"></p></td>
	</tr>
</tbody>
</table>
<?php
}
function movie_meta_save( $post_id ) {
	// Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'movie_nonce' ] ) && wp_verify_nonce( $_POST[ 'movie_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }

		if ( isset( $_POST[ 'lyriclink1' ] ) ) {
		update_post_meta( $post_id, 'lyriclink1', sanitize_text_field( $_POST[ 'lyriclink1' ] ) );
	}
			if ( isset( $_POST[ 'lyriclink2' ] ) ) {
		update_post_meta( $post_id, 'lyriclink2', sanitize_text_field( $_POST[ 'lyriclink2' ] ) );
	}
			if ( isset( $_POST[ 'lyriclink3' ] ) ) {
		update_post_meta( $post_id, 'lyriclink3', sanitize_text_field( $_POST[ 'lyriclink3' ] ) );
	}
			if ( isset( $_POST[ 'lyriclink4' ] ) ) {
		update_post_meta( $post_id, 'lyriclink4', sanitize_text_field( $_POST[ 'lyriclink4' ] ) );
	}
			if ( isset( $_POST[ 'lyriclink5' ] ) ) {
		update_post_meta( $post_id, 'lyriclink5', sanitize_text_field( $_POST[ 'lyriclink5' ] ) );
	}
			if ( isset( $_POST[ 'lyriclink6' ] ) ) {
		update_post_meta( $post_id, 'lyriclink6', sanitize_text_field( $_POST[ 'lyriclink6' ] ) );
	}
			if ( isset( $_POST[ 'lyriclink7' ] ) ) {
		update_post_meta( $post_id, 'lyriclink7', sanitize_text_field( $_POST[ 'lyriclink7' ] ) );
	}
			if ( isset( $_POST[ 'lyriclink8' ] ) ) {
		update_post_meta( $post_id, 'lyriclink8', sanitize_text_field( $_POST[ 'lyriclink8' ] ) );
	}
			if ( isset( $_POST[ 'lyriclink9' ] ) ) {
		update_post_meta( $post_id, 'lyriclink9', sanitize_text_field( $_POST[ 'lyriclink9' ] ) );
	}
			if ( isset( $_POST[ 'lyriclink10' ] ) ) {
		update_post_meta( $post_id, 'lyriclink10', sanitize_text_field( $_POST[ 'lyriclink10' ] ) );
	}
		
}	
add_action( 'save_post', 'movie_meta_save' );	




//code for adding the custom meta field for movies info custom post type

function movieinfo_add_custom_metabox() {

	add_meta_box(
		'movieinfo_meta',
		__( 'Movie Info' ),
		'movieinfo_meta_callback',
		'post',
		'normal',
		'high'
	);

}
add_action( 'add_meta_boxes', 'movieinfo_add_custom_metabox' );

function movieinfo_meta_callback( $post ) {
	wp_nonce_field( basename( __FILE__ ), 'movieinfo_nonce' );
	$movieinfo_stored_meta = get_post_meta( $post->ID ); 
	?>	
	<table class="form-table">
<tbody>
	<tr valign="top">
		<th scope="row"><label for="moviename">Movie Name</label></th>
<td><p><input class="large-text" type="text" name="moviename" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movieinfo_stored_meta['moviename'] ) ) echo esc_attr( $movieinfo_stored_meta['moviename'][0] ); ?>" placeholder="Enter movie name"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="actorname">Actors Name</label></th>
<td><p><input class="large-text" type="text" name="actorname" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movieinfo_stored_meta['actorname'] ) ) echo esc_attr( $movieinfo_stored_meta['actorname'][0] ); ?>" placeholder="Enter actors name"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="authorname">Author Name</label></th>
<td><p><input class="large-text" type="text" name="authorname" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movieinfo_stored_meta['authorname'] ) ) echo esc_attr( $movieinfo_stored_meta['authorname'][0] ); ?>" placeholder="Enter author name"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="directorname">Director Name</label></th>
<td><p><input class="large-text" type="text" name="directorname" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movieinfo_stored_meta['directorname'] ) ) echo esc_attr( $movieinfo_stored_meta['directorname'][0] ); ?>" placeholder="Enter director name"></p></td>
	</tr>
		<tr valign="top">
		<th scope="row"><label for="producermoviename">Producer Name</label></th>
<td><p><input class="large-text" type="text" name="producermoviename" id="genesis_custom_body_class" value="<?php if ( ! empty ( $movieinfo_stored_meta['producermoviename'] ) ) echo esc_attr( $movieinfo_stored_meta['producermoviename'][0] ); ?>" placeholder="Enter producer name"></p></td>
	</tr>
	
</tbody>
</table>
<?php
}
function movieinfo_meta_save( $post_id ) {
	// Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'movieinfo_nonce' ] ) && wp_verify_nonce( $_POST[ 'movieinfo_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }

		if ( isset( $_POST[ 'moviename' ] ) ) {
		update_post_meta( $post_id, 'moviename', sanitize_text_field( $_POST[ 'moviename' ] ) );
	}
			if ( isset( $_POST[ 'actorname' ] ) ) {
		update_post_meta( $post_id, 'actorname', sanitize_text_field( $_POST[ 'actorname' ] ) );
	}
			if ( isset( $_POST[ 'authorname' ] ) ) {
		update_post_meta( $post_id, 'authorname', sanitize_text_field( $_POST[ 'authorname' ] ) );
	}
			if ( isset( $_POST[ 'directorname' ] ) ) {
		update_post_meta( $post_id, 'directorname', sanitize_text_field( $_POST[ 'directorname' ] ) );
	}
	if ( isset( $_POST[ 'producermoviename' ] ) ) {
		update_post_meta( $post_id, 'producermoviename', sanitize_text_field( $_POST[ 'producermoviename' ] ) );
	}
		
}	
add_action( 'save_post', 'movieinfo_meta_save' );	


/*  Add responsive container to embeds
/* ------------------------------------ */ 
function alx_embed_html( $html ) {
    return '<div class="embed-responsive embed-responsive-16by9">' . $html . '</div>';
}
 
add_filter( 'embed_oembed_html', 'alx_embed_html', 10, 3 );
add_filter( 'video_embed_html', 'alx_embed_html' ); // Jetpack


//* Remove 'You are here' from the front of breadcrumb trail
function b3m_prefix_breadcrumb( $args ) {
  $args['labels']['prefix'] = '';
  
  return $args;
}
add_filter( 'genesis_breadcrumb_args', 'b3m_prefix_breadcrumb' );

function videocode( $atts )
{

	ob_start();
	$video_id = $atts['id'];
	$imagevideo = (has_post_thumbnail($post->ID)) ? get_the_post_thumbnail($post->ID, 'realty_widget_size') : '<div class="noThumb"></div>'; 
$imagevideo = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'singlepage' ); 
	?>
	<div class="youtube-container"><div class="youtube-player" data-id="<?php echo $video_id; ?>" data-tid=""></div></div>
	<script>
					(function() {
    var v = document.getElementsByClassName("youtube-player");
    for (var n = 0; n < v.length; n++) {
        var p = document.createElement("div");
        p.innerHTML = testThumb(v[n].dataset.tid);
        p.onclick = testIframe;
        v[n].appendChild(p);
    }
})();
 
function testThumb(tid) {
    return '<img class="youtube-thumb" src="<?php echo $imagevideo[0]; ?>"><div class="play-button"></div>';
}
 
function testIframe() {
    var iframe = document.createElement("iframe");
    iframe.setAttribute("src", "//www.youtube.com/embed/" + this.parentNode.dataset.id + "?autoplay=1&autohide=2&border=0&wmode=opaque&enablejsapi=1&controls=1&iv_load_policy=3&rel=0&modestbranding=1&fs=0");
    iframe.setAttribute("frameborder", "0");
    iframe.setAttribute("id", "youtube-iframe");
    this.parentNode.replaceChild(iframe, this);
}
</script>
<?php
if (function_exists( 'is_amp_endpoint' ) && is_amp_endpoint()) 
{
	echo '<iframe width="560" height="315" src="https://www.youtube.com/embed/'.$video_id.'" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>';
}
	return ob_get_clean();
}
add_shortcode('video','videocode');	